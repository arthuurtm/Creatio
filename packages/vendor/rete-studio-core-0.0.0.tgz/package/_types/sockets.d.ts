import { ClassicPreset } from 'rete';
export declare class Socket extends ClassicPreset.Socket {
    clone(): Socket;
    serialize(): JSONSocket;
    static deserialize(data: JSONSocket): Socket;
}
export declare type JSONSocket = {
    name: string;
};
export declare class RefSocket extends Socket {
    name: string;
    identifier?: string | undefined;
    isRef: boolean;
    constructor(name: string, identifier?: string | undefined);
    clone(): RefSocket;
    serialize(): JSONRefSocket;
    static deserialize(data: JSONRefSocket): RefSocket;
}
export declare type JSONRefSocket = JSONSocket & {
    isRef: true;
    identifier?: string;
};
export declare class ControlSocket extends Socket {
    isControl: boolean;
    clone(): ControlSocket;
    serialize(): JSONControlSocket;
    static deserialize(data: JSONControlSocket): ControlSocket;
}
export declare type JSONControlSocket = JSONSocket & {
    isControl: true;
};
export declare const socket: Socket;
//# sourceMappingURL=sockets.d.ts.map