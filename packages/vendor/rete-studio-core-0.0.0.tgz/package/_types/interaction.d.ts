import { NodeEditor } from 'rete';
import { Schemes } from './types';
export declare function applyInteraction(editor: NodeEditor<Schemes>, update: (nodeId: string) => void): void;
//# sourceMappingURL=interaction.d.ts.map