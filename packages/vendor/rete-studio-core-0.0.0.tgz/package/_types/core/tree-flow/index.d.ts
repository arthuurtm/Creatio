import { C, Closures, N } from './utils';
export declare function treeToFlow<Node extends N, Con extends C>(data: {
    nodes: Node[];
    connections: Con[];
    closures: Closures;
}, props: {
    isBlock: (node: Node) => false | RegExp | string;
    isStartNode: (node: Node) => boolean;
    getBlockParameterName: (node: Node) => {
        array: boolean;
        key: string;
    };
    createConnection: (source: Node, sourceOutput: string, target: Node, targetInput: string, options?: {
        isLoop?: boolean;
        identifier?: string;
    }) => Con;
}): {
    nodes: Node[];
    connections: Con[];
    closures: Closures;
};
export declare function flowToTree<Node extends N, Con extends C>(data: {
    nodes: Node[];
    connections: Con[];
    closures: Closures;
}, props: {
    isBranchNode: (node: Node) => boolean;
    isBlock: (node: Node) => boolean | RegExp;
    isCompatible(source: Node, target: Node): boolean;
    getBlockParameterName: (node: Node) => {
        array: boolean;
        key: string;
    };
    isRoot: (node: Node) => boolean;
    createConnection: (source: Node, sourceOutput: string, target: Node, targetInput: string, options?: {
        isLoop?: boolean;
        identifier?: string;
    }) => Con;
}): {
    nodes: Node[];
    connections: Con[];
};
//# sourceMappingURL=index.d.ts.map