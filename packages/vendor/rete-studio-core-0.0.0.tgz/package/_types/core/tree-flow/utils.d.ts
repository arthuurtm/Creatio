export declare type N = {
    id: string;
};
export declare type C = {
    sourceOutput: string;
    source: string;
    target: string;
    id: string;
};
export declare type Marker = {
    index: number;
    context: C;
};
export declare type Closures = Record<string, Set<string>>;
export declare function comparable(s: string): string;
export declare function sanitize(s: string): string;
export declare function getData(s: string): {
    nodes: N[];
    connections: C[];
    closures: Closures;
};
export declare function stringifyMarkers(marker: Marker[]): string;
export declare function stringifyMarker(marker: Marker): string;
export declare function stringifyChart(connections: C[], closures: Record<string, Set<string>>): string;
//# sourceMappingURL=utils.d.ts.map