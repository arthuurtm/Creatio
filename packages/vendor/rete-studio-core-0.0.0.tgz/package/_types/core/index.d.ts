import { NodeEditor, Root, Scope } from 'rete';
import { ClassicSchemes } from '../types';
import { Transformer } from './transformer';
import { ASTNodeBase, Context, ToASTContext, ToASTOptions, ToGraphOptions } from './types';
export * from './elaborate';
export type { EnsurePort } from './methods';
export * from './methods';
export { Transformer } from './transformer';
export * from './types';
export declare class UnexpectedNode {
    node: any;
    key: string;
    item: any;
    constructor(node: any, key: string, item: any);
}
export declare type Options<ASTNode extends ASTNodeBase, S extends ClassicSchemes> = {
    transformers: Transformer<Context<ASTNode, S>, ToASTContext<ASTNode, S>>[];
    up: ToGraphOptions<ASTNode, S>;
    down: ToASTOptions<ASTNode, S>;
};
export declare class CodePlugin<Schemes extends ClassicSchemes, ASTNode extends ASTNodeBase> extends Scope<never, [Root<Schemes>]> {
    private options;
    editor: NodeEditor<Schemes>;
    snapshots: {
        up: Map<string, NodeEditor<Schemes>>;
        down: Map<string, NodeEditor<Schemes>>;
    };
    constructor(options: Options<ASTNode, Schemes>);
    setParent(scope: Scope<Root<Schemes>>): void;
    private astNodeIntoEditor;
    current: number;
    applyAST(ast: ASTNode): Promise<void>;
    step(offset: number): Promise<void>;
    getCurrentStep(): number;
    getTransformers(): Transformer<Context<ASTNode, Schemes>, ToASTContext<ASTNode, Schemes>>[];
    retrieveAST<R extends ASTNode>(): Promise<R>;
    afterStep(ast: ASTNode): Promise<void>;
    toGraph(ast: ASTNode): Promise<void>;
    private nodeIntoAST;
    toAST<R extends ASTNode>(): Promise<R>;
    private copy;
}
//# sourceMappingURL=index.d.ts.map