import { NodeEditor } from 'rete';
import { ClassicSchemes } from '../types';
import { ASTNodeBase, ToASTContext } from './types';
export declare function belongToSameClosure<S extends ClassicSchemes>(source: S['Node'], target: S['Node'], { editor }: {
    editor: NodeEditor<S>;
}): boolean;
export declare function getClosures<S extends ClassicSchemes>(node: S['Node'], context: {
    editor: NodeEditor<S>;
}): S['Node'][];
export declare function getClosureDifference2<S extends ClassicSchemes>(source: S['Node'], target: S['Node'], context: {
    editor: NodeEditor<S>;
}): {
    left: S["Node"][];
    right: S["Node"][];
};
export declare function getClosureDifference<S extends ClassicSchemes>(source: S['Node'], target: S['Node'], context: {
    editor: NodeEditor<S>;
}): {
    left: S["Node"][];
    right: S["Node"][];
};
export declare function getClosureDifferenceOld<S extends ClassicSchemes, ASTNode extends ASTNodeBase>(source: S['Node'], target: S['Node'], context: ToASTContext<ASTNode, S>): S["Node"][];
export declare function getBranchExit<S extends ClassicSchemes, ASTNode extends ASTNodeBase>(node: S['Node'], keys: string[], context: ToASTContext<ASTNode, S>): S["Node"] | null;
export declare function flowToTree<S extends ClassicSchemes, ASTNode extends ASTNodeBase>(options: {
    isRoot(node: S['Node'], context: ToASTContext<ASTNode, S>): boolean;
    isBranch(node: S['Node'], context: ToASTContext<ASTNode, S>): boolean;
    isBlock(node: S['Node'], context: ToASTContext<ASTNode, S>): boolean;
    getBranchNames(node: S['Node'], context: ToASTContext<ASTNode, S>): string[];
    getBlockParameterName(node: S['Node'], context: ToASTContext<ASTNode, S>): {
        array: boolean;
        key: string;
    };
    isValidSubflow(source: S['Node'], target: S['Node'], context: ToASTContext<ASTNode, S>): boolean;
}): (context: ToASTContext<ASTNode, S>) => Promise<void>;
export declare function reconnect<S extends ClassicSchemes, ASTNode extends ASTNodeBase>(block: S['Node'], flow: S['Node'], array: boolean, propertyName: string, context: ToASTContext<ASTNode, S>): Promise<void>;
//# sourceMappingURL=elaborate.d.ts.map