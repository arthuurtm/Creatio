export declare abstract class Transformer<Context, ToASTContext> {
    name: string;
    constructor(name: string);
    abstract up(context: Context): Promise<void>;
    abstract down(context: ToASTContext): Promise<void>;
}
//# sourceMappingURL=transformer.d.ts.map