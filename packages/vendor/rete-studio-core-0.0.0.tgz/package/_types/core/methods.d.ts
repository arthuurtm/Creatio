import { ClassicPreset, NodeEditor, NodeId } from 'rete';
import { Input, Output, Sockets } from '../nodes';
import { ClassicSchemes } from '../types';
import { ASTNodeBase, BaseOptions, Context } from './types';
declare type PromiseLike<T> = Promise<T> | T;
export declare function forEach<ASTNode extends ASTNodeBase, S extends ClassicSchemes>(match: (node: S['Node']) => boolean, command: (node: S['Node'], context: Context<ASTNode, S>) => PromiseLike<undefined | void | ((context: Context<ASTNode, any>) => Promise<void>)>): (context: Context<ASTNode, S>) => Promise<void>;
export declare function createSuperStatement<S extends ClassicSchemes>(context: {
    editor: NodeEditor<S>;
} & BaseOptions<S>, name: string, parent?: string): Promise<S["Node"]>;
export declare function expressionToExpressionStatement<ASTNode extends ASTNodeBase, S extends ClassicSchemes>(context: Context<ASTNode, S>, node: S['Node'], input: string, createStatement: () => Promise<S['Node']>): Promise<S["Node"]>;
export declare function patchPlaceholderPorts<S extends ClassicSchemes>(match: (node: S['Node']) => (undefined | {
    inputs?: {
        key: string;
    }[];
    outputs?: {
        key: string;
        flow?: boolean;
    }[];
})): (context: {
    editor: NodeEditor<S>;
} & BaseOptions<S>) => Promise<void>;
export declare function mirrorRight<ASTNode extends ASTNodeBase, S extends ClassicSchemes>(match: (node: S['Node'], key: string) => boolean, ignore: (node: S['Node'], key: string, side: 'input' | 'output') => boolean): (context: Pick<Context<ASTNode, S>, 'editor' | 'createInput' | 'createOutput' | 'createConnection'>) => Promise<void>;
export declare function mirrorLeft<ASTNode extends ASTNodeBase, S extends ClassicSchemes>(match: (node: S['Node'], key: string) => boolean, ignore: (node: S['Node'], key: string, side: 'input' | 'output') => boolean): (context: Pick<Context<ASTNode, S>, 'editor' | 'createInput' | 'createOutput' | 'createConnection'>) => Promise<void>;
export declare function simplifyIdentifiers<ASTNode extends ASTNodeBase, S extends ClassicSchemes>(matchProducer: (node: S['Node'], context: Context<ASTNode, S>) => boolean, matchConsumer: (node: S['Node'], context: Context<ASTNode, S>) => boolean, producerMatched?: (node: S['Node'], connection: S['Connection'], context: Context<ASTNode, S>) => void, consumerMatched?: (node: S['Node'], connection: S['Connection'], context: Context<ASTNode, S>) => void): (context: Context<ASTNode, S>) => Promise<void>;
export declare function simplifyLiterals<S extends ClassicSchemes>(match: (node: S['Node']) => boolean, createControl: (node: S['Node']) => ClassicPreset.Control): <ASTNode extends ASTNodeBase>(context: Context<ASTNode, S>) => Promise<void>;
export declare function getInputNode<ASTNode extends ASTNodeBase, S extends ClassicSchemes>({ editor }: Pick<Context<ASTNode, S>, 'editor'>, nodeId: NodeId, inputKey: string): [S['Node'], S['Connection']];
export declare function getInputNode<ASTNode extends ASTNodeBase, S extends ClassicSchemes>({ editor }: Pick<Context<ASTNode, S>, 'editor'>, nodeId: NodeId, inputKey: string, mandatory: false): [undefined, undefined] | [S['Node'], S['Connection']];
export declare function getOutputNode<ASTNode extends ASTNodeBase, S extends ClassicSchemes>({ editor }: Pick<Context<ASTNode, S>, 'editor'>, nodeId: NodeId, outputKey: string): [S['Node'], S['Connection']];
export declare function getOutputNode<ASTNode extends ASTNodeBase, S extends ClassicSchemes>({ editor }: Pick<Context<ASTNode, S>, 'editor'>, nodeId: NodeId, outputKey: string, mandatory: false): [undefined, undefined] | [S['Node'], S['Connection']];
export declare function findLabeledStatement<ASTNode extends ASTNodeBase, S extends ClassicSchemes>({ editor }: Pick<Context<ASTNode, S>, 'editor'>, nodeId: string): S['Node'];
export declare function findLabeledStatement<ASTNode extends ASTNodeBase, S extends ClassicSchemes>({ editor }: Pick<Context<ASTNode, S>, 'editor'>, nodeId: string, optional: true): S['Node'] | null;
export declare function rename<ASTNode extends ASTNodeBase, S extends ClassicSchemes>(rename: (node: S['Node']) => string | undefined | void, update?: (node: S['Node']) => unknown): ({ editor }: Pick<Context<ASTNode, S>, 'editor'>) => Promise<void>;
export declare function markClosures<S extends ClassicSchemes, ASTNode extends ASTNodeBase>(props: {
    isStart: (node: S['Node']) => boolean;
    isClosure: (node: S['Node']) => boolean;
}): (context: Context<ASTNode, S>) => Promise<void>;
export declare function treeToFlow<S extends ClassicSchemes, ASTNode extends ASTNodeBase>(props: {
    isStart: (node: S['Node']) => boolean;
    isSequence: (node: S['Node']) => false | RegExp | string;
    getBlockParameterName(node: S['Node'], context: any): {
        array: boolean;
        key: string;
    };
    isBranch: (node: S['Node']) => false | RegExp | string;
}): (context: Context<ASTNode, S>) => Promise<void>;
export declare function removeRedunantNodes<S extends ClassicSchemes, ASTNode extends ASTNodeBase>(match: (node: S['Node']) => boolean, reconnect?: boolean): ({ editor, createConnection }: Context<ASTNode, S>) => Promise<void>;
export declare function collapsePort<Schemes extends ClassicSchemes, ASTNode extends ASTNodeBase, S extends 'input' | 'output', P extends (S extends 'input' ? Input<Sockets> : Output<Sockets>)>(context: Context<ASTNode, Schemes>, [from, fromPort]: [Schemes['Node'], string], [to, toPort]: [Schemes['Node'], string], side: S, apply: (from: P, to: P) => void): Promise<void>;
export declare function cleanUpPorts<ASTNode extends ASTNodeBase, S extends ClassicSchemes>(exclude: (node: S['Node']) => undefined | ({
    inputs?: string[];
    outputs?: string[];
}), onRemove: (node: S['Node'], key: string, port: S['Node']['inputs'][string] | S['Node']['outputs'][string]) => void): ({ editor }: Pick<Context<ASTNode, S>, 'editor'>) => Promise<void>;
export declare type EnsurePort = string | [string, () => ClassicPreset.Socket];
export declare function ensurePorts<ASTNode extends ASTNodeBase, S extends ClassicSchemes>(include: (node: S['Node']) => undefined | ({
    inputs?: EnsurePort[];
    outputs?: EnsurePort[];
}), onAdd: (node: S['Node'], key: string, port: S['Node']['inputs'][string] | S['Node']['outputs'][string]) => void): ({ editor, createInput, createOutput }: Pick<Context<ASTNode, S>, 'editor' | 'createInput' | 'createOutput'>) => Promise<void>;
export declare function mergeSiblingNodes<ASTNode extends ASTNodeBase, S extends ClassicSchemes>(source: S['Node'], target: S['Node']): (context: Context<ASTNode, S>) => Promise<void>;
export declare function getUpdateOperator(label: string): "++" | "--" | null;
export declare function getBinaryOperator(label: string): "==" | "===" | "!=" | "!==" | null;
export declare function getLogicalOperator(label: string): "&&" | "||" | null;
export declare function getUnaryOperator(label: string): "!" | "+" | "typeof" | null;
export declare function humanizeOperator(operator: string | number, type: 'update' | 'binary' | 'logical' | 'unary'): string;
export {};
//# sourceMappingURL=methods.d.ts.map