import { ClassicPreset } from 'rete';
import { BaseNode } from './nodes';
export declare class Connection<A extends BaseNode, B extends BaseNode> extends ClassicPreset.Connection<A, B> {
    isLoop?: boolean;
    secondary?: boolean;
    identifier?: string;
    constructor(source: A, sourceOutput: keyof A['outputs'], target: B, targetInput: keyof B['inputs'], props?: {
        secondary?: boolean;
        identifier?: string;
        isLoop?: boolean;
    });
    serialize(): JSONConnection;
    static deserialize(data: JSONConnection, source: BaseNode, target: BaseNode): Connection<BaseNode, BaseNode>;
}
export declare type JSONConnection = {
    id: string;
    source: string;
    sourceOutput: string | number | symbol;
    target: string;
    targetInput: string | number | symbol;
    identifier: string | undefined;
    isLoop: boolean | undefined;
    secondary: boolean | undefined;
};
//# sourceMappingURL=connections.d.ts.map