import { ClassicPreset, NodeId } from 'rete';
import { Control, InputControl, InsertControl, JSONControl, SelectControl } from './controls';
import { ControlSocket, JSONSocket, RefSocket, Socket } from './sockets';
export declare type InputType = 'text' | 'number' | 'boolean' | 'identifier' | 'null' | 'bigint';
export declare const inputTypes: {
    label: string;
    value: InputType;
}[];
export declare type Sockets = ControlSocket | RefSocket | Socket;
export declare class Input<S extends Socket> extends ClassicPreset.Input<S> {
    control: Control | null;
    alwaysVisibleControl?: boolean;
    serialize(): JSONInput;
    static deserialize(data: JSONInput, socket: Socket, control?: Control): Input<Socket>;
}
export declare type JSONInput = {
    id: string;
    label?: string;
    index?: number;
    multipleConnections?: boolean;
    alwaysVisibleControl?: boolean;
    socket: JSONSocket;
    control?: JSONControl;
};
export declare class Output<S extends Socket> extends ClassicPreset.Output<S> {
    control?: Control;
    addControl(control: Control): void;
    removeControl(): void;
    serialize(): JSONOutput;
    static deserialize(data: JSONOutput, socket: Socket, control?: Control): Output<Socket>;
}
export declare type JSONOutput = {
    id: string;
    label?: string;
    index?: number;
    multipleConnections?: boolean;
    socket: JSONSocket;
    control?: JSONControl;
};
export declare type JSONBaseNode = {
    id: string;
    width: number;
    height: number;
    parent?: NodeId;
    label: string;
    data: BaseNodeData;
    frame?: {
        left?: boolean;
        right?: boolean;
    };
    type: 'statement' | 'expression' | 'unknown';
    inputs: Record<string, JSONInput>;
    outputs: Record<string, JSONOutput>;
    controls: Record<string, JSONControl>;
};
declare type BaseNodeData = Record<string, string | number | undefined>;
export declare class BaseNode extends ClassicPreset.Node<{
    [key in string]: Sockets;
}, {
    [key in string]: Sockets;
}, {
    [key in string]: Control | InputControl | InsertControl | SelectControl;
}> {
    width: number;
    height: number;
    parent?: NodeId;
    data: BaseNodeData;
    type: 'statement' | 'expression' | 'unknown';
    frame?: {
        left?: boolean;
        right?: boolean;
    };
    inputs: {
        [key in string]?: Input<Sockets>;
    };
    outputs: {
        [key in string]?: Output<Sockets>;
    };
    controls: {
        [key in string]: Control | InputControl | InsertControl | SelectControl;
    };
    constructor(label: string);
    serialize(): JSONBaseNode;
    static deserialize(data: JSONBaseNode, getInput: (data: JSONInput) => Input<Socket>, getOutput: (data: JSONOutput) => Output<Socket>, getControl: (data: JSONControl) => Control): BaseNode;
    addInput<K extends string>(key: K, input: Input<Socket>): void;
    removeInput(key: string): void;
    addOutput<K extends string>(key: K, output: Output<Socket>): void;
    removeOutput(key: string): void;
    addControl(key: string, control: Control): void;
    removeControl(key: string): void;
    updateSize(): void;
    clone: (keepId?: boolean) => BaseNode;
}
export {};
//# sourceMappingURL=nodes.d.ts.map