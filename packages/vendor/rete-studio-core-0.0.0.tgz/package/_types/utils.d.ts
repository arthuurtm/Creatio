import { ClassicPreset, NodeEditor, NodeId } from 'rete';
import { Socket } from './sockets';
import { ClassicSchemes } from './types';
export declare function copyToEditor<S extends ClassicSchemes>(from: NodeEditor<S>, to: NodeEditor<S>): Promise<void>;
export declare type MirrorIgnore<S extends ClassicSchemes> = (node: S['Node'], key: string, side: 'input' | 'output') => boolean | null;
export declare type MirrorContext<S extends ClassicSchemes> = {
    ignore: MirrorIgnore<S>;
    createInput: (label?: string) => ClassicPreset.Input<Socket>;
    createOutput: (label?: string) => ClassicPreset.Output<Socket>;
    createConnection: (source: S['Node'], sourceOutput: string, target: S['Node'], targetInput: string) => S['Connection'];
};
export declare function mirrorPorts<S extends ClassicSchemes>(editor: NodeEditor<S>, nodeId: string, context: MirrorContext<S>): () => void;
export declare function mirrorIncomers<S extends ClassicSchemes>(editor: NodeEditor<S>, nodeId: string, context: MirrorContext<S>): Promise<void>;
export declare function mirrorInput<S extends ClassicSchemes>(editor: NodeEditor<S>, match: (nodeId: string, input: string) => boolean, context: MirrorContext<S>): Promise<void>;
export declare function mirrorOutgoers<S extends ClassicSchemes>(editor: NodeEditor<S>, nodeId: string, context: MirrorContext<S>): Promise<void>;
export declare function mirrorOutput<S extends ClassicSchemes>(editor: NodeEditor<S>, match: (nodeId: string, output: string) => boolean, context: MirrorContext<S>): Promise<void>;
export declare function removeInputConnections<S extends ClassicSchemes>(editor: NodeEditor<S>, nodeId: NodeId, inputs?: string[]): Promise<void>;
export declare function removeOutputConnections<S extends ClassicSchemes>(editor: NodeEditor<S>, nodeId: NodeId, outputs?: string[]): Promise<void>;
export declare function removeNodeWithConnections(editor: NodeEditor<ClassicSchemes>, id: NodeId): Promise<void>;
//# sourceMappingURL=utils.d.ts.map