import { NodeEditor } from 'rete';
import { JSONConnection } from './connections';
import { JSONBaseNode } from './nodes';
import { Schemes } from './types';
export declare type JSONEditorData = {
    nodes: JSONBaseNode[];
    connections: JSONConnection[];
};
export declare function serialize(editor: NodeEditor<Schemes>): JSONEditorData;
export declare function deserialize(editor: NodeEditor<Schemes>, data: JSONEditorData): Promise<void>;
//# sourceMappingURL=serialization.d.ts.map