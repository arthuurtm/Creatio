import { ClassicPreset, GetSchemes } from 'rete';
import { Connection } from './connections';
import { BaseNode } from './nodes';
export declare type NodeProps = BaseNode;
export declare type ConnProps = Connection<BaseNode, BaseNode>;
export declare type Schemes = GetSchemes<NodeProps, ConnProps>;
interface Cloneable {
    clone(keepId?: boolean): this;
}
declare type ClassicNode = ClassicPreset.Node & {
    type: string;
    data: Record<string, any>;
    parent?: string;
} & Cloneable;
declare type C<S extends ClassicNode, T extends ClassicNode> = ClassicPreset.Connection<S, T> & {
    isLoop?: boolean;
};
export declare type ClassicSchemes = GetSchemes<ClassicNode, C<ClassicNode, ClassicNode>>;
export declare type Size = {
    width: number;
    height: number;
};
export {};
//# sourceMappingURL=types.d.ts.map