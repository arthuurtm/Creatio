import { ClassicPreset } from 'rete';
import { InputType } from './nodes';
import { Socket, socket } from './sockets';
export { Socket, socket };
export declare class Control extends ClassicPreset.Control {
    serialize(): JSONControl;
}
declare type ControlAction = string | [string, object];
interface Interactive {
    action: ControlAction;
}
export declare type JSONControl = {
    id: string;
    index?: number;
};
export declare class InsertControl extends Control implements Interactive {
    action: ControlAction;
    onClick?: (control: InsertControl) => void;
    constructor(options: {
        action: ControlAction;
        onClick?: (control: InsertControl) => void;
    });
    clone(): InsertControl;
    serialize(): JSONInsertControl;
    static deserialize(data: JSONInsertControl): InsertControl;
}
export declare type JSONInsertControl = JSONControl & Interactive & {
    isInsertControl: true;
    action: ControlAction;
};
declare type SelectOption = {
    value: string;
    label: string;
};
declare type SelectChange = (value: string, control: SelectControl) => void;
export declare class SelectControl extends Control implements Interactive {
    action: ControlAction;
    value: string;
    options: SelectOption[];
    onChange?: SelectChange;
    constructor(props: {
        action: ControlAction;
        value: string;
        options: SelectOption[];
        onChange?: SelectChange;
    });
    change(key: string): void;
    clone(): SelectControl;
    serialize(): JSONSelectControl;
    static deserialize(data: JSONSelectControl): SelectControl;
}
export declare type JSONSelectControl = JSONControl & Interactive & {
    isSelectControl: true;
    value: string;
    options: SelectOption[];
};
export declare class InputControl extends ClassicPreset.InputControl<'text' | 'number'> implements Interactive {
    options: {
        action: ControlAction;
        type: InputType;
        readonly?: boolean;
        initial?: string | number;
        onChange?: (value?: string | number) => void;
        allowedTypes?: InputType[];
    };
    action: ControlAction;
    constructor(options: {
        action: ControlAction;
        type: InputType;
        readonly?: boolean;
        initial?: string | number;
        onChange?: (value?: string | number) => void;
        allowedTypes?: InputType[];
    });
    setValue(value?: string | number | undefined): void;
    clone(): InputControl;
    serialize(): JSONInputControl;
    static deserialize(data: JSONInputControl): InputControl;
}
export declare type JSONInputControl = JSONControl & Interactive & {
    isInputControl: true;
    readonly: boolean;
    type: InputType;
    value?: string | number;
    allowedTypes?: InputType[];
};
//# sourceMappingURL=controls.d.ts.map