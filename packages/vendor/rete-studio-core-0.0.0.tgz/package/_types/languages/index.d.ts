import { CodePlugin } from '../core';
import { JSONEditorData } from '../serialization';
import { Schemes } from '../types';
export declare type LanguageSnippet = {
    label: string;
    code: (() => string) | string;
} | {
    label: string;
    subitems: LanguageSnippet[];
};
export declare type Language<ParseResult, N extends {
    type: string;
}, F extends N> = {
    playgroundExample: string;
    snippets: LanguageSnippet[];
    initCodePlugin: () => {
        code: CodePlugin<Schemes, N>;
        astTools: {
            parse(code: string): Promise<ParseResult>;
            generate(ast: N): Promise<string>;
            purify(ast: ParseResult): Promise<F>;
            unpurify(ast: F): Promise<F>;
            executable(ast: F): Promise<F>;
        };
        unsupportedTypes: string[];
        processedTypes: Set<string>;
        toGraph: (ast: F) => Promise<void>;
        toAST: () => Promise<F>;
    };
};
export interface LanguageAdapter {
    getExample(): Promise<string>;
    getSnippets(): Promise<LanguageSnippet[]>;
    codeToExecutable(code: string): Promise<string>;
    graphToCode(data: JSONEditorData): Promise<string>;
    codeToGraph(code: string): Promise<JSONEditorData>;
    _getTransformerNames(): Promise<string[]>;
    _applySnapshot(direction: 'down' | 'up', id: string): Promise<JSONEditorData>;
}
export declare function createAdapter(language: Language<any, any, any>): LanguageAdapter;
//# sourceMappingURL=index.d.ts.map