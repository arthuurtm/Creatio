/*!
* rete-studio-core v0.0.0
* (c) 2026 Vitaliy Stoliarov
* Released under the CC-BY-NC-SA-4.0 license.
* */
'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var _classCallCheck = require('@babel/runtime/helpers/classCallCheck');
var _createClass = require('@babel/runtime/helpers/createClass');
var _inherits = require('@babel/runtime/helpers/inherits');
var _possibleConstructorReturn = require('@babel/runtime/helpers/possibleConstructorReturn');
var _getPrototypeOf = require('@babel/runtime/helpers/getPrototypeOf');
var rete = require('rete');
var _toConsumableArray = require('@babel/runtime/helpers/toConsumableArray');
var _defineProperty = require('@babel/runtime/helpers/defineProperty');
var _get = require('@babel/runtime/helpers/get');
var _assertThisInitialized = require('@babel/runtime/helpers/assertThisInitialized');
var _typeof = require('@babel/runtime/helpers/typeof');
var _asyncToGenerator = require('@babel/runtime/helpers/asyncToGenerator');
var _regeneratorRuntime = require('@babel/runtime/regenerator');
var reteStructures = require('rete-structures');
var _slicedToArray = require('@babel/runtime/helpers/slicedToArray');

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var _classCallCheck__default = /*#__PURE__*/_interopDefaultLegacy(_classCallCheck);
var _createClass__default = /*#__PURE__*/_interopDefaultLegacy(_createClass);
var _inherits__default = /*#__PURE__*/_interopDefaultLegacy(_inherits);
var _possibleConstructorReturn__default = /*#__PURE__*/_interopDefaultLegacy(_possibleConstructorReturn);
var _getPrototypeOf__default = /*#__PURE__*/_interopDefaultLegacy(_getPrototypeOf);
var _toConsumableArray__default = /*#__PURE__*/_interopDefaultLegacy(_toConsumableArray);
var _defineProperty__default = /*#__PURE__*/_interopDefaultLegacy(_defineProperty);
var _get__default = /*#__PURE__*/_interopDefaultLegacy(_get);
var _assertThisInitialized__default = /*#__PURE__*/_interopDefaultLegacy(_assertThisInitialized);
var _typeof__default = /*#__PURE__*/_interopDefaultLegacy(_typeof);
var _asyncToGenerator__default = /*#__PURE__*/_interopDefaultLegacy(_asyncToGenerator);
var _regeneratorRuntime__default = /*#__PURE__*/_interopDefaultLegacy(_regeneratorRuntime);
var _slicedToArray__default = /*#__PURE__*/_interopDefaultLegacy(_slicedToArray);

function _createSuper$4(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$4(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$4() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Connection = /*#__PURE__*/function (_ClassicPreset$Connec) {
  _inherits__default["default"](Connection, _ClassicPreset$Connec);
  var _super = _createSuper$4(Connection);
  function Connection(source, sourceOutput, target, targetInput, props) {
    var _this;
    _classCallCheck__default["default"](this, Connection);
    _this = _super.call(this, source, sourceOutput, target, targetInput);
    _this.isLoop = props === null || props === void 0 ? void 0 : props.isLoop;
    _this.identifier = props === null || props === void 0 ? void 0 : props.identifier;
    _this.secondary = props === null || props === void 0 ? void 0 : props.secondary;
    return _this;
  }
  _createClass__default["default"](Connection, [{
    key: "serialize",
    value: function serialize() {
      var id = this.id,
        source = this.source,
        sourceOutput = this.sourceOutput,
        target = this.target,
        targetInput = this.targetInput,
        identifier = this.identifier,
        isLoop = this.isLoop,
        secondary = this.secondary;
      return {
        id: id,
        source: source,
        sourceOutput: sourceOutput,
        target: target,
        targetInput: targetInput,
        identifier: identifier,
        isLoop: isLoop,
        secondary: secondary
      };
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data, source, target) {
      var connection = new Connection(source, String(data.sourceOutput), target, String(data.targetInput), {
        isLoop: data.isLoop,
        identifier: data.identifier,
        secondary: data.secondary
      });
      connection.id = data.id;
      return connection;
    }
  }]);
  return Connection;
}(rete.ClassicPreset.Connection);

function ownKeys$5(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread$5(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys$5(Object(t), !0).forEach(function (r) { _defineProperty__default["default"](e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$5(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _createSuper$3(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$3(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$3() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Socket = /*#__PURE__*/function (_ClassicPreset$Socket) {
  _inherits__default["default"](Socket, _ClassicPreset$Socket);
  var _super = _createSuper$3(Socket);
  function Socket() {
    _classCallCheck__default["default"](this, Socket);
    return _super.apply(this, arguments);
  }
  _createClass__default["default"](Socket, [{
    key: "clone",
    value: function clone() {
      return new Socket(this.name);
    }
  }, {
    key: "serialize",
    value: function serialize() {
      return {
        name: this.name
      };
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data) {
      return new Socket(data.name);
    }
  }]);
  return Socket;
}(rete.ClassicPreset.Socket);
var RefSocket = /*#__PURE__*/function (_Socket) {
  _inherits__default["default"](RefSocket, _Socket);
  var _super2 = _createSuper$3(RefSocket);
  function RefSocket(name, identifier) {
    var _this;
    _classCallCheck__default["default"](this, RefSocket);
    _this = _super2.call(this, name);
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "isRef", true);
    _this.name = name;
    _this.identifier = identifier;
    return _this;
  }
  _createClass__default["default"](RefSocket, [{
    key: "clone",
    value: function clone() {
      return new RefSocket(this.name, this.identifier);
    }
  }, {
    key: "serialize",
    value: function serialize() {
      return _objectSpread$5(_objectSpread$5({}, _get__default["default"](_getPrototypeOf__default["default"](RefSocket.prototype), "serialize", this).call(this)), {}, {
        isRef: true,
        identifier: this.identifier
      });
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data) {
      var socket = new RefSocket(data.name);
      socket.identifier = data.identifier;
      return socket;
    }
  }]);
  return RefSocket;
}(Socket);
var ControlSocket = /*#__PURE__*/function (_Socket2) {
  _inherits__default["default"](ControlSocket, _Socket2);
  var _super3 = _createSuper$3(ControlSocket);
  function ControlSocket() {
    var _this2;
    _classCallCheck__default["default"](this, ControlSocket);
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    _this2 = _super3.call.apply(_super3, [this].concat(args));
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this2), "isControl", true);
    return _this2;
  }
  _createClass__default["default"](ControlSocket, [{
    key: "clone",
    value: function clone() {
      return new ControlSocket(this.name);
    }
  }, {
    key: "serialize",
    value: function serialize() {
      return _objectSpread$5(_objectSpread$5({}, _get__default["default"](_getPrototypeOf__default["default"](ControlSocket.prototype), "serialize", this).call(this)), {}, {
        isControl: true
      });
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data) {
      var socket = new ControlSocket(data.name);
      return socket;
    }
  }]);
  return ControlSocket;
}(Socket);
var socket = new Socket('any');

function ownKeys$4(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread$4(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys$4(Object(t), !0).forEach(function (r) { _defineProperty__default["default"](e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$4(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _createSuper$2(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$2(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$2() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Control = /*#__PURE__*/function (_ClassicPreset$Contro) {
  _inherits__default["default"](Control, _ClassicPreset$Contro);
  var _super = _createSuper$2(Control);
  function Control() {
    _classCallCheck__default["default"](this, Control);
    return _super.apply(this, arguments);
  }
  _createClass__default["default"](Control, [{
    key: "serialize",
    value: function serialize() {
      return {
        id: this.id,
        index: this.index
      };
    }
  }]);
  return Control;
}(rete.ClassicPreset.Control);
var InsertControl = /*#__PURE__*/function (_Control) {
  _inherits__default["default"](InsertControl, _Control);
  var _super2 = _createSuper$2(InsertControl);
  function InsertControl(options) {
    var _this;
    _classCallCheck__default["default"](this, InsertControl);
    _this = _super2.call(this);
    _this.action = options.action;
    _this.onClick = options.onClick;
    return _this;
  }
  _createClass__default["default"](InsertControl, [{
    key: "clone",
    value: function clone() {
      return new InsertControl({
        action: this.action,
        onClick: this.onClick
      });
    }
  }, {
    key: "serialize",
    value: function serialize() {
      return _objectSpread$4({
        isInsertControl: true,
        action: this.action
      }, _get__default["default"](_getPrototypeOf__default["default"](InsertControl.prototype), "serialize", this).call(this));
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data) {
      var control = new InsertControl({
        action: data.action
      });
      control.id = data.id;
      control.index = data.index;
      return control;
    }
  }]);
  return InsertControl;
}(Control);
var SelectControl = /*#__PURE__*/function (_Control2) {
  _inherits__default["default"](SelectControl, _Control2);
  var _super3 = _createSuper$2(SelectControl);
  function SelectControl(props) {
    var _this2;
    _classCallCheck__default["default"](this, SelectControl);
    _this2 = _super3.call(this);
    _this2.action = props.action;
    _this2.value = props.value;
    _this2.options = props.options;
    _this2.onChange = props.onChange;
    return _this2;
  }
  _createClass__default["default"](SelectControl, [{
    key: "change",
    value: function change(key) {
      this.value = key;
      if (this.onChange) this.onChange(key, this);
    }
  }, {
    key: "clone",
    value: function clone() {
      return new SelectControl({
        action: this.action,
        value: this.value,
        options: this.options,
        onChange: this.onChange
      });
    }
  }, {
    key: "serialize",
    value: function serialize() {
      return _objectSpread$4(_objectSpread$4({}, _get__default["default"](_getPrototypeOf__default["default"](SelectControl.prototype), "serialize", this).call(this)), {}, {
        action: this.action,
        isSelectControl: true,
        value: this.value,
        options: this.options
      });
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data) {
      var control = new SelectControl({
        action: data.action,
        value: data.value,
        options: data.options
      });
      control.id = data.id;
      control.index = data.index;
      return control;
    }
  }]);
  return SelectControl;
}(Control);
var InputControl = /*#__PURE__*/function (_ClassicPreset$InputC) {
  _inherits__default["default"](InputControl, _ClassicPreset$InputC);
  var _super4 = _createSuper$2(InputControl);
  function InputControl(options) {
    var _this3;
    _classCallCheck__default["default"](this, InputControl);
    _this3 = _super4.call(this, 'text', options);
    _this3.options = options;
    _this3.action = options.action;
    return _this3;
  }
  _createClass__default["default"](InputControl, [{
    key: "setValue",
    value: function setValue(value) {
      var _this$options;
      var type = (_this$options = this.options) === null || _this$options === void 0 ? void 0 : _this$options.type;
      var val = type === 'number' && typeof value !== 'undefined' ? +value : value;
      _get__default["default"](_getPrototypeOf__default["default"](InputControl.prototype), "setValue", this).call(this, val);
      if (this.options.onChange) this.options.onChange(val);
    }
  }, {
    key: "clone",
    value: function clone() {
      var _this$options2, _this$options3;
      return new InputControl({
        action: this.action,
        type: ((_this$options2 = this.options) === null || _this$options2 === void 0 ? void 0 : _this$options2.type) || 'text',
        readonly: this.readonly,
        initial: this.value,
        allowedTypes: (_this$options3 = this.options) !== null && _this$options3 !== void 0 && _this$options3.allowedTypes ? _toConsumableArray__default["default"](this.options.allowedTypes) : undefined,
        onChange: this.options.onChange
      });
    }
  }, {
    key: "serialize",
    value: function serialize() {
      var _this$options4, _this$options5;
      return {
        isInputControl: true,
        action: this.action,
        id: this.id,
        index: this.index,
        readonly: this.readonly,
        type: ((_this$options4 = this.options) === null || _this$options4 === void 0 ? void 0 : _this$options4.type) || 'text',
        value: this.value,
        allowedTypes: (_this$options5 = this.options) === null || _this$options5 === void 0 ? void 0 : _this$options5.allowedTypes
      };
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data) {
      var control = new InputControl({
        action: data.action,
        type: data.type,
        readonly: data.readonly,
        initial: data.value,
        allowedTypes: data.allowedTypes
      });
      return control;
    }
  }]);
  return InputControl;
}(rete.ClassicPreset.InputControl);

var BIND_KEY = 'bind';

function ownKeys$3(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread$3(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys$3(Object(t), !0).forEach(function (r) { _defineProperty__default["default"](e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$3(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _createSuper$1(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$1(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$1() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var inputTypes = [{
  label: 'Identifier',
  value: 'identifier'
}, {
  label: 'Number',
  value: 'number'
}, {
  label: 'Text',
  value: 'text'
}, {
  label: 'Boolean',
  value: 'boolean'
}, {
  label: 'null',
  value: 'null'
}, {
  label: 'BigInt',
  value: 'bigint'
}];
var Input = /*#__PURE__*/function (_ClassicPreset$Input) {
  _inherits__default["default"](Input, _ClassicPreset$Input);
  var _super = _createSuper$1(Input);
  function Input() {
    _classCallCheck__default["default"](this, Input);
    return _super.apply(this, arguments);
  }
  _createClass__default["default"](Input, [{
    key: "serialize",
    value: function serialize() {
      var _this$control;
      return {
        id: this.id,
        label: this.label,
        index: this.index,
        multipleConnections: this.multipleConnections,
        alwaysVisibleControl: this.alwaysVisibleControl,
        socket: this.socket.serialize(),
        control: (_this$control = this.control) === null || _this$control === void 0 ? void 0 : _this$control.serialize()
      };
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data, socket, control) {
      var input = new Input(socket, data.label, data.multipleConnections);
      input.id = data.id;
      input.index = data.index;
      input.alwaysVisibleControl = data.alwaysVisibleControl;
      if (control) input.addControl(control);
      return input;
    }
  }]);
  return Input;
}(rete.ClassicPreset.Input);
var Output = /*#__PURE__*/function (_ClassicPreset$Output) {
  _inherits__default["default"](Output, _ClassicPreset$Output);
  var _super2 = _createSuper$1(Output);
  function Output() {
    _classCallCheck__default["default"](this, Output);
    return _super2.apply(this, arguments);
  }
  _createClass__default["default"](Output, [{
    key: "addControl",
    value: function addControl(control) {
      this.control = control;
    }
  }, {
    key: "removeControl",
    value: function removeControl() {
      this.control = undefined;
    }
  }, {
    key: "serialize",
    value: function serialize() {
      var _this$control2;
      return {
        id: this.id,
        label: this.label,
        index: this.index,
        multipleConnections: this.multipleConnections,
        socket: this.socket.serialize(),
        control: (_this$control2 = this.control) === null || _this$control2 === void 0 ? void 0 : _this$control2.serialize()
      };
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data, socket, control) {
      var output = new Output(socket, data.label, data.multipleConnections);
      output.id = data.id;
      output.index = data.index;
      if (control) output.addControl(control);
      return output;
    }
  }]);
  return Output;
}(rete.ClassicPreset.Output);
var BaseNode = /*#__PURE__*/function (_ClassicPreset$Node) {
  _inherits__default["default"](BaseNode, _ClassicPreset$Node);
  var _super3 = _createSuper$1(BaseNode);
  // loopBranch?: boolean

  function BaseNode(label) {
    var _this;
    _classCallCheck__default["default"](this, BaseNode);
    _this = _super3.call(this, label);
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "width", 300);
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "height", 30);
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "data", {});
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "type", 'unknown');
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "inputs", {});
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "outputs", {});
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "controls", {});
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "clone", function (keepId) {
      var n = new BaseNode(_this.label);
      if (keepId) n.id = _this.id;
      n.removeInput(BIND_KEY);
      Object.keys(_this.inputs).forEach(function (k) {
        var inp = _this.inputs[k];
        if (inp && !n.hasInput(k)) {
          var clone = new Input(inp.socket.clone(), inp.label, true);
          clone.index = inp.index;
          if (inp.control) {
            if (!('clone' in inp.control)) throw new Error('Input control must implement clone method');
            clone.control = inp.control.clone();
          }
          n.addInput(k, clone);
        }
      });
      n.removeOutput(BIND_KEY);
      Object.keys(_this.outputs).forEach(function (k) {
        var out = _this.outputs[k];
        if (out && !n.hasOutput(k)) {
          var clone = new Output(out.socket.clone(), out.label, true);
          clone.index = out.index;
          if (out.control) {
            if (!('clone' in out.control)) throw new Error('Output control must implement clone method');
            clone.control = out.control.clone();
          }
          n.addOutput(k, clone);
        }
      });
      Object.keys(_this.controls).forEach(function (k) {
        var control = _this.controls[k];
        if (control && !n.hasControl(k)) {
          if (!('clone' in control)) throw new Error('Control must implement clone method');
          n.addControl(k, control.clone());
        }
      });
      n.type = _this.type;
      n.parent = _this.parent;
      n.height = _this.height;
      n.width = _this.width;
      n.data = _objectSpread$3({}, _this.data);
      n.frame = _this.frame ? _objectSpread$3({}, _this.frame) : undefined;
      return n;
    });
    _this.addInput(BIND_KEY, new Input(socket, '', true));
    _this.addOutput(BIND_KEY, new Output(socket, '', true));
    return _this;
  }
  _createClass__default["default"](BaseNode, [{
    key: "serialize",
    value: function serialize() {
      return {
        id: this.id,
        width: this.width,
        height: this.height,
        parent: this.parent,
        label: this.label,
        frame: this.frame,
        data: _objectSpread$3({}, this.data),
        type: this.type,
        inputs: Object.fromEntries(Object.entries(this.inputs).map(function (_ref) {
          var _ref2 = _slicedToArray__default["default"](_ref, 2),
            key = _ref2[0],
            input = _ref2[1];
          return input ? [key, input.serialize()] : [key];
        })),
        outputs: Object.fromEntries(Object.entries(this.outputs).map(function (_ref3) {
          var _ref4 = _slicedToArray__default["default"](_ref3, 2),
            key = _ref4[0],
            output = _ref4[1];
          return output ? [key, output.serialize()] : [key];
        })),
        controls: Object.fromEntries(Object.entries(this.controls).map(function (_ref5) {
          var _ref6 = _slicedToArray__default["default"](_ref5, 2),
            key = _ref6[0],
            control = _ref6[1];
          return control ? [key, control.serialize()] : [key];
        }))
      };
    }
  }, {
    key: "addInput",
    value: function addInput(key, input) {
      _get__default["default"](_getPrototypeOf__default["default"](BaseNode.prototype), "addInput", this).call(this, key, input);
      this.updateSize();
    }
  }, {
    key: "removeInput",
    value: function removeInput(key) {
      if (this.hasInput(key)) {
        _get__default["default"](_getPrototypeOf__default["default"](BaseNode.prototype), "removeInput", this).call(this, key);
        this.updateSize();
      }
    }
  }, {
    key: "addOutput",
    value: function addOutput(key, output) {
      _get__default["default"](_getPrototypeOf__default["default"](BaseNode.prototype), "addOutput", this).call(this, key, output);
      this.updateSize();
    }
  }, {
    key: "removeOutput",
    value: function removeOutput(key) {
      if (this.hasOutput(key)) {
        _get__default["default"](_getPrototypeOf__default["default"](BaseNode.prototype), "removeOutput", this).call(this, key);
        this.updateSize();
      }
    }
  }, {
    key: "addControl",
    value: function addControl(key, control) {
      _get__default["default"](_getPrototypeOf__default["default"](BaseNode.prototype), "addControl", this).call(this, key, control);
      this.updateSize();
    }
  }, {
    key: "removeControl",
    value: function removeControl(key) {
      _get__default["default"](_getPrototypeOf__default["default"](BaseNode.prototype), "removeControl", this).call(this, key);
      this.updateSize();
    }
  }, {
    key: "updateSize",
    value: function updateSize() {
      var inputs = Object.entries(this.inputs);
      var outputs = Object.entries(this.outputs);
      var controls = Object.entries(this.controls);
      this.height = 40 + 4 + 5 + Math.max(inputs.length, outputs.length) * 36 + controls.length * 36;
      var inputsWidths = inputs.map(function (_ref7) {
        var _i$label;
        var _ref8 = _slicedToArray__default["default"](_ref7, 2);
          _ref8[0];
          var i = _ref8[1];
        return i !== null && i !== void 0 && i.control ? 120 : 50 + ((i === null || i === void 0 ? void 0 : (_i$label = i.label) === null || _i$label === void 0 ? void 0 : _i$label.length) || 0) * 6;
      });
      var outputsWidths = outputs.map(function (_ref9) {
        var _i$label2;
        var _ref10 = _slicedToArray__default["default"](_ref9, 2);
          _ref10[0];
          var i = _ref10[1];
        return i !== null && i !== void 0 && i.control ? 120 : 50 + ((i === null || i === void 0 ? void 0 : (_i$label2 = i.label) === null || _i$label2 === void 0 ? void 0 : _i$label2.length) || 0) * 6;
      });
      var labelWidth = this.label ? this.label.length * 12 : 0;
      // const controlsWidths = controls.map(([_, i]) => 100)

      this.width = Math.max(labelWidth, 50 + Math.max.apply(Math, _toConsumableArray__default["default"](inputsWidths).concat([0])) + Math.max.apply(Math, _toConsumableArray__default["default"](outputsWidths).concat([0]))); // + Math.max(...controlsWidths, 0)
    }
  }], [{
    key: "deserialize",
    value: function deserialize(data, getInput, getOutput, getControl) {
      var node = new BaseNode(data.label);
      node.id = data.id;
      node.parent = data.parent;
      node.data = data.data;
      node.type = data.type;
      node.frame = data.frame;
      node.removeInput(BIND_KEY);
      node.removeOutput(BIND_KEY);
      Object.entries(data.inputs).forEach(function (_ref11) {
        var _ref12 = _slicedToArray__default["default"](_ref11, 2),
          key = _ref12[0],
          input = _ref12[1];
        node.addInput(key, getInput(input));
      });
      Object.entries(data.outputs).forEach(function (_ref13) {
        var _ref14 = _slicedToArray__default["default"](_ref13, 2),
          key = _ref14[0],
          output = _ref14[1];
        node.addOutput(key, getOutput(output));
      });
      Object.entries(data.controls).forEach(function (_ref15) {
        var _ref16 = _slicedToArray__default["default"](_ref15, 2),
          key = _ref16[0],
          control = _ref16[1];
        node.addControl(key, getControl(control));
      });
      return node;
    }
  }]);
  return BaseNode;
}(rete.ClassicPreset.Node);

function _createForOfIteratorHelper$6(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$6(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$6(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$6(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$6(o, minLen); }
function _arrayLikeToArray$6(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function ownKeys$2(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread$2(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys$2(Object(t), !0).forEach(function (r) { _defineProperty__default["default"](e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$2(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function copyToEditor(_x, _x2) {
  return _copyToEditor.apply(this, arguments);
}
function _copyToEditor() {
  _copyToEditor = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(from, to) {
    var addNodes, _addNodes, _iterator, _step, n;
    return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          _addNodes = function _addNodes3() {
            _addNodes = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(parent) {
              var _iterator2, _step2, _node;
              return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
                while (1) switch (_context.prev = _context.next) {
                  case 0:
                    _iterator2 = _createForOfIteratorHelper$6(from.getNodes().filter(function (n) {
                      return n.parent === parent;
                    }));
                    _context.prev = 1;
                    _iterator2.s();
                  case 3:
                    if ((_step2 = _iterator2.n()).done) {
                      _context.next = 11;
                      break;
                    }
                    _node = _step2.value;
                    _context.next = 7;
                    return to.addNode(_node.clone(true));
                  case 7:
                    _context.next = 9;
                    return addNodes(_node.id);
                  case 9:
                    _context.next = 3;
                    break;
                  case 11:
                    _context.next = 16;
                    break;
                  case 13:
                    _context.prev = 13;
                    _context.t0 = _context["catch"](1);
                    _iterator2.e(_context.t0);
                  case 16:
                    _context.prev = 16;
                    _iterator2.f();
                    return _context.finish(16);
                  case 19:
                  case "end":
                    return _context.stop();
                }
              }, _callee, null, [[1, 13, 16, 19]]);
            }));
            return _addNodes.apply(this, arguments);
          };
          addNodes = function _addNodes2(_x23) {
            return _addNodes.apply(this, arguments);
          };
          _context2.next = 4;
          return addNodes();
        case 4:
          _iterator = _createForOfIteratorHelper$6(from.getConnections());
          _context2.prev = 5;
          _iterator.s();
        case 7:
          if ((_step = _iterator.n()).done) {
            _context2.next = 13;
            break;
          }
          n = _step.value;
          _context2.next = 11;
          return to.addConnection(n);
        case 11:
          _context2.next = 7;
          break;
        case 13:
          _context2.next = 18;
          break;
        case 15:
          _context2.prev = 15;
          _context2.t0 = _context2["catch"](5);
          _iterator.e(_context2.t0);
        case 18:
          _context2.prev = 18;
          _iterator.f();
          return _context2.finish(18);
        case 21:
        case "end":
          return _context2.stop();
      }
    }, _callee2, null, [[5, 15, 18, 21]]);
  }));
  return _copyToEditor.apply(this, arguments);
}
function mirrorPorts(editor, nodeId, context) {
  var ignore = context.ignore;
  var node = editor.getNode(nodeId);
  var inputs = _objectSpread$2({}, node.inputs);
  var outputs = _objectSpread$2({}, node.outputs);
  var newInputs = [];
  var newOutputs = [];
  for (var _key in inputs) {
    if (ignore(node, _key, 'input')) continue;
    var _input = inputs[_key];
    if (_input && !outputs[_key]) {
      node.addOutput(_key, context.createOutput(_input.label));
      newOutputs.push(_key);
    }
  }
  for (var _key2 in outputs) {
    if (ignore(node, _key2, 'output')) continue;
    var _output = outputs[_key2];
    if (_output && !inputs[_key2]) {
      node.addInput(_key2, context.createInput(_output.label));
      newInputs.push(_key2);
    }
  }
  return function () {
    for (var _i = 0, _newOutputs = newOutputs; _i < _newOutputs.length; _i++) {
      var _key3 = _newOutputs[_i];
      node.removeInput(_key3);
    }
    for (var _i2 = 0, _newInputs = newInputs; _i2 < _newInputs.length; _i2++) {
      var _key4 = _newInputs[_i2];
      node.removeOutput(_key4);
    }
  };
}
function mirrorIncomers(_x3, _x4, _x5) {
  return _mirrorIncomers.apply(this, arguments);
}
function _mirrorIncomers() {
  _mirrorIncomers = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(editor, nodeId, context) {
    var ignore, inpCons, clear, _iterator3, _step3, c;
    return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          ignore = context.ignore;
          inpCons = editor.getConnections().filter(function (c) {
            return c.target === nodeId;
          });
          clear = mirrorPorts(editor, nodeId, context);
          _iterator3 = _createForOfIteratorHelper$6(inpCons);
          _context3.prev = 4;
          _iterator3.s();
        case 6:
          if ((_step3 = _iterator3.n()).done) {
            _context3.next = 18;
            break;
          }
          c = _step3.value;
          if (!(ignore && ignore(editor.getNode(nodeId), c.targetInput, 'input'))) {
            _context3.next = 10;
            break;
          }
          return _context3.abrupt("continue", 16);
        case 10:
          _context3.next = 12;
          return mirrorIncomers(editor, c.source, context);
        case 12:
          _context3.next = 14;
          return editor.removeConnection(c.id);
        case 14:
          _context3.next = 16;
          return editor.addConnection(context.createConnection(editor.getNode(c.target), c.targetInput, editor.getNode(c.source), c.sourceOutput));
        case 16:
          _context3.next = 6;
          break;
        case 18:
          _context3.next = 23;
          break;
        case 20:
          _context3.prev = 20;
          _context3.t0 = _context3["catch"](4);
          _iterator3.e(_context3.t0);
        case 23:
          _context3.prev = 23;
          _iterator3.f();
          return _context3.finish(23);
        case 26:
          clear();
        case 27:
        case "end":
          return _context3.stop();
      }
    }, _callee3, null, [[4, 20, 23, 26]]);
  }));
  return _mirrorIncomers.apply(this, arguments);
}
function mirrorInput(_x6, _x7, _x8) {
  return _mirrorInput.apply(this, arguments);
}
function _mirrorInput() {
  _mirrorInput = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4(editor, match, context) {
    var cons, _iterator4, _step4, con, _node2;
    return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          cons = editor.getConnections().filter(function (c) {
            return match(c.target, c.targetInput);
          });
          _iterator4 = _createForOfIteratorHelper$6(cons);
          _context4.prev = 2;
          _iterator4.s();
        case 4:
          if ((_step4 = _iterator4.n()).done) {
            _context4.next = 19;
            break;
          }
          con = _step4.value;
          _node2 = editor.getNode(con.target);
          _context4.next = 9;
          return mirrorIncomers(editor, con.source, context);
        case 9:
          _context4.t0 = con;
          if (!_context4.t0) {
            _context4.next = 13;
            break;
          }
          _context4.next = 13;
          return editor.removeConnection(con.id);
        case 13:
          _node2.removeInput(con.targetInput);
          _node2.addOutput(con.targetInput, context.createOutput(con.targetInput));
          _context4.next = 17;
          return editor.addConnection(context.createConnection(_node2, con.targetInput, editor.getNode(con.source), con.sourceOutput));
        case 17:
          _context4.next = 4;
          break;
        case 19:
          _context4.next = 24;
          break;
        case 21:
          _context4.prev = 21;
          _context4.t1 = _context4["catch"](2);
          _iterator4.e(_context4.t1);
        case 24:
          _context4.prev = 24;
          _iterator4.f();
          return _context4.finish(24);
        case 27:
        case "end":
          return _context4.stop();
      }
    }, _callee4, null, [[2, 21, 24, 27]]);
  }));
  return _mirrorInput.apply(this, arguments);
}
function mirrorOutgoers(_x9, _x10, _x11) {
  return _mirrorOutgoers.apply(this, arguments);
}
function _mirrorOutgoers() {
  _mirrorOutgoers = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee5(editor, nodeId, context) {
    var ignore, inpCons, clear, _iterator5, _step5, c;
    return _regeneratorRuntime__default["default"].wrap(function _callee5$(_context5) {
      while (1) switch (_context5.prev = _context5.next) {
        case 0:
          ignore = context.ignore;
          inpCons = editor.getConnections().filter(function (c) {
            return c.source === nodeId;
          });
          clear = mirrorPorts(editor, nodeId, context);
          _iterator5 = _createForOfIteratorHelper$6(inpCons);
          _context5.prev = 4;
          _iterator5.s();
        case 6:
          if ((_step5 = _iterator5.n()).done) {
            _context5.next = 18;
            break;
          }
          c = _step5.value;
          if (!(ignore && ignore(editor.getNode(nodeId), c.sourceOutput, 'output'))) {
            _context5.next = 10;
            break;
          }
          return _context5.abrupt("continue", 16);
        case 10:
          _context5.next = 12;
          return mirrorOutgoers(editor, c.target, context);
        case 12:
          _context5.next = 14;
          return editor.removeConnection(c.id);
        case 14:
          _context5.next = 16;
          return editor.addConnection(context.createConnection(editor.getNode(c.target), c.targetInput, editor.getNode(c.source), c.sourceOutput));
        case 16:
          _context5.next = 6;
          break;
        case 18:
          _context5.next = 23;
          break;
        case 20:
          _context5.prev = 20;
          _context5.t0 = _context5["catch"](4);
          _iterator5.e(_context5.t0);
        case 23:
          _context5.prev = 23;
          _iterator5.f();
          return _context5.finish(23);
        case 26:
          clear();
        case 27:
        case "end":
          return _context5.stop();
      }
    }, _callee5, null, [[4, 20, 23, 26]]);
  }));
  return _mirrorOutgoers.apply(this, arguments);
}
function mirrorOutput(_x12, _x13, _x14) {
  return _mirrorOutput.apply(this, arguments);
}
function _mirrorOutput() {
  _mirrorOutput = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee6(editor, match, context) {
    var cons, _iterator6, _step6, con, _node3;
    return _regeneratorRuntime__default["default"].wrap(function _callee6$(_context6) {
      while (1) switch (_context6.prev = _context6.next) {
        case 0:
          cons = editor.getConnections().filter(function (c) {
            return match(c.source, c.sourceOutput);
          });
          _iterator6 = _createForOfIteratorHelper$6(cons);
          _context6.prev = 2;
          _iterator6.s();
        case 4:
          if ((_step6 = _iterator6.n()).done) {
            _context6.next = 17;
            break;
          }
          con = _step6.value;
          _node3 = editor.getNode(con.source);
          _context6.next = 9;
          return mirrorOutgoers(editor, con.target, context);
        case 9:
          _context6.next = 11;
          return editor.removeConnection(con.id);
        case 11:
          _node3.removeOutput(con.sourceOutput);
          _node3.addInput(con.sourceOutput, context.createInput(con.sourceOutput));
          _context6.next = 15;
          return editor.addConnection(context.createConnection(editor.getNode(con.target), con.targetInput, _node3, con.sourceOutput));
        case 15:
          _context6.next = 4;
          break;
        case 17:
          _context6.next = 22;
          break;
        case 19:
          _context6.prev = 19;
          _context6.t0 = _context6["catch"](2);
          _iterator6.e(_context6.t0);
        case 22:
          _context6.prev = 22;
          _iterator6.f();
          return _context6.finish(22);
        case 25:
        case "end":
          return _context6.stop();
      }
    }, _callee6, null, [[2, 19, 22, 25]]);
  }));
  return _mirrorOutput.apply(this, arguments);
}
function removeInputConnections(_x15, _x16, _x17) {
  return _removeInputConnections.apply(this, arguments);
}
function _removeInputConnections() {
  _removeInputConnections = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee7(editor, nodeId, inputs) {
    var _iterator7, _step7, c;
    return _regeneratorRuntime__default["default"].wrap(function _callee7$(_context7) {
      while (1) switch (_context7.prev = _context7.next) {
        case 0:
          _iterator7 = _createForOfIteratorHelper$6(editor.getConnections().filter(function (c) {
            return c.target === nodeId;
          }));
          _context7.prev = 1;
          _iterator7.s();
        case 3:
          if ((_step7 = _iterator7.n()).done) {
            _context7.next = 11;
            break;
          }
          c = _step7.value;
          if (!(inputs && !inputs.includes(c.targetInput))) {
            _context7.next = 7;
            break;
          }
          return _context7.abrupt("continue", 9);
        case 7:
          _context7.next = 9;
          return editor.removeConnection(c.id);
        case 9:
          _context7.next = 3;
          break;
        case 11:
          _context7.next = 16;
          break;
        case 13:
          _context7.prev = 13;
          _context7.t0 = _context7["catch"](1);
          _iterator7.e(_context7.t0);
        case 16:
          _context7.prev = 16;
          _iterator7.f();
          return _context7.finish(16);
        case 19:
        case "end":
          return _context7.stop();
      }
    }, _callee7, null, [[1, 13, 16, 19]]);
  }));
  return _removeInputConnections.apply(this, arguments);
}
function removeOutputConnections(_x18, _x19, _x20) {
  return _removeOutputConnections.apply(this, arguments);
}
function _removeOutputConnections() {
  _removeOutputConnections = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee8(editor, nodeId, outputs) {
    var _iterator8, _step8, c;
    return _regeneratorRuntime__default["default"].wrap(function _callee8$(_context8) {
      while (1) switch (_context8.prev = _context8.next) {
        case 0:
          _iterator8 = _createForOfIteratorHelper$6(editor.getConnections().filter(function (c) {
            return c.source === nodeId;
          }));
          _context8.prev = 1;
          _iterator8.s();
        case 3:
          if ((_step8 = _iterator8.n()).done) {
            _context8.next = 11;
            break;
          }
          c = _step8.value;
          if (!(outputs && !outputs.includes(c.sourceOutput))) {
            _context8.next = 7;
            break;
          }
          return _context8.abrupt("continue", 9);
        case 7:
          _context8.next = 9;
          return editor.removeConnection(c.id);
        case 9:
          _context8.next = 3;
          break;
        case 11:
          _context8.next = 16;
          break;
        case 13:
          _context8.prev = 13;
          _context8.t0 = _context8["catch"](1);
          _iterator8.e(_context8.t0);
        case 16:
          _context8.prev = 16;
          _iterator8.f();
          return _context8.finish(16);
        case 19:
        case "end":
          return _context8.stop();
      }
    }, _callee8, null, [[1, 13, 16, 19]]);
  }));
  return _removeOutputConnections.apply(this, arguments);
}
function removeNodeWithConnections(_x21, _x22) {
  return _removeNodeWithConnections.apply(this, arguments);
}
function _removeNodeWithConnections() {
  _removeNodeWithConnections = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee9(editor, id) {
    var _i3, _arr, c;
    return _regeneratorRuntime__default["default"].wrap(function _callee9$(_context9) {
      while (1) switch (_context9.prev = _context9.next) {
        case 0:
          _i3 = 0, _arr = _toConsumableArray__default["default"](editor.getConnections());
        case 1:
          if (!(_i3 < _arr.length)) {
            _context9.next = 9;
            break;
          }
          c = _arr[_i3];
          if (!(c.source === id || c.target === id)) {
            _context9.next = 6;
            break;
          }
          _context9.next = 6;
          return editor.removeConnection(c.id);
        case 6:
          _i3++;
          _context9.next = 1;
          break;
        case 9:
          _context9.next = 11;
          return editor.removeNode(id);
        case 11:
        case "end":
          return _context9.stop();
      }
    }, _callee9);
  }));
  return _removeNodeWithConnections.apply(this, arguments);
}

var utils = /*#__PURE__*/Object.freeze({
  __proto__: null,
  copyToEditor: copyToEditor,
  mirrorPorts: mirrorPorts,
  mirrorIncomers: mirrorIncomers,
  mirrorInput: mirrorInput,
  mirrorOutgoers: mirrorOutgoers,
  mirrorOutput: mirrorOutput,
  removeInputConnections: removeInputConnections,
  removeOutputConnections: removeOutputConnections,
  removeNodeWithConnections: removeNodeWithConnections
});

function _createForOfIteratorHelper$5(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$5(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$5(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$5(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$5(o, minLen); }
function _arrayLikeToArray$5(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function getNodesParents(scopesNodes) {
  var nestedNodes = {};
  function processScope(scopeId, nodeIds) {
    (nodeIds || []).forEach(function (id) {
      if (!scopesNodes[id]) {
        nestedNodes[id] = [scopeId].concat(_toConsumableArray__default["default"](nestedNodes[id] || []));
      } else {
        processScope(scopeId, scopesNodes[id]);
      }
    });
  }
  for (var scopeId in scopesNodes) {
    processScope(scopeId, scopesNodes[scopeId]);
  }
  return nestedNodes;
}
function areClosuresCompatible(nodeParents, source, target) {
  return (nodeParents[source] || []).length <= (nodeParents[target] || []).length;
}
function treeToFlow$1(data, props) {
  console.time('treeToFlow');
  var graph = reteStructures.structures({
    nodes: _toConsumableArray__default["default"](data.nodes),
    connections: _toConsumableArray__default["default"](data.connections)
  });
  var roots = graph.nodes().filter(props.isStartNode);
  var nodeParents = getNodesParents(data.closures);
  var markers = {};
  function traverse(node) {
    var context = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    var outgoerConnections = graph.connections().filter(function (c) {
      return c.source === node.id;
    });
    var _loop = function _loop() {
      var out = outgoerConnections[index];
      var source = graph.nodes().find(function (n) {
        return n.id === out.source;
      });
      var m = props.isBlock(source) ? [].concat(_toConsumableArray__default["default"](context), [{
        index: index,
        context: out
      }]) : context;
      var node = graph.nodes().find(function (n) {
        return n.id === out.target;
      });
      markers[node.id] = m;
      traverse(node, m);
    };
    for (var index = 0; index < outgoerConnections.length; index++) {
      _loop();
    }
  }
  var _iterator = _createForOfIteratorHelper$5(roots),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var root = _step.value;
      traverse(root);
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  var mutableGraph = reteStructures.structures({
    nodes: graph.nodes(),
    connections: graph.connections()
  });
  var leaves = mutableGraph.leaves().nodes();
  var _iterator2 = _createForOfIteratorHelper$5(leaves),
    _step2;
  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var leaf = _step2.value;
      var leafMarkers = markers[leaf.id];
      var _iterator3 = _createForOfIteratorHelper$5(_toConsumableArray__default["default"](leafMarkers).reverse()),
        _step3;
      try {
        var _loop3 = function _loop3() {
          var _reconnect$;
          var marker = _step3.value;
          var isStillLeaf = mutableGraph.leaves().nodes().includes(leaf);
          if (!isStillLeaf) return 1; // continue
          var entries = Object.entries(markers);
          var next = mutableGraph.nodes().find(function (n) {
            return n.id === marker.context.source;
          }).id;
          var reconnect = entries.find(function (_ref) {
            var _ref2 = _slicedToArray__default["default"](_ref, 2),
              list = _ref2[1];
            return list.find(function (m) {
              return m.context.source === next && m.index === marker.index + 1;
            });
          });
          var nextContext = reconnect === null || reconnect === void 0 ? void 0 : (_reconnect$ = reconnect[1]) === null || _reconnect$ === void 0 ? void 0 : _reconnect$[(reconnect === null || reconnect === void 0 ? void 0 : reconnect[1].length) - 1].context;
          if (nextContext && areClosuresCompatible(nodeParents, leaf.id, nextContext.target)) {
            mutableGraph = reteStructures.structures({
              nodes: mutableGraph.nodes(),
              connections: [].concat(_toConsumableArray__default["default"](mutableGraph.connections().filter(function (c) {
                return c.id !== nextContext.id;
              })), [props.createConnection(leaf, 'bind', mutableGraph.nodes().find(function (n) {
                return n.id === nextContext.target;
              }), 'bind')])
            });
          }
        };
        for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
          if (_loop3()) continue;
        }
      } catch (err) {
        _iterator3.e(err);
      } finally {
        _iterator3.f();
      }
    }

    // normalize body indices
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }
  var _loop2 = function _loop2() {
    var c = _arr[_i];
    var source = mutableGraph.nodes().find(function (n) {
      return n.id === c.source;
    });
    var isBlock = props.isBlock(source);
    if (isBlock) {
      var parameterName = props.getBlockParameterName(source);
      var regex = parameterName.array ? new RegExp('^' + parameterName.key + '\\[(-{0,1}\\d+)\\]$') : parameterName.key;
      if (c.sourceOutput.match(regex)) {
        mutableGraph = reteStructures.structures({
          nodes: mutableGraph.nodes(),
          connections: [].concat(_toConsumableArray__default["default"](mutableGraph.connections().filter(function (con) {
            return con.id !== c.id;
          })), [props.createConnection(mutableGraph.nodes().find(function (n) {
            return n.id === c.source;
          }), 'bind', mutableGraph.nodes().find(function (n) {
            return n.id === c.target;
          }), 'bind')])
        });
      }
    }
  };
  for (var _i = 0, _arr = _toConsumableArray__default["default"](mutableGraph.connections()); _i < _arr.length; _i++) {
    _loop2();
  }
  console.timeEnd('treeToFlow');
  return {
    nodes: mutableGraph.nodes(),
    connections: mutableGraph.connections(),
    closures: data.closures
  };
}
function flowToTree$1(data, props) {
  console.time('flowToTree');
  var nodes = _toConsumableArray__default["default"](data.nodes);
  var connections = _toConsumableArray__default["default"](data.connections);
  var graph = reteStructures.structures({
    nodes: nodes,
    connections: connections
  });
  var nodeParents = getNodesParents(data.closures);
  var visited = new Map();
  function markBranchingScopes(node) {
    var scopes = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    if (visited.has(node.id)) return;
    var isBranchNode = props.isBranchNode(node);
    var outgoers = graph.outgoers(node.id);
    var _loop4 = function _loop4() {
      var scope = _arr2[_i2];
      if (scope.exit.id === node.id) scopes = scopes.filter(function (s) {
        return s !== scope;
      });
    };
    for (var _i2 = 0, _arr2 = _toConsumableArray__default["default"](scopes); _i2 < _arr2.length; _i2++) {
      _loop4();
    }
    var exit = isBranchNode && outgoers.nodes().length > 1 ? outgoers.nodes().map(function (n) {
      return graph.successors(n.id).union({
        nodes: [n],
        connections: []
      });
    }).reduce(function (a, b) {
      return a.intersection({
        nodes: b.nodes(),
        connections: b.connections()
      });
    }).roots().nodes()[0] : null;
    visited.set(node.id, scopes.map(function (s) {
      return s.start;
    }));
    var _iterator4 = _createForOfIteratorHelper$5(outgoers.nodes()),
      _step4;
    try {
      for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
        var outgoer = _step4.value;
        markBranchingScopes(outgoer, exit ? [].concat(_toConsumableArray__default["default"](scopes), [{
          start: node,
          exit: exit
        }]) : scopes);
      }
    } catch (err) {
      _iterator4.e(err);
    } finally {
      _iterator4.f();
    }
  }
  var roots = graph.nodes().filter(props.isRoot);
  var _iterator5 = _createForOfIteratorHelper$5(roots),
    _step5;
  try {
    for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
      var root = _step5.value;
      markBranchingScopes(root);
    }
  } catch (err) {
    _iterator5.e(err);
  } finally {
    _iterator5.f();
  }
  var indices = new Map();
  function traverse(node, startNode) {
    var markers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : new Set();
    var traversed = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : new Set();
    if (traversed.has(node.id)) return markers;
    traversed.add(node.id);
    var isStart = node.id === startNode.id;
    var incomers = graph.connections().filter(function (c) {
      return c.target === node.id;
    });
    var _loop5 = function _loop5() {
      var inc = incomers[index];
      var source = graph.nodes().find(function (n) {
        return n.id === inc.source;
      });

      // TODO subtract scopes
      var sameScope = (visited.get(inc.source) || []).length <= (visited.get(startNode.id) || []).length && areClosuresCompatible(nodeParents, inc.source, startNode.id);
      if (isStart && props.isBranchNode(source)) {
        return 1; // continue
      } else if (props.isBlock(source) && sameScope && props.isCompatible(source, startNode)) {
        markers.add(inc.source);
      } else {
        var n = graph.nodes().find(function (n) {
          return n.id === inc.source;
        });
        traverse(n, startNode, markers, traversed);
      }
    };
    for (var index = 0; index < incomers.length; index++) {
      if (_loop5()) continue;
    }
    return markers;
  }
  var mutableGraph = reteStructures.structures({
    nodes: graph.nodes(),
    connections: graph.connections()
  });
  var leaves = [];
  var processed = new Set();
  var _loop6 = function _loop6() {
    var leaf = leaves[0];
    var markers = traverse(leaf, leaf);
    processed.add(leaf.id);
    var _loop8 = function _loop8() {
      var marker = _Array$from[_i4];
      var predecessorsIds = mutableGraph.predecessors(marker).nodes().map(function (n) {
        return n.id;
      });
      var isMain = predecessorsIds.every(function (id) {
        return !markers.has(id);
      });
      if (isMain) {
        var index = (indices.get(marker) || 0) - 1;
        var _source = mutableGraph.nodes().find(function (n) {
          return n.id === marker;
        });
        var outputMeta = props.getBlockParameterName(_source);
        indices.set(marker, index);
        mutableGraph = reteStructures.structures({
          nodes: mutableGraph.nodes(),
          connections: [].concat(_toConsumableArray__default["default"](mutableGraph.connections().filter(function (c) {
            return c.target !== leaf.id;
          })), [props.createConnection(_source, outputMeta.array ? "".concat(outputMeta.key, "[").concat(index, "]") : outputMeta.key, leaf, 'bind')])
        });
        return 1; // break
      }
    };
    for (var _i4 = 0, _Array$from = Array.from(markers); _i4 < _Array$from.length; _i4++) {
      if (_loop8()) break;
    }
  };
  while (leaves = mutableGraph.difference({
    nodes: mutableGraph.nodes().filter(function (n) {
      return processed.has(n.id);
    }),
    connections: mutableGraph.connections()
  }).leaves().nodes(), leaves.length > 0) {
    _loop6();
  }

  // normalize body indices
  var _loop7 = function _loop7() {
    var c = _arr3[_i3];
    var minIndex = indices.get(c.source) || 0;
    var source = mutableGraph.nodes().find(function (n) {
      return n.id === c.source;
    });
    var outputMeta = props.getBlockParameterName(source);
    var bodyRegexp = outputMeta.array ? new RegExp('^' + outputMeta.key + '\\[(-{0,1}\\d+)\\]$') : outputMeta.key;
    if (c.sourceOutput.match(bodyRegexp)) {
      var index = c.sourceOutput.match(bodyRegexp)[1];
      mutableGraph = reteStructures.structures({
        nodes: mutableGraph.nodes(),
        connections: [].concat(_toConsumableArray__default["default"](mutableGraph.connections().filter(function (con) {
          return con.id !== c.id;
        })), [props.createConnection(mutableGraph.nodes().find(function (n) {
          return n.id === c.source;
        }), outputMeta.array ? "".concat(outputMeta.key, "[").concat(parseInt(index) - minIndex, "]") : outputMeta.key, mutableGraph.nodes().find(function (n) {
          return n.id === c.target;
        }), 'bind')])
      });
    }
  };
  for (var _i3 = 0, _arr3 = _toConsumableArray__default["default"](mutableGraph.connections()); _i3 < _arr3.length; _i3++) {
    _loop7();
  }
  console.timeEnd('flowToTree');
  return {
    nodes: mutableGraph.nodes(),
    connections: mutableGraph.connections()
  };
}

function _createForOfIteratorHelper$4(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$4(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$4(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$4(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$4(o, minLen); }
function _arrayLikeToArray$4(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function belongToSameClosure(source, target, _ref) {
  var editor = _ref.editor;
  if (source.parent === target.parent) return true;
  if (target.parent && belongToSameClosure(source, editor.getNode(target.parent), {
    editor: editor
  })) return true;
  return false;
}
function getClosures(node, context) {
  if (node.parent) {
    var closure = context.editor.getNode(node.parent);
    return [closure].concat(_toConsumableArray__default["default"](getClosures(closure, context)));
  }
  return [];
}
function getClosureDifference2(source, target, context) {
  var a = getClosures(source, context).reverse();
  var b = getClosures(target, context).reverse();
  var i = 0;
  for (; i < a.length; i++) {
    if (!a[i]) break;
    if (!b[i]) break;
    if (a[i] !== b[i]) break;
  }
  return {
    left: a.slice(i),
    right: b.slice(i)
  };
}
function getClosureDifference(source, target, context) {
  var a = getClosures(source, context);
  var b = getClosures(target, context);
  var i = 0;
  for (; i < a.length; i++) {
    if (a[i] && b[i] && a[i] === b[i]) continue;
  }
  return {
    left: a.slice(i),
    right: b.slice(i)
  };
}
function getClosureDifferenceOld(source, target, context) {
  var a = getClosures(source, context);
  var b = getClosures(target, context);
  return a.filter(function (x) {
    return !b.includes(x);
  });
}
function getBranchExit(node, keys, context) {
  var editor = context.editor;
  var _keys = _slicedToArray__default["default"](keys, 2),
    consKey = _keys[0],
    altKey = _keys[1]; // TODO all keys
  var alternate = editor.getConnections().find(function (c) {
    return c.source === node.id && c.sourceOutput === altKey;
  });
  if (!alternate) return null;
  var consequentSubgraph = reteStructures.structures(editor).successors(node.id, function (n, c) {
    return c.source === node.id ? c.sourceOutput === consKey : n.type === 'statement';
  });
  var alternateSubgraph = reteStructures.structures(editor).successors(node.id, function (n, c) {
    return c.source === node.id ? c.sourceOutput === altKey : n.type === 'statement';
  });
  var intersection = consequentSubgraph.intersection({
    getNodes: alternateSubgraph.nodes,
    getConnections: alternateSubgraph.connections
  });
  var roots = intersection.roots().nodes();
  if (roots.length > 1) throw new Error('Multiple roots in getClosureDifferenceOld');
  return roots[0] || null;
}
function flowToTree(options) {
  var _isRoot = options.isRoot,
    isBranch = options.isBranch,
    _isBlock = options.isBlock,
    isValidSubflow = options.isValidSubflow,
    _getBlockParameterName = options.getBlockParameterName;
  return /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
      var data, result, connectionsToRemove, connectionsToAdd, _iterator, _step, c, _iterator2, _step2, _c;
      return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            data = reteStructures.structures({
              nodes: context.editor.getNodes(),
              connections: context.editor.getConnections()
            }).filter(function (n) {
              return n.type === 'statement' || options.isRoot(n, context);
            });
            _context.prev = 1;
            result = flowToTree$1({
              nodes: data.nodes(),
              connections: data.connections(),
              closures: {}
            }, {
              isRoot: function isRoot(node) {
                return _isRoot(node, context);
              },
              isBlock: function isBlock(node) {
                return _isBlock(node, context);
              },
              getBlockParameterName: function getBlockParameterName(node) {
                return _getBlockParameterName(node, context);
              },
              isCompatible: function isCompatible(source, target) {
                return isValidSubflow(source, target, context);
              },
              isBranchNode: function isBranchNode(node) {
                return isBranch(node, context);
              },
              createConnection: function createConnection(s, o, t, i, opts) {
                if (!s.hasOutput(o)) s.addOutput(o, context.createOutput(o));
                return context.createConnection(s, o, t, i, opts);
              }
            });
            connectionsToRemove = context.editor.getConnections().filter(function (c) {
              var exists = result.connections.find(function (r) {
                return r.id === c.id;
              });
              var isTargetStatement = context.editor.getNode(c.target).type === 'statement';
              var isSourceStatement = context.editor.getNode(c.source).type === 'statement';
              return !exists && isTargetStatement && isSourceStatement;
            });
            connectionsToAdd = result.connections.filter(function (r) {
              return !context.editor.getConnections().find(function (c) {
                return c.id === r.id;
              });
            });
            console.log('RESULT', result, {
              connectionsToRemove: connectionsToRemove,
              connectionsToAdd: connectionsToAdd
            });
            _iterator = _createForOfIteratorHelper$4(connectionsToRemove);
            _context.prev = 7;
            _iterator.s();
          case 9:
            if ((_step = _iterator.n()).done) {
              _context.next = 15;
              break;
            }
            c = _step.value;
            _context.next = 13;
            return context.editor.removeConnection(c.id);
          case 13:
            _context.next = 9;
            break;
          case 15:
            _context.next = 20;
            break;
          case 17:
            _context.prev = 17;
            _context.t0 = _context["catch"](7);
            _iterator.e(_context.t0);
          case 20:
            _context.prev = 20;
            _iterator.f();
            return _context.finish(20);
          case 23:
            _iterator2 = _createForOfIteratorHelper$4(connectionsToAdd);
            _context.prev = 24;
            _iterator2.s();
          case 26:
            if ((_step2 = _iterator2.n()).done) {
              _context.next = 32;
              break;
            }
            _c = _step2.value;
            _context.next = 30;
            return context.editor.addConnection(_c);
          case 30:
            _context.next = 26;
            break;
          case 32:
            _context.next = 37;
            break;
          case 34:
            _context.prev = 34;
            _context.t1 = _context["catch"](24);
            _iterator2.e(_context.t1);
          case 37:
            _context.prev = 37;
            _iterator2.f();
            return _context.finish(37);
          case 40:
            _context.next = 46;
            break;
          case 42:
            _context.prev = 42;
            _context.t2 = _context["catch"](1);
            console.error(_context.t2);
            throw _context.t2;
          case 46:
          case "end":
            return _context.stop();
        }
      }, _callee, null, [[1, 42], [7, 17, 20, 23], [24, 34, 37, 40]]);
    }));
    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }();
}

// function findLastIndex<T>(array: T[], predicate: (value: T, index: number, obj: T[]) => boolean) {
//   for (let i = array.length - 1; i >= 0; i--) {
//     if (predicate(array[i], i, array)) return i
//   }
//   return -1
// }

function reconnect(_x2, _x3, _x4, _x5, _x6) {
  return _reconnect.apply(this, arguments);
}
function _reconnect() {
  _reconnect = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(block, flow, array, propertyName, context) {
    var editor, createOutput, createConnection, _iterator3, _step3, c, nextIndex, key;
    return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          editor = context.editor, createOutput = context.createOutput, createConnection = context.createConnection;
          _iterator3 = _createForOfIteratorHelper$4(editor.getConnections().filter(function (c) {
            return c.target === flow.id && c.targetInput === BIND_KEY;
          }));
          _context2.prev = 2;
          _iterator3.s();
        case 4:
          if ((_step3 = _iterator3.n()).done) {
            _context2.next = 10;
            break;
          }
          c = _step3.value;
          _context2.next = 8;
          return editor.removeConnection(c.id);
        case 8:
          _context2.next = 4;
          break;
        case 10:
          _context2.next = 15;
          break;
        case 12:
          _context2.prev = 12;
          _context2.t0 = _context2["catch"](2);
          _iterator3.e(_context2.t0);
        case 15:
          _context2.prev = 15;
          _iterator3.f();
          return _context2.finish(15);
        case 18:
          nextIndex = editor.getConnections().filter(function (c) {
            return c.source === block.id && c.sourceOutput.match(array ? new RegExp("^".concat(propertyName, "\\[.*\\]$")) : propertyName);
          }).length;
          key = array ? "".concat(propertyName, "[").concat(nextIndex, "]") : propertyName;
          if (!block.hasOutput(key)) block.addOutput(key, createOutput(key));
          _context2.next = 23;
          return editor.addConnection(createConnection(block, key, flow, BIND_KEY));
        case 23:
        case "end":
          return _context2.stop();
      }
    }, _callee2, null, [[2, 12, 15, 18]]);
  }));
  return _reconnect.apply(this, arguments);
}

function sanitize(s) {
  return s.trim().replace(/\n +/g, '\n');
}
function stringifyChart(connections, closures) {
  // https://mermaid.live
  return sanitize("\nflowchart LR\n\n".concat(connections.map(function (c) {
    return "".concat(c.source, " -->|").concat(c.sourceOutput, "| ").concat(c.target);
  }).join('\n'), "\n\n").concat(Object.entries(closures).map(function (_ref4) {
    var _ref5 = _slicedToArray__default["default"](_ref4, 2),
      id = _ref5[0],
      nodes = _ref5[1];
    return "subgraph ".concat(id, "\n").concat(Array.from(nodes).join('\n'), "\nend");
  }).join('\n'), "\n"));
}

function ownKeys$1(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread$1(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys$1(Object(t), !0).forEach(function (r) { _defineProperty__default["default"](e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _createForOfIteratorHelper$3(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$3(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$3(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$3(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$3(o, minLen); }
function _arrayLikeToArray$3(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
// reusable
function forEach(match, command) {
  return /*#__PURE__*/function () {
    var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
      var _iterator, _step, _node, act;
      return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _iterator = _createForOfIteratorHelper$3(context.editor.getNodes().filter(match));
            _context.prev = 1;
            _iterator.s();
          case 3:
            if ((_step = _iterator.n()).done) {
              _context.next = 13;
              break;
            }
            _node = _step.value;
            _context.next = 7;
            return command(_node, context);
          case 7:
            act = _context.sent;
            if (!act) {
              _context.next = 11;
              break;
            }
            _context.next = 11;
            return act(context);
          case 11:
            _context.next = 3;
            break;
          case 13:
            _context.next = 18;
            break;
          case 15:
            _context.prev = 15;
            _context.t0 = _context["catch"](1);
            _iterator.e(_context.t0);
          case 18:
            _context.prev = 18;
            _iterator.f();
            return _context.finish(18);
          case 21:
          case "end":
            return _context.stop();
        }
      }, _callee, null, [[1, 15, 18, 21]]);
    }));
    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }();
}

// reusable
function createSuperStatement(_x2, _x3, _x4) {
  return _createSuperStatement.apply(this, arguments);
}

// reusable
function _createSuperStatement() {
  _createSuperStatement = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee15(context, name, parent) {
    var editor, createNode, node;
    return _regeneratorRuntime__default["default"].wrap(function _callee15$(_context20) {
      while (1) switch (_context20.prev = _context20.next) {
        case 0:
          editor = context.editor, createNode = context.createNode;
          node = createNode(name);
          node.parent = parent;
          node.type = 'statement';
          _context20.next = 6;
          return editor.addNode(node);
        case 6:
          return _context20.abrupt("return", node);
        case 7:
        case "end":
          return _context20.stop();
      }
    }, _callee15);
  }));
  return _createSuperStatement.apply(this, arguments);
}
function expressionToExpressionStatement(_x5, _x6, _x7, _x8) {
  return _expressionToExpressionStatement.apply(this, arguments);
}

// reusable
function _expressionToExpressionStatement() {
  _expressionToExpressionStatement = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee16(context, node, input, createStatement) {
    var editor, createConnection, createOutput, statement, _getInputNode, _getInputNode2, expression, expressionConnection;
    return _regeneratorRuntime__default["default"].wrap(function _callee16$(_context21) {
      while (1) switch (_context21.prev = _context21.next) {
        case 0:
          editor = context.editor, createConnection = context.createConnection, createOutput = context.createOutput;
          _context21.next = 3;
          return createStatement();
        case 3:
          statement = _context21.sent;
          _getInputNode = getInputNode(context, node.id, input), _getInputNode2 = _slicedToArray__default["default"](_getInputNode, 2), expression = _getInputNode2[0], expressionConnection = _getInputNode2[1];
          _context21.next = 7;
          return editor.removeConnection(expressionConnection.id);
        case 7:
          node.removeInput(input);
          node.addOutput(input, createOutput(input));
          _context21.next = 11;
          return editor.addConnection(createConnection(expression, expressionConnection.sourceOutput, statement, 'expression'));
        case 11:
          _context21.next = 13;
          return editor.addConnection(createConnection(node, input, statement, BIND_KEY));
        case 13:
          return _context21.abrupt("return", statement);
        case 14:
        case "end":
          return _context21.stop();
      }
    }, _callee16);
  }));
  return _expressionToExpressionStatement.apply(this, arguments);
}
function patchPlaceholderPorts(match) {
  return /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
      var editor, createInput, createOutput, createConnection, _iterator2, _step2, _node2, result, _result$inputs, inputs, _result$outputs, outputs, _iterator3, _step3, inp, _iterator4, _step4, out, _getOutputNode, _getOutputNode2, existingNode, end;
      return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            editor = context.editor, createInput = context.createInput, createOutput = context.createOutput, createConnection = context.createConnection;
            _iterator2 = _createForOfIteratorHelper$3(editor.getNodes());
            _context2.prev = 2;
            _iterator2.s();
          case 4:
            if ((_step2 = _iterator2.n()).done) {
              _context2.next = 36;
              break;
            }
            _node2 = _step2.value;
            result = match(_node2);
            if (!result) {
              _context2.next = 34;
              break;
            }
            _result$inputs = result.inputs, inputs = _result$inputs === void 0 ? [] : _result$inputs, _result$outputs = result.outputs, outputs = _result$outputs === void 0 ? [] : _result$outputs;
            _iterator3 = _createForOfIteratorHelper$3(inputs);
            try {
              for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                inp = _step3.value;
                if (!_node2.hasInput(inp.key)) _node2.addInput(inp.key, createInput(inp.key));
              }
            } catch (err) {
              _iterator3.e(err);
            } finally {
              _iterator3.f();
            }
            _iterator4 = _createForOfIteratorHelper$3(outputs);
            _context2.prev = 12;
            _iterator4.s();
          case 14:
            if ((_step4 = _iterator4.n()).done) {
              _context2.next = 26;
              break;
            }
            out = _step4.value;
            if (!_node2.hasOutput(out.key)) {
              _node2.addOutput(out.key, createOutput(out.key));
            }
            _getOutputNode = getOutputNode(context, _node2.id, out.key, false), _getOutputNode2 = _slicedToArray__default["default"](_getOutputNode, 1), existingNode = _getOutputNode2[0];
            if (!(!existingNode && out.flow)) {
              _context2.next = 24;
              break;
            }
            _context2.next = 21;
            return createSuperStatement(context, 'Placeholder');
          case 21:
            end = _context2.sent;
            _context2.next = 24;
            return editor.addConnection(createConnection(_node2, out.key, end, BIND_KEY));
          case 24:
            _context2.next = 14;
            break;
          case 26:
            _context2.next = 31;
            break;
          case 28:
            _context2.prev = 28;
            _context2.t0 = _context2["catch"](12);
            _iterator4.e(_context2.t0);
          case 31:
            _context2.prev = 31;
            _iterator4.f();
            return _context2.finish(31);
          case 34:
            _context2.next = 4;
            break;
          case 36:
            _context2.next = 41;
            break;
          case 38:
            _context2.prev = 38;
            _context2.t1 = _context2["catch"](2);
            _iterator2.e(_context2.t1);
          case 41:
            _context2.prev = 41;
            _iterator2.f();
            return _context2.finish(41);
          case 44:
          case "end":
            return _context2.stop();
        }
      }, _callee2, null, [[2, 38, 41, 44], [12, 28, 31, 34]]);
    }));
    return function (_x9) {
      return _ref2.apply(this, arguments);
    };
  }();
}

// reusable
function mirrorRight(match, ignore) {
  return /*#__PURE__*/function () {
    var _ref3 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
      var editor, mirrorContext;
      return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            editor = context.editor;
            mirrorContext = _objectSpread$1({
              ignore: ignore
            }, context);
            _context3.next = 4;
            return mirrorOutput(editor, function (id, key) {
              return match(editor.getNode(id), key);
            }, mirrorContext);
          case 4:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }));
    return function (_x10) {
      return _ref3.apply(this, arguments);
    };
  }();
}

// reusable
function mirrorLeft(match, ignore) {
  return /*#__PURE__*/function () {
    var _ref4 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4(context) {
      var editor, mirrorContext;
      return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            editor = context.editor;
            mirrorContext = _objectSpread$1({
              ignore: ignore
            }, context);
            _context4.next = 4;
            return mirrorInput(editor, function (id, key) {
              return match(editor.getNode(id), key);
            }, mirrorContext);
          case 4:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }));
    return function (_x11) {
      return _ref4.apply(this, arguments);
    };
  }();
}

// reusable
function simplifyIdentifiers(matchProducer, matchConsumer, producerMatched, consumerMatched) {
  return /*#__PURE__*/function () {
    var _ref5 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee5(context) {
      var editor, createConnection, producers, consumers, _loop, _i, _arr, findIdentifier, _i2, _consumers, consumer, consumerNode, producer, producerNode;
      return _regeneratorRuntime__default["default"].wrap(function _callee5$(_context6) {
        while (1) switch (_context6.prev = _context6.next) {
          case 0:
            findIdentifier = function _findIdentifier(identifier, scope) {
              var allMatches = producers.filter(function (p) {
                return p.identifier === identifier;
              });
              if (allMatches.length === 0) return null;
              var scopedMatches = allMatches.filter(function (m) {
                return editor.getNode(m.node).parent === scope;
              });
              if (scopedMatches.length === 1) return scopedMatches[0];
              if (scopedMatches.length > 1) {
                console.warn({
                  scopedMatches: scopedMatches
                });
                throw new Error('found more than 1 identifier');
              }
              if (!scope) return null;
              return findIdentifier(identifier, editor.getNode(scope).parent);
            };
            editor = context.editor, createConnection = context.createConnection;
            producers = [];
            consumers = [];
            _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
              var identifier, inpCon, _inpCon, target, targetInput;
              return _regeneratorRuntime__default["default"].wrap(function _loop$(_context5) {
                while (1) switch (_context5.prev = _context5.next) {
                  case 0:
                    identifier = _arr[_i];
                    if (!matchProducer(identifier, context)) {
                      _context5.next = 11;
                      break;
                    }
                    inpCon = editor.getConnections().find(function (c) {
                      return c.target === identifier.id && c.targetInput === BIND_KEY;
                    });
                    if (inpCon) {
                      _context5.next = 5;
                      break;
                    }
                    throw new Error('inpCon');
                  case 5:
                    producers.push({
                      identifier: identifier.data.name,
                      identifierNode: identifier.id,
                      node: inpCon.source,
                      output: inpCon.sourceOutput
                    });
                    _context5.next = 8;
                    return removeNodeWithConnections(editor, identifier.id);
                  case 8:
                    if (producerMatched) producerMatched(identifier, inpCon, context);
                    _context5.next = 18;
                    break;
                  case 11:
                    if (!matchConsumer(identifier, context)) {
                      _context5.next = 18;
                      break;
                    }
                    _inpCon = editor.getConnections().find(function (c) {
                      return c.source === identifier.id && c.sourceOutput === BIND_KEY;
                    });
                    if (_inpCon) {
                      _context5.next = 15;
                      break;
                    }
                    throw new Error('inpCon');
                  case 15:
                    target = _inpCon.target, targetInput = _inpCon.targetInput;
                    consumers.push({
                      identifier: identifier.data.name,
                      identifierNode: identifier.id,
                      node: target,
                      input: targetInput
                    });
                    if (consumerMatched) consumerMatched(identifier, _inpCon, context);
                  case 18:
                  case "end":
                    return _context5.stop();
                }
              }, _loop);
            });
            _i = 0, _arr = _toConsumableArray__default["default"](editor.getNodes());
          case 6:
            if (!(_i < _arr.length)) {
              _context6.next = 11;
              break;
            }
            return _context6.delegateYield(_loop(), "t0", 8);
          case 8:
            _i++;
            _context6.next = 6;
            break;
          case 11:
            _i2 = 0, _consumers = consumers;
          case 12:
            if (!(_i2 < _consumers.length)) {
              _context6.next = 25;
              break;
            }
            consumer = _consumers[_i2];
            consumerNode = editor.getNode(consumer.node);
            producer = findIdentifier(consumer.identifier, consumerNode.parent);
            if (!producer) {
              _context6.next = 22;
              break;
            }
            producerNode = editor.getNode(producer.node);
            _context6.next = 20;
            return removeNodeWithConnections(editor, consumer.identifierNode);
          case 20:
            _context6.next = 22;
            return editor.addConnection(createConnection(producerNode, producer.output, consumerNode, consumer.input));
          case 22:
            _i2++;
            _context6.next = 12;
            break;
          case 25:
          case "end":
            return _context6.stop();
        }
      }, _callee5);
    }));
    return function (_x12) {
      return _ref5.apply(this, arguments);
    };
  }();
}

// reusable
function convertNodeToInput(_x13, _x14, _x15) {
  return _convertNodeToInput.apply(this, arguments);
} // reusable
function _convertNodeToInput() {
  _convertNodeToInput = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee17(editor, match, createControl) {
    var _iterator11, _step11, _loop6;
    return _regeneratorRuntime__default["default"].wrap(function _callee17$(_context23) {
      while (1) switch (_context23.prev = _context23.next) {
        case 0:
          _iterator11 = _createForOfIteratorHelper$3(editor.getNodes().filter(match));
          _context23.prev = 1;
          _loop6 = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop6() {
            var node, outputCons, outputConnection, target, input;
            return _regeneratorRuntime__default["default"].wrap(function _loop6$(_context22) {
              while (1) switch (_context22.prev = _context22.next) {
                case 0:
                  node = _step11.value;
                  outputCons = editor.getConnections().filter(function (c) {
                    return c.source === node.id;
                  });
                  if (!(outputCons.length === 0)) {
                    _context22.next = 4;
                    break;
                  }
                  return _context22.abrupt("return", 1);
                case 4:
                  if (!(outputCons.length > 1)) {
                    _context22.next = 6;
                    break;
                  }
                  throw new Error('multiple outgoers are not supported');
                case 6:
                  outputConnection = outputCons[0];
                  target = editor.getNode(outputConnection.target);
                  input = target.inputs[outputConnection.targetInput];
                  if (input) {
                    _context22.next = 12;
                    break;
                  }
                  console.warn({
                    node: node,
                    target: target,
                    input: input,
                    con: outputConnection
                  });
                  throw new Error('cannot find input');
                case 12:
                  input.addControl(createControl(node));
                  _context22.next = 15;
                  return removeNodeWithConnections(editor, node.id);
                case 15:
                case "end":
                  return _context22.stop();
              }
            }, _loop6);
          });
          _iterator11.s();
        case 4:
          if ((_step11 = _iterator11.n()).done) {
            _context23.next = 10;
            break;
          }
          return _context23.delegateYield(_loop6(), "t0", 6);
        case 6:
          if (!_context23.t0) {
            _context23.next = 8;
            break;
          }
          return _context23.abrupt("continue", 8);
        case 8:
          _context23.next = 4;
          break;
        case 10:
          _context23.next = 15;
          break;
        case 12:
          _context23.prev = 12;
          _context23.t1 = _context23["catch"](1);
          _iterator11.e(_context23.t1);
        case 15:
          _context23.prev = 15;
          _iterator11.f();
          return _context23.finish(15);
        case 18:
        case "end":
          return _context23.stop();
      }
    }, _callee17, null, [[1, 12, 15, 18]]);
  }));
  return _convertNodeToInput.apply(this, arguments);
}
function simplifyLiterals(match, createControl) {
  return /*#__PURE__*/function () {
    var _ref6 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee6(context) {
      var editor;
      return _regeneratorRuntime__default["default"].wrap(function _callee6$(_context7) {
        while (1) switch (_context7.prev = _context7.next) {
          case 0:
            editor = context.editor;
            _context7.next = 3;
            return convertNodeToInput(editor, match, createControl);
          case 3:
          case "end":
            return _context7.stop();
        }
      }, _callee6);
    }));
    return function (_x16) {
      return _ref6.apply(this, arguments);
    };
  }();
}

// reusable

function getInputNode(_ref7, nodeId, inputKey) {
  var editor = _ref7.editor;
  var mandatory = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
  var connections = editor.getConnections().filter(function (c) {
    return c.target === nodeId && c.targetInput === inputKey;
  });
  if (mandatory && !connections.length) {
    console.warn({
      nodeId: nodeId,
      inputKey: inputKey
    });
    throw new Error('doesnt have input connection');
  }
  if (connections.length > 1) throw new Error('found more than 1 connection');
  var connection = connections[0];
  return connection ? [editor.getNode(connection.source), connection] : [undefined, undefined];
}

// reusable

function getOutputNode(_ref8, nodeId, outputKey) {
  var editor = _ref8.editor;
  var mandatory = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
  var connections = editor.getConnections().filter(function (c) {
    return c.source === nodeId && c.sourceOutput === outputKey;
  });
  if (mandatory && !connections.length) {
    // console.warn({ nodeId, outputKey, node: editor.getNode(nodeId) })
    throw new Error('doesnt have output connection');
  }
  if (connections.length > 1) throw new Error('found more than 1 connection');
  var connection = connections[0];
  return connection ? [editor.getNode(connection.target), connection] : [undefined, undefined];
}
function findLabeledStatement(_ref9, nodeId) {
  var editor = _ref9.editor;
  var optional = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  function findLabel(nodeId, label) {
    var cons = editor.getConnections().filter(function (c) {
      return c.target === nodeId && !c.isLoop;
    });
    var nodes = cons.map(function (c) {
      return editor.getNode(c.source);
    });
    var labeledConn = cons.find(function (c) {
      var n = editor.getNode(c.source);
      if (n.label === 'LabeledStatement' && c.sourceOutput === 'body') {
        if (label) {
          var _getOutputNode3 = getOutputNode({
              editor: editor
            }, n.id, 'label'),
            _getOutputNode4 = _slicedToArray__default["default"](_getOutputNode3, 1),
            _labelNode = _getOutputNode4[0];
          return _labelNode.data.name === label;
        }
        return true;
      }
    });
    if (labeledConn) return editor.getNode(labeledConn.source);
    var _iterator5 = _createForOfIteratorHelper$3(nodes),
      _step5;
    try {
      for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
        var n = _step5.value;
        var found = findLabel(n.id, label);
        if (found) return found;
      }
    } catch (err) {
      _iterator5.e(err);
    } finally {
      _iterator5.f();
    }
    return null;
  }
  var _getOutputNode5 = getOutputNode({
      editor: editor
    }, nodeId, 'label', false),
    _getOutputNode6 = _slicedToArray__default["default"](_getOutputNode5, 1),
    labelNode = _getOutputNode6[0];
  var label = labelNode ? String(labelNode.data.name) : undefined;
  var labeledStatement = findLabel(nodeId, label);
  if (!optional && !labeledStatement) throw new Error('Could not find labeled statement');
  return labeledStatement;
}
function rename(rename, update) {
  return /*#__PURE__*/function () {
    var _ref11 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee7(_ref10) {
      var editor, _i3, _arr2, _node3, label;
      return _regeneratorRuntime__default["default"].wrap(function _callee7$(_context8) {
        while (1) switch (_context8.prev = _context8.next) {
          case 0:
            editor = _ref10.editor;
            for (_i3 = 0, _arr2 = _toConsumableArray__default["default"](editor.getNodes()); _i3 < _arr2.length; _i3++) {
              _node3 = _arr2[_i3];
              label = rename(_node3);
              if (label) {
                _node3.label = label;
                update === null || update === void 0 ? void 0 : update(_node3);
              }
            }
          case 2:
          case "end":
            return _context8.stop();
        }
      }, _callee7);
    }));
    return function (_x17) {
      return _ref11.apply(this, arguments);
    };
  }();
}
function markClosures(props) {
  function traverse(_x18, _x19, _x20) {
    return _traverse.apply(this, arguments);
  }
  function _traverse() {
    _traverse = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee9(node, context, closureId) {
      var _closure;
      var editor, createNode, cons, nodes, closure, _iterator6, _step6, _closure2, _node4;
      return _regeneratorRuntime__default["default"].wrap(function _callee9$(_context10) {
        while (1) switch (_context10.prev = _context10.next) {
          case 0:
            editor = context.editor, createNode = context.createNode;
            cons = editor.getConnections().filter(function (c) {
              return c.source === node.id;
            });
            nodes = cons.map(function (c) {
              return editor.getNode(c.target);
            });
            closure = null;
            if (!props.isClosure(node)) {
              _context10.next = 11;
              break;
            }
            closure = createNode('Closure');
            closure.parent = closureId;
            _context10.next = 9;
            return editor.addNode(closure);
          case 9:
            _context10.next = 12;
            break;
          case 11:
            closure = closureId ? editor.getNode(closureId) : null;
          case 12:
            node.parent = (_closure = closure) === null || _closure === void 0 ? void 0 : _closure.id;
            _iterator6 = _createForOfIteratorHelper$3(nodes);
            _context10.prev = 14;
            _iterator6.s();
          case 16:
            if ((_step6 = _iterator6.n()).done) {
              _context10.next = 22;
              break;
            }
            _node4 = _step6.value;
            _context10.next = 20;
            return traverse(_node4, context, (_closure2 = closure) === null || _closure2 === void 0 ? void 0 : _closure2.id);
          case 20:
            _context10.next = 16;
            break;
          case 22:
            _context10.next = 27;
            break;
          case 24:
            _context10.prev = 24;
            _context10.t0 = _context10["catch"](14);
            _iterator6.e(_context10.t0);
          case 27:
            _context10.prev = 27;
            _iterator6.f();
            return _context10.finish(27);
          case 30:
          case "end":
            return _context10.stop();
        }
      }, _callee9, null, [[14, 24, 27, 30]]);
    }));
    return _traverse.apply(this, arguments);
  }
  return /*#__PURE__*/function () {
    var _ref12 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee8(context) {
      var startNode;
      return _regeneratorRuntime__default["default"].wrap(function _callee8$(_context9) {
        while (1) switch (_context9.prev = _context9.next) {
          case 0:
            startNode = context.editor.getNodes().find(props.isStart);
            if (startNode) {
              _context9.next = 3;
              break;
            }
            throw new Error('start node not found');
          case 3:
            _context9.next = 5;
            return traverse(startNode, context);
          case 5:
          case "end":
            return _context9.stop();
        }
      }, _callee8);
    }));
    return function (_x21) {
      return _ref12.apply(this, arguments);
    };
  }();
}
function debugNodeId(node) {
  return [node.label, node.id].join('_');
}
function treeToFlow(props) {
  return /*#__PURE__*/function () {
    var _ref13 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee10(context) {
      var startParents, collectRootDescendants, groups, collectedConnections, _iterator7, _step7, _loop2, _i4, _Array$from, c, _i5, _Array$from2, _c;
      return _regeneratorRuntime__default["default"].wrap(function _callee10$(_context12) {
        while (1) switch (_context12.prev = _context12.next) {
          case 0:
            collectRootDescendants = function _collectRootDescendan(parent) {
              var match = context.editor.getNodes().filter(function (n) {
                return n.parent === parent && !startParents.includes(n.id);
              });
              return [].concat(_toConsumableArray__default["default"](match), _toConsumableArray__default["default"](match.filter(function (n) {
                return n.label === 'Closure';
              }).flatMap(function (n) {
                return collectRootDescendants(n.id);
              })));
            };
            startParents = context.editor.getNodes().filter(props.isStart).map(function (n) {
              return n.parent;
            });
            groups = context.editor.getNodes().filter(props.isStart).map(function (n) {
              return {
                start: n,
                nodes: collectRootDescendants(n.parent)
              };
            });
            collectedConnections = {
              remove: [],
              add: []
            };
            _iterator7 = _createForOfIteratorHelper$3(groups);
            _context12.prev = 5;
            _loop2 = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop2() {
              var _collectedConnections, _collectedConnections2;
              var _step7$value, start, nodes, data, result, connectionsToRemove, connectionsToAdd;
              return _regeneratorRuntime__default["default"].wrap(function _loop2$(_context11) {
                while (1) switch (_context11.prev = _context11.next) {
                  case 0:
                    _step7$value = _step7.value, start = _step7$value.start, nodes = _step7$value.nodes;
                    data = reteStructures.structures({
                      nodes: nodes,
                      connections: context.editor.getConnections()
                    }).filter(function (n) {
                      return n.type === 'statement' || props.isStart(n);
                    });
                    result = treeToFlow$1({
                      nodes: data.nodes(),
                      connections: data.connections(),
                      closures: context.editor.getNodes().filter(function (n) {
                        return n.label === 'Closure';
                      }).map(function (n) {
                        var children = context.editor.getNodes().filter(function (c) {
                          return c.parent === n.id;
                        });
                        return [n.id, children.map(function (c) {
                          return c.id;
                        })];
                      }).reduce(function (obj, _ref14) {
                        var _ref15 = _slicedToArray__default["default"](_ref14, 2),
                          id = _ref15[0],
                          children = _ref15[1];
                        return children.length ? _objectSpread$1(_objectSpread$1({}, obj), {}, _defineProperty__default["default"]({}, id, new Set(children))) : obj;
                      }, {})
                    }, {
                      isStartNode: props.isStart,
                      isBlock: function isBlock(n) {
                        return props.isSequence(n);
                      },
                      getBlockParameterName: function getBlockParameterName(n) {
                        return props.getBlockParameterName(n, context);
                      },
                      createConnection: context.createConnection
                    });
                    connectionsToRemove = data.connections().filter(function (c) {
                      var exists = result.connections.find(function (r) {
                        return r.id === c.id;
                      });
                      var isTargetStatement = context.editor.getNode(c.target).type === 'statement';
                      return !exists && isTargetStatement;
                    });
                    connectionsToAdd = result.connections.filter(function (r) {
                      return !data.connections().find(function (c) {
                        return c.id === r.id;
                      });
                    });
                    (_collectedConnections = collectedConnections.remove).push.apply(_collectedConnections, _toConsumableArray__default["default"](connectionsToRemove));
                    (_collectedConnections2 = collectedConnections.add).push.apply(_collectedConnections2, _toConsumableArray__default["default"](connectionsToAdd));
                    console.log("".concat(start.label, "[").concat(start.id, "]\n"), stringifyChart(result.connections.map(function (c) {
                      return _objectSpread$1(_objectSpread$1({}, c), {}, {
                        source: debugNodeId(context.editor.getNode(c.source)),
                        target: debugNodeId(context.editor.getNode(c.target))
                      });
                    }), Object.fromEntries(Object.entries(result.closures).map(function (_ref16) {
                      var _ref17 = _slicedToArray__default["default"](_ref16, 2),
                        id = _ref17[0],
                        c = _ref17[1];
                      return [debugNodeId(context.editor.getNode(id)), new Set(Array.from(c).filter(function (id) {
                        return result.nodes.find(function (n) {
                          return n.id === id;
                        }) || result.closures[id];
                      }).map(function (id) {
                        return debugNodeId(context.editor.getNode(id));
                      }))];
                    }))));
                  case 8:
                  case "end":
                    return _context11.stop();
                }
              }, _loop2);
            });
            _iterator7.s();
          case 8:
            if ((_step7 = _iterator7.n()).done) {
              _context12.next = 12;
              break;
            }
            return _context12.delegateYield(_loop2(), "t0", 10);
          case 10:
            _context12.next = 8;
            break;
          case 12:
            _context12.next = 17;
            break;
          case 14:
            _context12.prev = 14;
            _context12.t1 = _context12["catch"](5);
            _iterator7.e(_context12.t1);
          case 17:
            _context12.prev = 17;
            _iterator7.f();
            return _context12.finish(17);
          case 20:
            _i4 = 0, _Array$from = Array.from(new Set(collectedConnections.remove));
          case 21:
            if (!(_i4 < _Array$from.length)) {
              _context12.next = 28;
              break;
            }
            c = _Array$from[_i4];
            _context12.next = 25;
            return context.editor.removeConnection(c.id);
          case 25:
            _i4++;
            _context12.next = 21;
            break;
          case 28:
            _i5 = 0, _Array$from2 = Array.from(new Set(collectedConnections.add));
          case 29:
            if (!(_i5 < _Array$from2.length)) {
              _context12.next = 36;
              break;
            }
            _c = _Array$from2[_i5];
            _context12.next = 33;
            return context.editor.addConnection(_c);
          case 33:
            _i5++;
            _context12.next = 29;
            break;
          case 36:
          case "end":
            return _context12.stop();
        }
      }, _callee10, null, [[5, 14, 17, 20]]);
    }));
    return function (_x22) {
      return _ref13.apply(this, arguments);
    };
  }();
}

// reusable
function removeRedunantNodes(match) {
  var reconnect = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  return /*#__PURE__*/function () {
    var _ref19 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee11(_ref18) {
      var editor, createConnection, _loop3, _i6, _arr3;
      return _regeneratorRuntime__default["default"].wrap(function _callee11$(_context14) {
        while (1) switch (_context14.prev = _context14.next) {
          case 0:
            editor = _ref18.editor, createConnection = _ref18.createConnection;
            _loop3 = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop3() {
              var node, inputs, outputs, _iterator8, _step8, input, c;
              return _regeneratorRuntime__default["default"].wrap(function _loop3$(_context13) {
                while (1) switch (_context13.prev = _context13.next) {
                  case 0:
                    node = _arr3[_i6];
                    if (!match(node)) {
                      _context13.next = 28;
                      break;
                    }
                    if (!reconnect) {
                      _context13.next = 26;
                      break;
                    }
                    inputs = editor.getConnections().filter(function (c) {
                      return c.target === node.id;
                    });
                    outputs = editor.getConnections().filter(function (c) {
                      return c.source === node.id;
                    });
                    if (!(outputs.length > 1)) {
                      _context13.next = 7;
                      break;
                    }
                    throw new Error('Multiple outputs are not allowed');
                  case 7:
                    if (!outputs[0]) {
                      _context13.next = 26;
                      break;
                    }
                    _iterator8 = _createForOfIteratorHelper$3(inputs);
                    _context13.prev = 9;
                    _iterator8.s();
                  case 11:
                    if ((_step8 = _iterator8.n()).done) {
                      _context13.next = 18;
                      break;
                    }
                    input = _step8.value;
                    c = createConnection(editor.getNode(input.source), input.sourceOutput, editor.getNode(outputs[0].target), outputs[0].targetInput);
                    _context13.next = 16;
                    return editor.addConnection(c);
                  case 16:
                    _context13.next = 11;
                    break;
                  case 18:
                    _context13.next = 23;
                    break;
                  case 20:
                    _context13.prev = 20;
                    _context13.t0 = _context13["catch"](9);
                    _iterator8.e(_context13.t0);
                  case 23:
                    _context13.prev = 23;
                    _iterator8.f();
                    return _context13.finish(23);
                  case 26:
                    _context13.next = 28;
                    return removeNodeWithConnections(editor, node.id);
                  case 28:
                  case "end":
                    return _context13.stop();
                }
              }, _loop3, null, [[9, 20, 23, 26]]);
            });
            _i6 = 0, _arr3 = _toConsumableArray__default["default"](editor.getNodes());
          case 3:
            if (!(_i6 < _arr3.length)) {
              _context14.next = 8;
              break;
            }
            return _context14.delegateYield(_loop3(), "t0", 5);
          case 5:
            _i6++;
            _context14.next = 3;
            break;
          case 8:
          case "end":
            return _context14.stop();
        }
      }, _callee11);
    }));
    return function (_x23) {
      return _ref19.apply(this, arguments);
    };
  }();
}
function collapsePort(_x24, _x25, _x26, _x27, _x28) {
  return _collapsePort.apply(this, arguments);
}
function _collapsePort() {
  _collapsePort = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee18(context, _ref20, _ref21, side, apply) {
    var _ref22, from, fromPort, _ref23, to, toPort, editor, createConnection, sidePorts, port, prevPort, connections, _iterator12, _step12, _connection3;
    return _regeneratorRuntime__default["default"].wrap(function _callee18$(_context24) {
      while (1) switch (_context24.prev = _context24.next) {
        case 0:
          _ref22 = _slicedToArray__default["default"](_ref20, 2), from = _ref22[0], fromPort = _ref22[1];
          _ref23 = _slicedToArray__default["default"](_ref21, 2), to = _ref23[0], toPort = _ref23[1];
          editor = context.editor, createConnection = context.createConnection;
          sidePorts = "".concat(side, "s");
          port = to[sidePorts][toPort];
          prevPort = from[sidePorts][fromPort];
          if (!(!port || !prevPort)) {
            _context24.next = 8;
            break;
          }
          throw new Error("cannot find ".concat(side, " port"));
        case 8:
          apply(prevPort, port);
          connections = editor.getConnections().filter(function (c) {
            return side === 'output' ? c.source === from.id && c.sourceOutput === fromPort : c.target === from.id && c.targetInput === fromPort;
          });
          _iterator12 = _createForOfIteratorHelper$3(connections);
          _context24.prev = 11;
          _iterator12.s();
        case 13:
          if ((_step12 = _iterator12.n()).done) {
            _context24.next = 19;
            break;
          }
          _connection3 = _step12.value;
          _context24.next = 17;
          return editor.addConnection(side === 'output' ? createConnection(to, toPort, editor.getNode(_connection3.target), _connection3.targetInput) : createConnection(editor.getNode(_connection3.source), _connection3.sourceOutput, to, toPort));
        case 17:
          _context24.next = 13;
          break;
        case 19:
          _context24.next = 24;
          break;
        case 21:
          _context24.prev = 21;
          _context24.t0 = _context24["catch"](11);
          _iterator12.e(_context24.t0);
        case 24:
          _context24.prev = 24;
          _iterator12.f();
          return _context24.finish(24);
        case 27:
        case "end":
          return _context24.stop();
      }
    }, _callee18, null, [[11, 21, 24, 27]]);
  }));
  return _collapsePort.apply(this, arguments);
}
function cleanUpPorts(exclude, onRemove) {
  return /*#__PURE__*/function () {
    var _ref25 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee12(_ref24) {
      var editor, _loop4, _i7, _arr4;
      return _regeneratorRuntime__default["default"].wrap(function _callee12$(_context16) {
        while (1) switch (_context16.prev = _context16.next) {
          case 0:
            editor = _ref24.editor;
            _loop4 = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop4() {
              var node, result, _result$inputs2, inputs, _result$outputs2, outputs;
              return _regeneratorRuntime__default["default"].wrap(function _loop4$(_context15) {
                while (1) switch (_context15.prev = _context15.next) {
                  case 0:
                    node = _arr4[_i7];
                    result = exclude(node);
                    if (result) {
                      _result$inputs2 = result.inputs, inputs = _result$inputs2 === void 0 ? [] : _result$inputs2, _result$outputs2 = result.outputs, outputs = _result$outputs2 === void 0 ? [] : _result$outputs2;
                      inputs.forEach(function (input) {
                        if (editor.getConnections().filter(function (c) {
                          return c.target === node.id && c.targetInput === input;
                        }).length) return;
                        onRemove(node, input, node.inputs[input]);
                        node.removeInput(input);
                      });
                      outputs.forEach(function (output) {
                        if (editor.getConnections().filter(function (c) {
                          return c.source === node.id && c.sourceOutput === output;
                        }).length) return;
                        onRemove(node, output, node.outputs[output]);
                        node.removeOutput(output);
                      });
                    }
                  case 3:
                  case "end":
                    return _context15.stop();
                }
              }, _loop4);
            });
            _i7 = 0, _arr4 = _toConsumableArray__default["default"](editor.getNodes());
          case 3:
            if (!(_i7 < _arr4.length)) {
              _context16.next = 8;
              break;
            }
            return _context16.delegateYield(_loop4(), "t0", 5);
          case 5:
            _i7++;
            _context16.next = 3;
            break;
          case 8:
          case "end":
            return _context16.stop();
        }
      }, _callee12);
    }));
    return function (_x29) {
      return _ref25.apply(this, arguments);
    };
  }();
}
function ensurePorts(include, onAdd) {
  return /*#__PURE__*/function () {
    var _ref27 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee13(_ref26) {
      var editor, createInput, createOutput, _loop5, _i8, _arr5;
      return _regeneratorRuntime__default["default"].wrap(function _callee13$(_context18) {
        while (1) switch (_context18.prev = _context18.next) {
          case 0:
            editor = _ref26.editor, createInput = _ref26.createInput, createOutput = _ref26.createOutput;
            _loop5 = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop5() {
              var node, result, _result$inputs3, inputs, _result$outputs3, outputs;
              return _regeneratorRuntime__default["default"].wrap(function _loop5$(_context17) {
                while (1) switch (_context17.prev = _context17.next) {
                  case 0:
                    node = _arr5[_i8];
                    result = include(node);
                    if (result) {
                      _result$inputs3 = result.inputs, inputs = _result$inputs3 === void 0 ? [] : _result$inputs3, _result$outputs3 = result.outputs, outputs = _result$outputs3 === void 0 ? [] : _result$outputs3;
                      inputs.forEach(function (input) {
                        var _ref28 = Array.isArray(input) ? input : [input],
                          _ref29 = _slicedToArray__default["default"](_ref28, 2),
                          key = _ref29[0],
                          socket = _ref29[1];
                        if (node.inputs[key]) return;
                        node.addInput(key, createInput(key));
                        if (socket) node.inputs[key].socket = socket();
                        onAdd(node, key, node.inputs[key]);
                      });
                      outputs.forEach(function (output) {
                        var _ref30 = Array.isArray(output) ? output : [output],
                          _ref31 = _slicedToArray__default["default"](_ref30, 2),
                          key = _ref31[0],
                          socket = _ref31[1];
                        if (node.outputs[key]) return;
                        node.addOutput(key, createOutput(key));
                        if (socket) node.outputs[key].socket = socket();
                        onAdd(node, key, node.outputs[key]);
                      });
                    }
                  case 3:
                  case "end":
                    return _context17.stop();
                }
              }, _loop5);
            });
            _i8 = 0, _arr5 = _toConsumableArray__default["default"](editor.getNodes());
          case 3:
            if (!(_i8 < _arr5.length)) {
              _context18.next = 8;
              break;
            }
            return _context18.delegateYield(_loop5(), "t0", 5);
          case 5:
            _i8++;
            _context18.next = 3;
            break;
          case 8:
          case "end":
            return _context18.stop();
        }
      }, _callee13);
    }));
    return function (_x30) {
      return _ref27.apply(this, arguments);
    };
  }();
}
function mergeSiblingNodes(source, target) {
  return /*#__PURE__*/function () {
    var _ref32 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee14(context) {
      var editor, createConnection, inputs, outputs, inputConnections, outputConnections, _iterator9, _step9, _connection, _source, sourceOutput, targetInput, _iterator10, _step10, _connection2, targetId, _sourceOutput, _targetInput;
      return _regeneratorRuntime__default["default"].wrap(function _callee14$(_context19) {
        while (1) switch (_context19.prev = _context19.next) {
          case 0:
            editor = context.editor, createConnection = context.createConnection;
            if (editor.getConnections().find(function (c) {
              return c.source === source.id && c.target === target.id;
            })) {
              _context19.next = 3;
              break;
            }
            throw new Error('the nodes should be siblings');
          case 3:
            target.data = _objectSpread$1({}, source.data);
            inputs = Object.entries(source.inputs);
            outputs = Object.entries(source.outputs);
            inputConnections = editor.getConnections().filter(function (c) {
              return c.target === source.id;
            });
            outputConnections = editor.getConnections().filter(function (c) {
              return c.source === source.id;
            });
            _context19.next = 10;
            return removeNodeWithConnections(editor, source.id);
          case 10:
            inputs.forEach(function (_ref33) {
              var _ref34 = _slicedToArray__default["default"](_ref33, 2),
                key = _ref34[0],
                input = _ref34[1];
              return input && !target.hasInput(key) && target.addInput(key, input);
            });
            outputs.forEach(function (_ref35) {
              var _ref36 = _slicedToArray__default["default"](_ref35, 2),
                key = _ref36[0],
                output = _ref36[1];
              return output && !target.hasOutput(key) && target.addOutput(key, output);
            });
            _iterator9 = _createForOfIteratorHelper$3(inputConnections);
            _context19.prev = 13;
            _iterator9.s();
          case 15:
            if ((_step9 = _iterator9.n()).done) {
              _context19.next = 22;
              break;
            }
            _connection = _step9.value;
            _source = _connection.source, sourceOutput = _connection.sourceOutput, targetInput = _connection.targetInput;
            _context19.next = 20;
            return editor.addConnection(createConnection(editor.getNode(_source), sourceOutput, target, targetInput, _connection));
          case 20:
            _context19.next = 15;
            break;
          case 22:
            _context19.next = 27;
            break;
          case 24:
            _context19.prev = 24;
            _context19.t0 = _context19["catch"](13);
            _iterator9.e(_context19.t0);
          case 27:
            _context19.prev = 27;
            _iterator9.f();
            return _context19.finish(27);
          case 30:
            _iterator10 = _createForOfIteratorHelper$3(outputConnections);
            _context19.prev = 31;
            _iterator10.s();
          case 33:
            if ((_step10 = _iterator10.n()).done) {
              _context19.next = 40;
              break;
            }
            _connection2 = _step10.value;
            targetId = _connection2.target, _sourceOutput = _connection2.sourceOutput, _targetInput = _connection2.targetInput;
            _context19.next = 38;
            return editor.addConnection(createConnection(target, _sourceOutput, editor.getNode(targetId), _targetInput, _connection2));
          case 38:
            _context19.next = 33;
            break;
          case 40:
            _context19.next = 45;
            break;
          case 42:
            _context19.prev = 42;
            _context19.t1 = _context19["catch"](31);
            _iterator10.e(_context19.t1);
          case 45:
            _context19.prev = 45;
            _iterator10.f();
            return _context19.finish(45);
          case 48:
          case "end":
            return _context19.stop();
        }
      }, _callee14, null, [[13, 24, 27, 30], [31, 42, 45, 48]]);
    }));
    return function (_x31) {
      return _ref32.apply(this, arguments);
    };
  }();
}
function getUpdateOperator(label) {
  switch (label) {
    case 'increment':
      return '++';
    case 'decrement':
      return '--';
  }
  return null;
}
function getBinaryOperator(label) {
  switch (label) {
    case 'equal':
      return '==';
    case 'strict equal':
      return '===';
    case 'not equal':
      return '!=';
    case 'not strict equal':
      return '!==';
  }
  return null;
}
function getLogicalOperator(label) {
  switch (label) {
    case 'and':
      return '&&';
    case 'or':
      return '||';
  }
  return null;
}
function getUnaryOperator(label) {
  switch (label) {
    case 'not':
      return '!';
    case 'to number':
      return '+';
    case 'typeof':
      return 'typeof';
  }
  return null;
}
function humanizeOperator(operator, type) {
  if (type === 'update') {
    switch (operator) {
      case '++':
        return 'increment';
      case '--':
        return 'decrement';
    }
  }
  if (type === 'binary') {
    switch (operator) {
      case '==':
        return 'equal';
      case '===':
        return 'strict equal';
      case '!=':
        return 'not equal';
      case '!==':
        return 'not strict equal';
    }
  }
  if (type === 'logical') {
    switch (operator) {
      case '&&':
        return 'and';
      case '||':
        return 'or';
    }
  }
  if (type === 'unary') {
    switch (operator) {
      case '!':
        return 'not';
      case '+':
        return 'to number';
    }
  }
  return String(operator);
}

var Transformer = /*#__PURE__*/_createClass__default["default"](function Transformer(name) {
  _classCallCheck__default["default"](this, Transformer);
  this.name = name;
});

function _createForOfIteratorHelper$2(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$2(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$2(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$2(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$2(o, minLen); }
function _arrayLikeToArray$2(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty__default["default"](e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var UnexpectedNode = /*#__PURE__*/_createClass__default["default"](function UnexpectedNode(node, key, item) {
  _classCallCheck__default["default"](this, UnexpectedNode);
  this.node = node;
  this.key = key;
  this.item = item;
});
var CodePlugin = /*#__PURE__*/function (_Scope) {
  _inherits__default["default"](CodePlugin, _Scope);
  var _super = _createSuper(CodePlugin);
  function CodePlugin(options) {
    var _this;
    _classCallCheck__default["default"](this, CodePlugin);
    _this = _super.call(this, 'code');
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "snapshots", {
      up: new Map(),
      down: new Map()
    });
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "current", -1);
    _this.options = options;
    return _this;
  }
  _createClass__default["default"](CodePlugin, [{
    key: "setParent",
    value: function setParent(scope) {
      _get__default["default"](_getPrototypeOf__default["default"](CodePlugin.prototype), "setParent", this).call(this, scope);
      this.editor = this.parentScope(rete.NodeEditor);
    }
  }, {
    key: "astNodeIntoEditor",
    value: function () {
      var _astNodeIntoEditor = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(data, context) {
        var editor, isSupported, isStatement, isExpression, createNode, createConnection, nodeCreated, node, _i, _Object$keys, _key, _item, i, id, s, _s;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              editor = context.editor, isSupported = context.isSupported, isStatement = context.isStatement, isExpression = context.isExpression, createNode = context.createNode, createConnection = context.createConnection, nodeCreated = context.nodeCreated;
              if (isSupported(data)) {
                _context.next = 3;
                break;
              }
              throw new Error('unsupported');
            case 3:
              node = createNode(data.type);
              if (isStatement(data)) {
                node.type = 'statement';
              } else if (isExpression(data)) {
                node.type = 'expression';
              } else {
                node.type = 'unknown';
              }
              _i = 0, _Object$keys = Object.keys(data);
            case 6:
              if (!(_i < _Object$keys.length)) {
                _context.next = 37;
                break;
              }
              _key = _Object$keys[_i];
              _item = data[_key];
              if (!Array.isArray(_item)) {
                _context.next = 24;
                break;
              }
              _context.t0 = _regeneratorRuntime__default["default"].keys(_item);
            case 11:
              if ((_context.t1 = _context.t0()).done) {
                _context.next = 22;
                break;
              }
              i = _context.t1.value;
              id = "".concat(_key, "[").concat(i, "]");
              node.addOutput(id, new Output(socket, id, true));
              _context.next = 17;
              return this.astNodeIntoEditor(_item[i], context);
            case 17:
              s = _context.sent;
              _context.next = 20;
              return editor.addConnection(createConnection(node, id, s, BIND_KEY));
            case 20:
              _context.next = 11;
              break;
            case 22:
              _context.next = 34;
              break;
            case 24:
              if (!(_item && _typeof__default["default"](_item) === 'object' && 'type' in _item)) {
                _context.next = 33;
                break;
              }
              node.addOutput(_key, new Output(socket, _key, true));
              _context.next = 28;
              return this.astNodeIntoEditor(_item, context);
            case 28:
              _s = _context.sent;
              _context.next = 31;
              return editor.addConnection(createConnection(node, _key, _s, BIND_KEY));
            case 31:
              _context.next = 34;
              break;
            case 33:
              node.data[_key] = _item;
            case 34:
              _i++;
              _context.next = 6;
              break;
            case 37:
              _context.next = 39;
              return editor.addNode(node);
            case 39:
              nodeCreated(node);
              return _context.abrupt("return", node);
            case 41:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
      function astNodeIntoEditor(_x, _x2) {
        return _astNodeIntoEditor.apply(this, arguments);
      }
      return astNodeIntoEditor;
    }()
  }, {
    key: "applyAST",
    value: function () {
      var _applyAST = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(ast) {
        var tempEditor;
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              tempEditor = new rete.NodeEditor();
              _context2.next = 3;
              return this.astNodeIntoEditor(ast, _objectSpread(_objectSpread({}, this.options.up), {}, {
                editor: tempEditor
              }));
            case 3:
              _context2.next = 5;
              return this.copy(tempEditor, this.editor);
            case 5:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function applyAST(_x3) {
        return _applyAST.apply(this, arguments);
      }
      return applyAST;
    }()
  }, {
    key: "step",
    value: function () {
      var _step = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(offset) {
        var target, transformers, transformer, _transformer;
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              target = this.current + offset;
              transformers = this.options.transformers;
              console.log(this.current, target, offset);
              if (!(target < -1 || target >= transformers.length)) {
                _context3.next = 5;
                break;
              }
              throw new Error('step: out of bounds');
            case 5:
              if (!(this.current < target)) {
                _context3.next = 13;
                break;
              }
              this.current++;
              transformer = transformers[this.current];
              _context3.next = 10;
              return transformer.up(_objectSpread(_objectSpread({}, this.options.up), {}, {
                editor: this.editor
              }));
            case 10:
              console.log('up', transformer.name);
              _context3.next = 5;
              break;
            case 13:
              if (!(this.current > target)) {
                _context3.next = 21;
                break;
              }
              _transformer = transformers[this.current];
              _context3.next = 17;
              return transformers[this.current].down(_objectSpread(_objectSpread({}, this.options.down), {}, {
                editor: this.editor
              }));
            case 17:
              console.log('down', _transformer.name);
              this.current--;
              _context3.next = 13;
              break;
            case 21:
              console.log('step', this.current);
            case 22:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
      function step(_x4) {
        return _step.apply(this, arguments);
      }
      return step;
    }()
  }, {
    key: "getCurrentStep",
    value: function getCurrentStep() {
      return this.current;
    }
  }, {
    key: "getTransformers",
    value: function getTransformers() {
      return this.options.transformers;
    }
  }, {
    key: "retrieveAST",
    value: function () {
      var _retrieveAST = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4() {
        var roots, root;
        return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              roots = reteStructures.structures(this.editor).roots().nodes();
              if (!(roots.length > 1)) {
                _context4.next = 3;
                break;
              }
              throw new Error('toAST: Multiple roots');
            case 3:
              if (!(roots.length === 0)) {
                _context4.next = 5;
                break;
              }
              throw new Error('toAST: No roots');
            case 5:
              root = roots[0];
              return _context4.abrupt("return", this.nodeIntoAST(root, _objectSpread(_objectSpread({}, this.options.down), {}, {
                editor: this.editor
              })));
            case 7:
            case "end":
              return _context4.stop();
          }
        }, _callee4, this);
      }));
      function retrieveAST() {
        return _retrieveAST.apply(this, arguments);
      }
      return retrieveAST;
    }()
  }, {
    key: "afterStep",
    value: function () {
      var _afterStep = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee5(ast) {
        var tempEditor;
        return _regeneratorRuntime__default["default"].wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              tempEditor = new rete.NodeEditor();
              _context5.next = 3;
              return this.astNodeIntoEditor(ast, _objectSpread(_objectSpread({}, this.options.up), {}, {
                editor: tempEditor
              }));
            case 3:
              _context5.next = 5;
              return this.copy(tempEditor, this.editor);
            case 5:
            case "end":
              return _context5.stop();
          }
        }, _callee5, this);
      }));
      function afterStep(_x5) {
        return _afterStep.apply(this, arguments);
      }
      return afterStep;
    }()
  }, {
    key: "toGraph",
    value: function () {
      var _toGraph = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee6(ast) {
        var transformers, tempEditor, _iterator, _step2, transformer, snapshot;
        return _regeneratorRuntime__default["default"].wrap(function _callee6$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              transformers = this.options.transformers;
              tempEditor = new rete.NodeEditor();
              this.snapshots.up.clear();
              // console.time('processNode')
              _context6.next = 5;
              return this.astNodeIntoEditor(ast, _objectSpread(_objectSpread({}, this.options.up), {}, {
                editor: tempEditor
              }));
            case 5:
              // console.timeEnd('processNode')
              // console.time('simplify')
              _iterator = _createForOfIteratorHelper$2(transformers);
              _context6.prev = 6;
              _iterator.s();
            case 8:
              if ((_step2 = _iterator.n()).done) {
                _context6.next = 26;
                break;
              }
              transformer = _step2.value;
              _context6.prev = 10;
              _context6.next = 13;
              return transformer.up(_objectSpread(_objectSpread({}, this.options.up), {}, {
                editor: tempEditor
              }));
            case 13:
              snapshot = new rete.NodeEditor();
              _context6.next = 16;
              return this.copy(tempEditor, snapshot);
            case 16:
              this.snapshots.up.set(transformer.name, snapshot);
              _context6.next = 24;
              break;
            case 19:
              _context6.prev = 19;
              _context6.t0 = _context6["catch"](10);
              _context6.next = 23;
              return this.copy(tempEditor, this.editor);
            case 23:
              throw _context6.t0;
            case 24:
              _context6.next = 8;
              break;
            case 26:
              _context6.next = 31;
              break;
            case 28:
              _context6.prev = 28;
              _context6.t1 = _context6["catch"](6);
              _iterator.e(_context6.t1);
            case 31:
              _context6.prev = 31;
              _iterator.f();
              return _context6.finish(31);
            case 34:
              _context6.next = 36;
              return this.copy(tempEditor, this.editor);
            case 36:
            case "end":
              return _context6.stop();
          }
        }, _callee6, this, [[6, 28, 31, 34], [10, 19]]);
      }));
      function toGraph(_x6) {
        return _toGraph.apply(this, arguments);
      }
      return toGraph;
    }()
  }, {
    key: "nodeIntoAST",
    value: function nodeIntoAST(node, context) {
      var _this2 = this;
      var keys = context.nodeParameters(node.label);
      var args = keys.map(function (key) {
        if (node.data[key] !== undefined && node.data[key] !== null) return node.data[key];
        var connections = context.editor.getConnections().filter(function (c) {
          if (c.source !== node.id) return false;
          if (c.sourceOutput === key) return true;
          if (c.sourceOutput.match(/^.*\[\d+\]$/) && c.sourceOutput.startsWith(key)) return true;
        });
        if (connections.length === 0) return context.defaults(node, key);
        if (connections[0].sourceOutput.match(/^.*\[\d+\]$/)) {
          return connections.sort(function (a, b) {
            var aIndex = parseInt(a.sourceOutput.match(/^.*\[(\d+)\]$/)[1]);
            var bIndex = parseInt(b.sourceOutput.match(/^.*\[(\d+)\]$/)[1]);
            return aIndex - bIndex;
          }).map(function (c) {
            return _this2.nodeIntoAST(context.editor.getNode(c.target), context);
          });
        }
        if (connections.length > 1) throw new Error("Multiple connections not allowed for ".concat(key));
        return _this2.nodeIntoAST(context.editor.getNode(connections[0].target), context);
      });
      return context.createASTNode(node, args);
    }
  }, {
    key: "toAST",
    value: function () {
      var _toAST = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee7() {
        var tempEditor, transformers, _iterator2, _step3, transformer, snapshot, roots, root, ast;
        return _regeneratorRuntime__default["default"].wrap(function _callee7$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              tempEditor = new rete.NodeEditor();
              transformers = _toConsumableArray__default["default"](this.options.transformers).reverse();
              this.snapshots.down.clear();
              _context7.next = 5;
              return this.copy(this.editor, tempEditor);
            case 5:
              _iterator2 = _createForOfIteratorHelper$2(transformers);
              _context7.prev = 6;
              _iterator2.s();
            case 8:
              if ((_step3 = _iterator2.n()).done) {
                _context7.next = 18;
                break;
              }
              transformer = _step3.value;
              _context7.next = 12;
              return transformer.down(_objectSpread(_objectSpread({}, this.options.down), {}, {
                editor: tempEditor
              }));
            case 12:
              snapshot = new rete.NodeEditor();
              this.snapshots.down.set(transformer.name, snapshot);
              _context7.next = 16;
              return this.copy(tempEditor, snapshot);
            case 16:
              _context7.next = 8;
              break;
            case 18:
              _context7.next = 23;
              break;
            case 20:
              _context7.prev = 20;
              _context7.t0 = _context7["catch"](6);
              _iterator2.e(_context7.t0);
            case 23:
              _context7.prev = 23;
              _iterator2.f();
              return _context7.finish(23);
            case 26:
              roots = reteStructures.structures(tempEditor).roots().nodes();
              if (!(roots.length > 1)) {
                _context7.next = 29;
                break;
              }
              throw new Error('toAST: Multiple roots');
            case 29:
              if (!(roots.length === 0)) {
                _context7.next = 31;
                break;
              }
              throw new Error('toAST: No roots');
            case 31:
              root = roots[0];
              _context7.prev = 32;
              ast = this.nodeIntoAST(root, _objectSpread(_objectSpread({}, this.options.down), {}, {
                editor: tempEditor
              }));
              console.log('toAST', ast);
              return _context7.abrupt("return", ast);
            case 38:
              _context7.prev = 38;
              _context7.t1 = _context7["catch"](32);
              console.error('toAST: ', _context7.t1);
              throw _context7.t1;
            case 42:
            case "end":
              return _context7.stop();
          }
        }, _callee7, this, [[6, 20, 23, 26], [32, 38]]);
      }));
      function toAST() {
        return _toAST.apply(this, arguments);
      }
      return toAST;
    }()
  }, {
    key: "copy",
    value: function () {
      var _copy = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee8(from, to) {
        return _regeneratorRuntime__default["default"].wrap(function _callee8$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              _context8.next = 2;
              return to.clear();
            case 2:
              _context8.next = 4;
              return copyToEditor(from, to);
            case 4:
            case "end":
              return _context8.stop();
          }
        }, _callee8);
      }));
      function copy(_x7, _x8) {
        return _copy.apply(this, arguments);
      }
      return copy;
    }()
  }]);
  return CodePlugin;
}(rete.Scope);

function _createForOfIteratorHelper$1(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$1(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$1(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$1(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$1(o, minLen); }
function _arrayLikeToArray$1(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function applyOutputIdentifierControl(control, activeNode, data) {
  control.options.onChange = function (value) {
    activeNode.outputs[data.key].socket.identifier = String(value);
  };
}
function applyDataKey(control, activeNode, data) {
  control.options.onChange = function (value) {
    activeNode.data[data.key] = value;
  };
}
function applySelectVarKind(control, activeNode) {
  control.onChange = function (value) {
    activeNode.data.kind = value;
  };
}
function applySelectUpdatePrefix(control, activeNode) {
  control.onChange = function (value) {
    activeNode.data.prefix = value === 'prefix';
  };
}
function applyInsertHandler(control, activeNode, update, data) {
  var key = data.key,
    side = data.side,
    needControl = data.needControl;
  control.onClick = function () {
    var list = side === 'input' ? activeNode.inputs : activeNode.outputs;
    var index = Object.keys(list).filter(function (k) {
      return k.startsWith(key);
    }).length;
    var arrayKey = "".concat(key, "[").concat(index, "]");
    if (side === 'input') {
      var input = new Input(socket, arrayKey, true);
      if (needControl && !input.control) {
        var _control = new InputControl({
          action: 'change-identifier',
          type: 'text'
        });
        input.control = _control;
      }
      activeNode.addInput(arrayKey, input);
    } else {
      var identifier = "arg".concat(rete.getUID());
      var output = new Output(new RefSocket('Reference', identifier), arrayKey, true);
      if (needControl && !output.control) {
        var _control2 = new InputControl({
          // TODO
          action: ['change-output-identifier', {
            key: key
          }],
          type: 'identifier',
          initial: identifier,
          allowedTypes: ['identifier']
        });
        applyOutputIdentifierControl(_control2, activeNode, {
          key: key
        });
        output.control = _control2;
      }
      activeNode.addOutput(arrayKey, output);
    }
    activeNode.updateSize();
    update(activeNode.id);
  };
}
function applyInteraction(editor, update) {
  var _iterator = _createForOfIteratorHelper$1(editor.getNodes()),
    _step;
  try {
    var _loop = function _loop() {
      var node = _step.value;
      [].concat(_toConsumableArray__default["default"](Object.values(node.controls).map(function (control) {
        return [node, control];
      })), _toConsumableArray__default["default"](Object.values(node.inputs).map(function (inp) {
        return [node, inp === null || inp === void 0 ? void 0 : inp.control];
      })), _toConsumableArray__default["default"](Object.values(node.outputs).map(function (out) {
        return [node, out === null || out === void 0 ? void 0 : out.control];
      }))).forEach(function (_ref) {
        var _ref2 = _slicedToArray__default["default"](_ref, 2),
          activeNode = _ref2[0],
          control = _ref2[1];
        if (control instanceof InsertControl && control.action[0] === 'insert') {
          applyInsertHandler(control, activeNode, update, control.action[1]);
        }
        if (control instanceof InputControl && control.action[0] === 'change-output-identifier') {
          applyOutputIdentifierControl(control, activeNode, control.action[1]);
        }
        if (control instanceof InputControl && control.action[0] === 'change-key-text') {
          applyDataKey(control, activeNode, control.action[1]);
        }
        if (control instanceof SelectControl && control.action === 'select-var-kind') {
          applySelectVarKind(control, activeNode);
        }
        if (control instanceof SelectControl && control.action === 'select-update-prefix') {
          applySelectUpdatePrefix(control, activeNode);
        }
      });
    };
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      _loop();
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
}

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function serialize(editor) {
  var data = {
    nodes: editor.getNodes().map(function (n) {
      return n.serialize();
    }),
    connections: editor.getConnections().map(function (c) {
      return c.serialize();
    })
  };
  return data;
}
function deserializeSocket(socket) {
  if ('isRef' in socket) {
    return RefSocket.deserialize(socket);
  }
  if ('isControl' in socket) {
    return ControlSocket.deserialize(socket);
  }
  return Socket.deserialize(socket);
}
function deserializeControl(control) {
  if ('isSelectControl' in control) {
    return SelectControl.deserialize(control);
  }
  if ('isInputControl' in control) {
    return InputControl.deserialize(control);
  }
  if ('isInsertControl' in control) {
    return InsertControl.deserialize(control);
  }
  throw new Error('cannot find control class');
}
function importForParent(_x, _x2, _x3) {
  return _importForParent.apply(this, arguments);
}
function _importForParent() {
  _importForParent = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(editor, nodes, parent) {
    var children, _iterator, _step, node;
    return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          children = nodes.filter(function (node) {
            return node.parent === parent;
          });
          _iterator = _createForOfIteratorHelper(children);
          _context.prev = 2;
          _iterator.s();
        case 4:
          if ((_step = _iterator.n()).done) {
            _context.next = 12;
            break;
          }
          node = _step.value;
          _context.next = 8;
          return editor.addNode(BaseNode.deserialize(node, function (input) {
            return Input.deserialize(input, deserializeSocket(input.socket), input.control && deserializeControl(input.control));
          }, function (output) {
            return Output.deserialize(output, deserializeSocket(output.socket), output.control && deserializeControl(output.control));
          }, function (control) {
            return deserializeControl(control);
          }));
        case 8:
          _context.next = 10;
          return importForParent(editor, nodes, node.id);
        case 10:
          _context.next = 4;
          break;
        case 12:
          _context.next = 17;
          break;
        case 14:
          _context.prev = 14;
          _context.t0 = _context["catch"](2);
          _iterator.e(_context.t0);
        case 17:
          _context.prev = 17;
          _iterator.f();
          return _context.finish(17);
        case 20:
        case "end":
          return _context.stop();
      }
    }, _callee, null, [[2, 14, 17, 20]]);
  }));
  return _importForParent.apply(this, arguments);
}
function deserialize(_x4, _x5) {
  return _deserialize.apply(this, arguments);
}
function _deserialize() {
  _deserialize = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(editor, data) {
    var _iterator2, _step2, c, instance;
    return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          _context2.next = 2;
          return importForParent(editor, data.nodes);
        case 2:
          _iterator2 = _createForOfIteratorHelper(data.connections);
          _context2.prev = 3;
          _iterator2.s();
        case 5:
          if ((_step2 = _iterator2.n()).done) {
            _context2.next = 12;
            break;
          }
          c = _step2.value;
          instance = Connection.deserialize(c, editor.getNode(c.source), editor.getNode(c.target));
          _context2.next = 10;
          return editor.addConnection(instance);
        case 10:
          _context2.next = 5;
          break;
        case 12:
          _context2.next = 17;
          break;
        case 14:
          _context2.prev = 14;
          _context2.t0 = _context2["catch"](3);
          _iterator2.e(_context2.t0);
        case 17:
          _context2.prev = 17;
          _iterator2.f();
          return _context2.finish(17);
        case 20:
        case "end":
          return _context2.stop();
      }
    }, _callee2, null, [[3, 14, 17, 20]]);
  }));
  return _deserialize.apply(this, arguments);
}

function createAdapter(language) {
  var _language$initCodePlu = language.initCodePlugin(),
    code = _language$initCodePlu.code,
    toAST = _language$initCodePlu.toAST,
    toGraph = _language$initCodePlu.toGraph,
    astTools = _language$initCodePlu.astTools;
  var workerEditor = new rete.NodeEditor();
  workerEditor.use(code);
  return {
    getExample: function getExample() {
      return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee() {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              return _context.abrupt("return", language.playgroundExample);
            case 1:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))();
    },
    getSnippets: function getSnippets() {
      return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2() {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              return _context2.abrupt("return", language.snippets);
            case 1:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }))();
    },
    codeToExecutable: function codeToExecutable(code) {
      return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3() {
        var ast;
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              _context3.t0 = astTools;
              _context3.next = 3;
              return astTools.parse(code);
            case 3:
              _context3.t1 = _context3.sent;
              _context3.next = 6;
              return _context3.t0.purify.call(_context3.t0, _context3.t1);
            case 6:
              ast = _context3.sent;
              _context3.t2 = astTools;
              _context3.next = 10;
              return astTools.executable(ast);
            case 10:
              _context3.t3 = _context3.sent;
              return _context3.abrupt("return", _context3.t2.generate.call(_context3.t2, _context3.t3));
            case 12:
            case "end":
              return _context3.stop();
          }
        }, _callee3);
      }))();
    },
    graphToCode: function graphToCode(data) {
      return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4() {
        var ast, generatedCode;
        return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return workerEditor.clear();
            case 2:
              _context4.next = 4;
              return deserialize(workerEditor, data);
            case 4:
              _context4.next = 6;
              return toAST();
            case 6:
              ast = _context4.sent;
              generatedCode = astTools.generate(ast);
              return _context4.abrupt("return", generatedCode);
            case 9:
            case "end":
              return _context4.stop();
          }
        }, _callee4);
      }))();
    },
    codeToGraph: function codeToGraph(code) {
      return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee5() {
        var ast;
        return _regeneratorRuntime__default["default"].wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.t0 = astTools;
              _context5.next = 3;
              return astTools.parse(code);
            case 3:
              _context5.t1 = _context5.sent;
              _context5.next = 6;
              return _context5.t0.purify.call(_context5.t0, _context5.t1);
            case 6:
              ast = _context5.sent;
              _context5.next = 9;
              return workerEditor.clear();
            case 9:
              _context5.next = 11;
              return toGraph(ast);
            case 11:
              return _context5.abrupt("return", serialize(workerEditor));
            case 12:
            case "end":
              return _context5.stop();
          }
        }, _callee5);
      }))();
    },
    _getTransformerNames: function _getTransformerNames() {
      return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee6() {
        return _regeneratorRuntime__default["default"].wrap(function _callee6$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              return _context6.abrupt("return", Array.from(code.getTransformers().map(function (t) {
                return t.name;
              })));
            case 1:
            case "end":
              return _context6.stop();
          }
        }, _callee6);
      }))();
    },
    _applySnapshot: function _applySnapshot(direction, name) {
      return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee7() {
        var editor;
        return _regeneratorRuntime__default["default"].wrap(function _callee7$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              editor = code.snapshots[direction].get(name);
              if (editor) {
                _context7.next = 3;
                break;
              }
              throw new Error('Snapshot not found');
            case 3:
              return _context7.abrupt("return", serialize(editor));
            case 4:
            case "end":
              return _context7.stop();
          }
        }, _callee7);
      }))();
    }
  };
}

exports.BIND_KEY = BIND_KEY;
exports.BaseNode = BaseNode;
exports.CodePlugin = CodePlugin;
exports.Connection = Connection;
exports.Control = Control;
exports.ControlSocket = ControlSocket;
exports.Input = Input;
exports.InputControl = InputControl;
exports.InsertControl = InsertControl;
exports.Output = Output;
exports.RefSocket = RefSocket;
exports.SelectControl = SelectControl;
exports.Socket = Socket;
exports.Transformer = Transformer;
exports.UnexpectedNode = UnexpectedNode;
exports.Utils = utils;
exports.applyInteraction = applyInteraction;
exports.belongToSameClosure = belongToSameClosure;
exports.cleanUpPorts = cleanUpPorts;
exports.collapsePort = collapsePort;
exports.createAdapter = createAdapter;
exports.createSuperStatement = createSuperStatement;
exports.deserialize = deserialize;
exports.ensurePorts = ensurePorts;
exports.expressionToExpressionStatement = expressionToExpressionStatement;
exports.findLabeledStatement = findLabeledStatement;
exports.flowToTree = flowToTree;
exports.forEach = forEach;
exports.getBinaryOperator = getBinaryOperator;
exports.getBranchExit = getBranchExit;
exports.getClosureDifference = getClosureDifference;
exports.getClosureDifference2 = getClosureDifference2;
exports.getClosureDifferenceOld = getClosureDifferenceOld;
exports.getClosures = getClosures;
exports.getInputNode = getInputNode;
exports.getLogicalOperator = getLogicalOperator;
exports.getOutputNode = getOutputNode;
exports.getUnaryOperator = getUnaryOperator;
exports.getUpdateOperator = getUpdateOperator;
exports.humanizeOperator = humanizeOperator;
exports.inputTypes = inputTypes;
exports.markClosures = markClosures;
exports.mergeSiblingNodes = mergeSiblingNodes;
exports.mirrorLeft = mirrorLeft;
exports.mirrorRight = mirrorRight;
exports.patchPlaceholderPorts = patchPlaceholderPorts;
exports.reconnect = reconnect;
exports.removeRedunantNodes = removeRedunantNodes;
exports.rename = rename;
exports.serialize = serialize;
exports.simplifyIdentifiers = simplifyIdentifiers;
exports.simplifyLiterals = simplifyLiterals;
exports.socket = socket;
exports.treeToFlow = treeToFlow;
//# sourceMappingURL=rete-studio-core.common.js.map
