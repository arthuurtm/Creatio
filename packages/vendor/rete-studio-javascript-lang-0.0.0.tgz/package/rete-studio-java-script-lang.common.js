/*!
* rete-studio-javascript-lang v0.0.0
* (c) 2026 Vitaliy Stoliarov
* Released under the CC-BY-NC-SA-4.0 license.
* */
'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var _toConsumableArray = require('@babel/runtime/helpers/toConsumableArray');
var _defineProperty = require('@babel/runtime/helpers/defineProperty');
var _asyncToGenerator = require('@babel/runtime/helpers/asyncToGenerator');
var _regeneratorRuntime = require('@babel/runtime/regenerator');
var _generate = require('@babel/generator');
var parser = require('@babel/parser');
var t = require('@babel/types');
var rete = require('rete');
var reteStudioCore = require('rete-studio-core');
var traverse = require('@babel/traverse');
var _slicedToArray = require('@babel/runtime/helpers/slicedToArray');
var _classCallCheck = require('@babel/runtime/helpers/classCallCheck');
var _createClass = require('@babel/runtime/helpers/createClass');
var _inherits = require('@babel/runtime/helpers/inherits');
var _possibleConstructorReturn = require('@babel/runtime/helpers/possibleConstructorReturn');
var _getPrototypeOf = require('@babel/runtime/helpers/getPrototypeOf');
var _assertThisInitialized = require('@babel/runtime/helpers/assertThisInitialized');
var reteStructures = require('rete-structures');

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  var n = Object.create(null);
  if (e) {
    Object.keys(e).forEach(function (k) {
      if (k !== 'default') {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    });
  }
  n["default"] = e;
  return Object.freeze(n);
}

var _toConsumableArray__default = /*#__PURE__*/_interopDefaultLegacy(_toConsumableArray);
var _defineProperty__default = /*#__PURE__*/_interopDefaultLegacy(_defineProperty);
var _asyncToGenerator__default = /*#__PURE__*/_interopDefaultLegacy(_asyncToGenerator);
var _regeneratorRuntime__default = /*#__PURE__*/_interopDefaultLegacy(_regeneratorRuntime);
var _generate__default = /*#__PURE__*/_interopDefaultLegacy(_generate);
var t__namespace = /*#__PURE__*/_interopNamespace(t);
var traverse__default = /*#__PURE__*/_interopDefaultLegacy(traverse);
var _slicedToArray__default = /*#__PURE__*/_interopDefaultLegacy(_slicedToArray);
var _classCallCheck__default = /*#__PURE__*/_interopDefaultLegacy(_classCallCheck);
var _createClass__default = /*#__PURE__*/_interopDefaultLegacy(_createClass);
var _inherits__default = /*#__PURE__*/_interopDefaultLegacy(_inherits);
var _possibleConstructorReturn__default = /*#__PURE__*/_interopDefaultLegacy(_possibleConstructorReturn);
var _getPrototypeOf__default = /*#__PURE__*/_interopDefaultLegacy(_getPrototypeOf);
var _assertThisInitialized__default = /*#__PURE__*/_interopDefaultLegacy(_assertThisInitialized);

function declarationToVariable(declaration, transformBody, parentScope) {
  if (t__namespace.isVariableDeclaration(declaration)) {
    return declaration;
  }
  if (t__namespace.isFunctionDeclaration(declaration)) {
    if (!declaration.id) throw new Error('function declaration should have id');
    return t__namespace.variableDeclaration('var', [t__namespace.variableDeclarator(declaration.id, declarationToExpression(declaration, transformBody, parentScope))]);
  }
  if (t__namespace.isClassDeclaration(declaration) && declaration.id) {
    return t__namespace.variableDeclaration('const', [t__namespace.variableDeclarator(declaration.id, declarationToExpression(declaration, transformBody, parentScope))]);
  }
  throw new Error('unknown declaration type');
}
function declarationToExpression(declaration, transformBody, parentScope) {
  if (t__namespace.isFunctionDeclaration(declaration)) {
    var id = declaration.id,
      params = declaration.params,
      _body = declaration.body,
      generator = declaration.generator,
      async = declaration.async;
    transformBody(_body, parentScope);
    return t__namespace.functionExpression(id, params, _body, generator, async);
  }
  if (t__namespace.isClassDeclaration(declaration)) {
    transformBody(declaration, parentScope);
    var _id = declaration.id,
      superClass = declaration.superClass,
      _body2 = declaration.body,
      decorators = declaration.decorators;
    return t__namespace.classExpression(_id, superClass, _body2, decorators);
  }
  throw new Error('unknown declaration type');
}

function createLoop(path) {
  var id = path.parentPath.isLabeledStatement() ? path.parentPath.node.label : t__namespace.identifier('loop' + rete.getUID());
  if (path.parentPath.isLabeledStatement()) {
    path.parentPath.node.label = t__namespace.identifier('old' + rete.getUID());
  }
  return {
    id: id,
    statement: t__namespace.labeledStatement(id, t__namespace.emptyStatement()),
    patchContinue: function patchContinue(body, pregoto) {
      traverse__default["default"](body, {
        enter: function enter(path) {
          if (path.isCompletionStatement()) {
            path.skip();
          }
          if (path.isContinueStatement()) {
            if (!path.node.label || path.node.label.name === id.name) {
              var n = t__namespace.continueStatement(id);
              path.replaceWith(t__namespace.blockStatement(pregoto ? [pregoto, n] : [n]));
              path.skip();
            }
          }
        }
      }, path.scope);
    }
  };
}
function loopToGoto(path, pregoto) {
  var _path$node = path.node,
    test = _path$node.test,
    body = _path$node.body;
  var _createLoop = createLoop(path),
    id = _createLoop.id,
    statement = _createLoop.statement,
    patchContinue = _createLoop.patchContinue;
  var block = t__namespace.blockStatement([]);
  var ifStatement = t__namespace.ifStatement(test || t__namespace.booleanLiteral(true), block);
  statement.body = ifStatement;
  patchContinue(body, pregoto);
  if (t__namespace.isBlockStatement(body)) {
    var _block$body;
    (_block$body = block.body).push.apply(_block$body, _toConsumableArray__default["default"](body.body));
  } else {
    block.body.push(body);
  }
  if (pregoto) {
    block.body.push(pregoto);
  }
  block.body.push(t__namespace.continueStatement(id));
  return {
    statement: statement,
    id: id,
    body: block
  };
}

var scopeHoisingIndex = new WeakMap();
function hoise(scopable, declaration) {
  var parentBody = getScopableBody(scopable);
  var index = scopeHoisingIndex.get(parentBody) || 0;
  parentBody.splice(index, 0, declaration);
  scopeHoisingIndex.set(parentBody, index + 1);
}
function getScopableBody(scopable) {
  if (t__namespace.isSwitchStatement(scopable)) throw new Error('scope does not have body');
  if (!Array.isArray(scopable.body)) throw new Error('not implemented for non-array body');
  return scopable.body;
}
function prepend(parent, node, nextSibling) {
  return insert(parent, node, nextSibling, 0);
}
function append(parent, node, nextSibling) {
  return insert(parent, node, nextSibling, 1);
}
function insert(parent, node, nextSibling, index) {
  var scope = t__namespace.isLabeledStatement(parent) ? parent.body : parent;
  if (!t__namespace.isScopable(scope)) throw new Error('parent is not scopable');
  var body = getScopableBody(scope);
  var exportIndex = body.indexOf(nextSibling);
  if (exportIndex < 0) throw new Error('exportIndex is negative');
  body.splice(exportIndex + index, 0, node);
}

function getIdentifiers(v) {
  var ids = [];
  if (t__namespace.isIdentifier(v)) {
    ids.push(v);
  } else if (t__namespace.isArrayPattern(v)) {
    v.elements.forEach(function (el) {
      return el && ids.push.apply(ids, _toConsumableArray__default["default"](getIdentifiers(el)));
    });
  } else if (t__namespace.isObjectPattern(v)) {
    v.properties.forEach(function (el) {
      if (t__namespace.isRestElement(el)) ids.push.apply(ids, _toConsumableArray__default["default"](getIdentifiers(el)));else ids.push.apply(ids, _toConsumableArray__default["default"](getIdentifiers(el.value)));
    });
  } else if (t__namespace.isRestElement(v)) {
    ids.push.apply(ids, _toConsumableArray__default["default"](getIdentifiers(v.argument)));
  } else {
    throw v.type;
  }
  return ids;
}

function _createForOfIteratorHelper$g(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$g(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$g(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$g(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$g(o, minLen); }
function _arrayLikeToArray$g(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function makePurifiedExecutable(node, scope) {
  traverse__default["default"](node, {
    enter: function enter(path) {
      if (path.isLabeledStatement()) {
        var _path$node = path.node,
          label = _path$node.label,
          body = _path$node.body;
        makePurifiedExecutable(body, path.scope);
        path.replaceWith(t__namespace.labeledStatement(label, t__namespace.whileStatement(t__namespace.booleanLiteral(true), t__namespace.blockStatement([body, t__namespace.breakStatement(label)]))));
        path.skip();
      }
    }
  }, scope);
  return node;
}
function applyAstTransformations(node, scope) {
  traverse__default["default"](node, {
    enter: function enter(path) {
      if (path.isObjectProperty()) {
        if (!path.node.computed && t__namespace.isIdentifier(path.node.key)) {
          path.replaceWith(t__namespace.objectProperty(t__namespace.stringLiteral(path.node.key.name), path.node.value, true, path.node.shorthand, path.node.decorators));
        }
      }
      if (path.isMemberExpression()) {
        if (!path.node.computed && t__namespace.isIdentifier(path.node.property)) {
          path.replaceWith(t__namespace.memberExpression(path.node.object, t__namespace.stringLiteral(path.node.property.name), true, path.node.optional));
        }
      }
      if (path.isWhileStatement()) {
        var _loopToGoto = loopToGoto(path),
          statement = _loopToGoto.statement;
        path.replaceWith(statement);
      }
      if (path.isForStatement()) {
        var _path$node2 = path.node,
          init = _path$node2.init,
          update = _path$node2.update;
        var _loopToGoto2 = loopToGoto(path, update && t__namespace.expressionStatement(update)),
          _statement = _loopToGoto2.statement;
        var closure = t__namespace.blockStatement([_statement]);
        if (init) {
          closure.body.unshift(t__namespace.isStatement(init) ? init : t__namespace.expressionStatement(init));
        }
        path.replaceWith(closure);
      }
      if (path.isDoWhileStatement()) {
        var _path$node3 = path.node,
          test = _path$node3.test,
          body = _path$node3.body;
        var _createLoop = createLoop(path),
          id = _createLoop.id,
          _statement2 = _createLoop.statement,
          patchContinue = _createLoop.patchContinue;
        var block = t__namespace.blockStatement([]);
        patchContinue(body);
        _statement2.body = block;
        if (t__namespace.isBlockStatement(body)) {
          var _block$body;
          (_block$body = block.body).push.apply(_block$body, _toConsumableArray__default["default"](body.body));
        } else {
          block.body.push(body);
        }
        var ifStatement = t__namespace.ifStatement(test || t__namespace.booleanLiteral(true), t__namespace.continueStatement(id));
        block.body.push(ifStatement);
        path.replaceWith(_statement2);
      }
      if (path.isForInStatement() || path.isForOfStatement()) {
        var _path$node4 = path.node,
          left = _path$node4.left,
          right = _path$node4.right,
          _body = _path$node4.body;
        var _createLoop2 = createLoop(path),
          _id = _createLoop2.id,
          _statement3 = _createLoop2.statement,
          _patchContinue = _createLoop2.patchContinue;
        var _closure = t__namespace.blockStatement([_statement3]);
        var iteratorId = t__namespace.identifier('iterator');
        var iterator = t__namespace.memberExpression(right, t__namespace.memberExpression(t__namespace.identifier('Symbol'), t__namespace.identifier('iterator')), true);
        _closure.body.unshift(t__namespace.variableDeclaration('const', [t__namespace.variableDeclarator(iteratorId, t__namespace.callExpression(iterator, []))]));
        var _block = t__namespace.blockStatement([]);
        _patchContinue(_body);
        _statement3.body = _block;
        _block.body.push(t__namespace.variableDeclaration('const', [t__namespace.variableDeclarator(t__namespace.objectPattern([t__namespace.objectProperty(t__namespace.identifier('value'), t__namespace.identifier('value')), t__namespace.objectProperty(t__namespace.identifier('done'), t__namespace.identifier('done'))]), t__namespace.callExpression(t__namespace.memberExpression(iteratorId, t__namespace.identifier('next')), []))]));
        _block.body.push(t__namespace.ifStatement(t__namespace.identifier('done'), t__namespace.breakStatement(_id)));
        if (t__namespace.isVariableDeclaration(left)) {
          left.declarations[0].init = right;
          _block.body.push(left);
        } else {
          _block.body.push(t__namespace.variableDeclaration('const', [t__namespace.variableDeclarator(left, t__namespace.identifier('value'))]));
        }
        if (t__namespace.isBlockStatement(_body)) {
          var _block$body2;
          (_block$body2 = _block.body).push.apply(_block$body2, _toConsumableArray__default["default"](_body.body));
        } else {
          _block.body.push(_body);
        }
        _block.body.push(t__namespace.continueStatement(_id));
        path.replaceWith(_closure);
      }
      if (path.isSwitchStatement()) {
        var _path$node5 = path.node,
          discriminant = _path$node5.discriminant,
          cases = _path$node5.cases;
        var _createLoop3 = createLoop(path),
          _statement4 = _createLoop3.statement;
        var _block2 = t__namespace.blockStatement([]);
        _statement4.body = _block2;
        var v = t__namespace.variableDeclaration('let', [t__namespace.variableDeclarator(t__namespace.identifier('_switchCase'))]);
        _block2.body.push(v);
        cases.forEach(function (item) {
          var completed = t__namespace.assignmentExpression('=', t__namespace.identifier('_switchCase'), t__namespace.booleanLiteral(true));
          var test = item.test && t__namespace.binaryExpression('===', discriminant, item.test);
          var testAll = test && t__namespace.logicalExpression('||', t__namespace.identifier('_switchCase'), test);
          _block2.body.push(testAll ? t__namespace.ifStatement(testAll, t__namespace.blockStatement([].concat(_toConsumableArray__default["default"](item.consequent), [t__namespace.expressionStatement(completed)]))) : t__namespace.blockStatement(item.consequent));
        });
        path.replaceWith(_statement4);
      }
      if (path.isExportNamedDeclaration() && path.node.declaration) {
        if (!t__namespace.isScopable(path.parent)) throw new Error('parent is not scopable');
        var declaration = path.node.declaration;
        path.node.declaration = null;
        var varDeclaration = declarationToVariable(declaration, applyAstTransformations, path.parentPath.scope);
        prepend(path.parent, varDeclaration, path.node);
        var declarations = varDeclaration.declarations.map(function (item) {
          return getIdentifiers(item.id);
        }).flat();
        var _iterator = _createForOfIteratorHelper$g(declarations),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var _id2 = _step.value;
            path.node.specifiers.push(t__namespace.exportSpecifier(_id2, _id2));
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      } else if (path.isExportDefaultDeclaration() && path.node.declaration) {
        if (t__namespace.isDeclaration(path.node.declaration)) {
          path.node.declaration = declarationToExpression(path.node.declaration, applyAstTransformations, path.parentPath.scope);
        }
      } else if (path.isImportDefaultSpecifier()) {
        path.replaceWith(t__namespace.importSpecifier(path.node.local, t__namespace.identifier('default')));
      } else if (path.isFunctionDeclaration()) {
        if (path.node.id && 'body' in path.parent) {
          var variable = declarationToVariable(path.node, applyAstTransformations, path.parentPath.scope);
          path.remove();
          if (!t__namespace.isScopable(path.parent)) throw new Error('parent is not scopable');
          hoise(path.parent, variable);
        }
      } else if (path.isClassDeclaration()) {
        path.replaceWith(declarationToVariable(path.node, applyAstTransformations, path.parentPath.scope));
      } else if (path.isObjectMethod()) {
        var _path$node6 = path.node,
          params = _path$node6.params,
          _body2 = _path$node6.body,
          generator = _path$node6.generator,
          async = _path$node6.async;
        var functionExpression = t__namespace.functionExpression(null, params, _body2, generator, async);
        path.replaceWith(t__namespace.objectProperty(path.node.key, functionExpression));
      } else if (path.isArrowFunctionExpression() && t__namespace.isExpression(path.node.body)) {
        path.node.body = t__namespace.blockStatement([t__namespace.returnStatement(path.node.body)]);
      } else if (path.isClassMethod() && t__namespace.isIdentifier(path.node.key) && path.node.key.name !== 'constructor') {
        var _params = path.node.params.filter(function (p) {
          return !t__namespace.isTSParameterProperty(p);
        });
        var _functionExpression = t__namespace.functionExpression(null, _params, path.node.body);
        var parent = path.parentPath;
        if (!parent.isClassBody()) throw new Error('parent is not class body');
        parent.node.body.unshift(t__namespace.classProperty(path.node.key, _functionExpression));
        path.remove();
      }
    }
  }, scope);
  return node;
}
function omitBlockStatements(node, scope) {
  traverse__default["default"](node, {
    enter: function enter(path) {
      if (path.isBlockStatement() && path.parentPath.isScopable()) {
        if (path.node.body.length > 0 && !path.node.body.some(function (item) {
          return t__namespace.isVariableDeclaration(item);
        })) {
          var create = path.parentPath.isBlockStatement() ? t__namespace.blockStatement : t__namespace.program;
          if (path.parentPath.isBlockStatement() || path.parentPath.isProgram()) {
            var body = path.parentPath.node.body.map(function (item) {
              return item === path.node ? path.node.body : item;
            }).flat();
            path.parentPath.replaceWith(create(body));
          }
        }
      }
      if (path.isIfStatement()) {
        if (t__namespace.isBlockStatement(path.node.consequent) && path.node.consequent.body.length === 1 && !t__namespace.isVariableDeclaration(path.node.consequent.body[0])) {
          path.replaceWith(t__namespace.ifStatement(path.node.test, path.node.consequent.body[0], path.node.alternate));
        }
        if (t__namespace.isBlockStatement(path.node.alternate) && path.node.alternate.body.length === 1 && !t__namespace.isVariableDeclaration(path.node.alternate.body[0])) {
          path.replaceWith(t__namespace.ifStatement(path.node.test, path.node.consequent, path.node.alternate.body[0]));
        }
      }
      if (path.isBlockStatement() && path.parentPath.isLabeledStatement() && path.node.body.length === 1 && !t__namespace.isVariableDeclaration(path.node.body[0])) {
        path.parentPath.replaceWith(t__namespace.labeledStatement(path.parentPath.node.label, path.node.body[0]));
      }
      // if (path.isBlockStatement() && path.parentPath.isProgram()) {
      //   if (path.parentPath.node.body.length === 1) {
      //     path.replaceWith(t.program(path.node))
      //   }
      // }
    }
  }, scope);
}
function applyAstReverseTransformations(node, scope) {
  var n = t__namespace.isProgram(node) ? t__namespace.file(node) : node;
  traverse__default["default"](n, {
    enter: function enter(path) {
      if (path.isObjectProperty()) {
        if (path.node.computed && t__namespace.isStringLiteral(path.node.key)) {
          path.replaceWith(t__namespace.objectProperty(t__namespace.identifier(path.node.key.value), path.node.value, false, path.node.shorthand, path.node.decorators));
        }
      }
      if (path.isMemberExpression()) {
        if (path.node.computed && t__namespace.isStringLiteral(path.node.property)) {
          path.replaceWith(t__namespace.memberExpression(path.node.object, t__namespace.identifier(path.node.property.value), false, path.node.optional));
        }
      }
    }
  }, scope);
  omitBlockStatements(n, scope);

  // omit else after trailing break/continue
  traverse__default["default"](n, {
    enter: function enter(path) {
      if (path.isIfStatement()) {
        var _path$node7 = path.node,
          test = _path$node7.test,
          consequent = _path$node7.consequent,
          alternate = _path$node7.alternate;
        var lastConsequentStatement = getLast(consequent);
        if (alternate && (t__namespace.isBreakStatement(lastConsequentStatement) || t__namespace.isContinueStatement(lastConsequentStatement))) {
          if (t__namespace.isIfStatement(path.parent) && path.key === 'consequent') {
            path.parentPath.replaceWith(t__namespace.ifStatement(path.parent.test, t__namespace.blockStatement([path.node]), path.parent.alternate));
          }
          path.insertAfter(alternate);
          path.replaceWith(t__namespace.ifStatement(test, consequent));
        }
      }
    }
  }, scope);
  omitBlockStatements(n, scope);

  // do while
  traverse__default["default"](n, {
    enter: function enter(path) {
      if (path.isLabeledStatement()) {
        var body = path.node.body;
        if (t__namespace.isBlockStatement(body)) {
          var last = body.body[body.body.length - 1];
          if (t__namespace.isIfStatement(last)) {
            if (t__namespace.isContinueStatement(last.consequent) && (!last.alternate || t__namespace.isBreakStatement(last.alternate))) {
              var _last$consequent$labe;
              if (((_last$consequent$labe = last.consequent.label) === null || _last$consequent$labe === void 0 ? void 0 : _last$consequent$labe.name) === path.node.label.name) {
                path.replaceWith(t__namespace.labeledStatement(path.node.label, t__namespace.doWhileStatement(last.test, t__namespace.blockStatement(body.body.slice(0, body.body.length - 1)))));
              }
            }
          }
        }
      }
    }
  }, scope);
  traverse__default["default"](n, {
    enter: function enter(path) {
      if (path.isLabeledStatement()) {
        var body = path.node.body;
        if (t__namespace.isIfStatement(body)) {
          var _last$label;
          var last = getLast(body.consequent);
          if (t__namespace.isContinueStatement(last) && ((_last$label = last.label) === null || _last$label === void 0 ? void 0 : _last$label.name) === path.node.label.name) {
            path.replaceWith(t__namespace.labeledStatement(path.node.label, t__namespace.whileStatement(body.test, body.consequent)));
            if (body.alternate) append(path.parent, body.alternate, path.node);
          }
        }
      }
    }
  }, scope);

  // remove redundant continue statements
  traverse__default["default"](n, {
    enter: function enter(path) {
      if (path.isWhileStatement() && t__namespace.isLabeledStatement(path.parent)) {
        var _last$label2;
        var last = getLast(path.node.body);
        if (t__namespace.isContinueStatement(last) && path.parent.label.name === ((_last$label2 = last.label) === null || _last$label2 === void 0 ? void 0 : _last$label2.name)) {
          path.traverse({
            enter: function enter(continuePath) {
              if (continuePath.node === last) continuePath.remove();
            }
          });
        }
      }
    }
  }, scope);

  // remove unused labels
  traverse__default["default"](n, {
    enter: function enter(path) {
      if (path.isLabeledStatement()) {
        var used = false;
        path.traverse({
          enter: function enter(nestedPath) {
            if (nestedPath.isBreakStatement() || nestedPath.isContinueStatement()) {
              var _nestedPath$node$labe;
              if (((_nestedPath$node$labe = nestedPath.node.label) === null || _nestedPath$node$labe === void 0 ? void 0 : _nestedPath$node$labe.name) === path.node.label.name) {
                used = true;
              }
            }
          }
        });
        if (!used) path.replaceWith(path.node.body);
      }
    }
  }, scope);
  return n;
}
function getLast(statement) {
  if (t__namespace.isBlockStatement(statement)) {
    return getLast(statement.body[statement.body.length - 1]);
  }
  return statement;
}

function _createForOfIteratorHelper$f(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$f(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$f(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$f(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$f(o, minLen); }
function _arrayLikeToArray$f(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$o(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$o(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$o() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var AddControls = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](AddControls, _Transformer);
  var _super = _createSuper$o(AddControls);
  function AddControls() {
    _classCallCheck__default["default"](this, AddControls);
    return _super.call(this, 'add controls');
  }
  _createClass__default["default"](AddControls, [{
    key: "createInsertButton",
    value: function createInsertButton(key, side, needControl) {
      return new reteStudioCore.InsertControl({
        action: ['insert', {
          key: key,
          side: side,
          needControl: needControl
        }]
      });
    }
  }, {
    key: "createOutputIdentifierControl",
    value: function createOutputIdentifierControl(identifier, key) {
      // TODO
      var control = new reteStudioCore.InputControl({
        action: ['change-output-identifier', {
          key: key
        }],
        type: 'identifier',
        initial: identifier,
        allowedTypes: ['identifier']
      });
      return control;
    }
  }, {
    key: "createTextControl",
    value: function createTextControl(value, key) {
      var control = new reteStudioCore.InputControl({
        action: ['change-key-text', {
          key: key
        }],
        type: 'text',
        initial: value
      });
      return control;
    }
  }, {
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        var _this = this;
        var editor, _iterator, _step, _loop;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              editor = context.editor;
              _iterator = _createForOfIteratorHelper$f(editor.getNodes());
              _context2.prev = 2;
              _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                var node, entry, input, _input, _i, _Object$entries, _Object$entries$_i, key, _input2, left, right, keyInput, options, init, _options, outputs, _iterator2, _step2, _step2$value, _key, output, control;
                return _regeneratorRuntime__default["default"].wrap(function _loop$(_context) {
                  while (1) switch (_context.prev = _context.next) {
                    case 0:
                      node = _step.value;
                      if (['ClassBody'].includes(node.label)) {
                        node.addControl('insert', _this.createInsertButton('body', 'input'));
                      }
                      if (['CallExpression'].includes(node.label)) {
                        node.addControl('insert', _this.createInsertButton('arguments', 'input', true));
                      }
                      if (['ArrayExpression'].includes(node.label)) {
                        node.addControl('insert', _this.createInsertButton('elements', 'input', true));
                      }
                      if (['ObjectExpression'].includes(node.label)) {
                        node.addControl('insert', _this.createInsertButton('properties', 'input'));
                      }
                      if (!['FunctionExpression', 'ArrowFunctionExpression', 'Constructor'].includes(node.label)) {
                        _context.next = 10;
                        break;
                      }
                      entry = editor.getNodes().find(function (n) {
                        return n.parent === node.id && n.label === 'Entry';
                      });
                      if (entry) {
                        _context.next = 9;
                        break;
                      }
                      throw new Error('AddControls: entry node not found');
                    case 9:
                      entry.addControl('insert', _this.createInsertButton('params', 'output', true));
                    case 10:
                      if (['ThrowStatement'].includes(node.label)) {
                        input = node.inputs['argument'];
                        if (!input.control) {
                          input.control = new reteStudioCore.InputControl({
                            action: 'change-throw',
                            type: 'text'
                          });
                        }
                      }
                      if (['ExpressionStatement'].includes(node.label)) {
                        _input = node.inputs['expression'];
                        if (!_input.control) {
                          _input.control = new reteStudioCore.InputControl({
                            action: 'change-expression',
                            type: 'identifier'
                          });
                        }
                      }
                      if (['ArrayExpression'].includes(node.label)) {
                        for (_i = 0, _Object$entries = Object.entries(node.inputs); _i < _Object$entries.length; _i++) {
                          _Object$entries$_i = _slicedToArray__default["default"](_Object$entries[_i], 2), key = _Object$entries$_i[0], _input2 = _Object$entries$_i[1];
                          if (_input2 && key.startsWith('elements')) {
                            if (!_input2.control) {
                              _input2.control = new reteStudioCore.InputControl({
                                action: 'change-array-element',
                                type: 'identifier'
                              });
                            }
                          }
                        }
                      }
                      if (['BinaryExpression'].includes(node.label)) {
                        left = node.inputs['left'];
                        right = node.inputs['right'];
                        if (!left.control) {
                          left.control = new reteStudioCore.InputControl({
                            action: 'change-left',
                            type: 'identifier'
                          });
                        }
                        if (!right.control) {
                          right.control = new reteStudioCore.InputControl({
                            action: 'change-right',
                            type: 'identifier'
                          });
                        }
                      }
                      if (['RegExpLiteral'].includes(node.label)) {
                        node.addControl('pattern', _this.createTextControl(String(node.data.pattern), 'pattern'));
                        node.addControl('flags', _this.createTextControl(String(node.data.flags || ''), 'flags'));
                      }
                      if (['ObjectProperty'].includes(node.label)) {
                        keyInput = node.inputs['key'];
                        if (!keyInput.control) keyInput.addControl(new reteStudioCore.InputControl({
                          action: 'change-object-property-key',
                          type: 'text',
                          initial: ''
                        }));
                      }
                      if (['VariableDeclarator'].includes(node.label)) {
                        options = [{
                          value: 'var',
                          label: 'Var'
                        }, {
                          value: 'let',
                          label: 'Let'
                        }, {
                          value: 'const',
                          label: 'Const'
                        }];
                        init = node.inputs['init'];
                        if (!init.control) init.addControl(new reteStudioCore.InputControl({
                          action: 'change-var-identifier',
                          type: 'identifier',
                          initial: ''
                        }));
                        node.addControl('kind', new reteStudioCore.SelectControl({
                          action: 'select-var-kind',
                          value: String(node.data.kind),
                          options: options
                        }));
                      }
                      if (['UpdateExpression'].includes(node.label) && ['++', '--'].includes(String(node.data.operator))) {
                        _options = [{
                          value: 'prefix',
                          label: 'Prefix'
                        }, {
                          value: 'postfix',
                          label: 'Postfix'
                        }];
                        node.addControl('prefix', new reteStudioCore.SelectControl({
                          action: 'select-update-prefix',
                          value: node.data.prefix ? 'prefix' : 'postfix',
                          options: _options
                        }));
                      }
                      outputs = Object.entries(node.outputs).filter(function (_ref) {
                        var _ref2 = _slicedToArray__default["default"](_ref, 2),
                          output = _ref2[1];
                        return output && output.socket instanceof reteStudioCore.RefSocket;
                      });
                      _iterator2 = _createForOfIteratorHelper$f(outputs);
                      _context.prev = 20;
                      _iterator2.s();
                    case 22:
                      if ((_step2 = _iterator2.n()).done) {
                        _context.next = 30;
                        break;
                      }
                      _step2$value = _slicedToArray__default["default"](_step2.value, 2), _key = _step2$value[0], output = _step2$value[1];
                      if (output.socket.identifier) {
                        _context.next = 26;
                        break;
                      }
                      throw new Error('AddControls: output identifier not found');
                    case 26:
                      control = _this.createOutputIdentifierControl(output.socket.identifier, _key);
                      output.addControl(control);
                    case 28:
                      _context.next = 22;
                      break;
                    case 30:
                      _context.next = 35;
                      break;
                    case 32:
                      _context.prev = 32;
                      _context.t0 = _context["catch"](20);
                      _iterator2.e(_context.t0);
                    case 35:
                      _context.prev = 35;
                      _iterator2.f();
                      return _context.finish(35);
                    case 38:
                    case "end":
                      return _context.stop();
                  }
                }, _loop, null, [[20, 32, 35, 38]]);
              });
              _iterator.s();
            case 5:
              if ((_step = _iterator.n()).done) {
                _context2.next = 9;
                break;
              }
              return _context2.delegateYield(_loop(), "t0", 7);
            case 7:
              _context2.next = 5;
              break;
            case 9:
              _context2.next = 14;
              break;
            case 11:
              _context2.prev = 11;
              _context2.t1 = _context2["catch"](2);
              _iterator.e(_context2.t1);
            case 14:
              _context2.prev = 14;
              _iterator.f();
              return _context2.finish(14);
            case 17:
            case "end":
              return _context2.stop();
          }
        }, _callee, null, [[2, 11, 14, 17]]);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        var editor, _iterator3, _step3, node, identifierInputs, _iterator4, _step4, _step4$value, input, control;
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              editor = context.editor;
              _iterator3 = _createForOfIteratorHelper$f(editor.getNodes());
              try {
                for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                  node = _step3.value;
                  identifierInputs = Object.entries(node.inputs).filter(function (_ref3) {
                    var _input$control$option;
                    var _ref4 = _slicedToArray__default["default"](_ref3, 2),
                      input = _ref4[1];
                    return input && input.control instanceof reteStudioCore.InputControl && ((_input$control$option = input.control.options) === null || _input$control$option === void 0 ? void 0 : _input$control$option.type) === 'identifier';
                  }).map(function (_ref5) {
                    var _ref6 = _slicedToArray__default["default"](_ref5, 2),
                      key = _ref6[0],
                      input = _ref6[1];
                    return [key, input, input === null || input === void 0 ? void 0 : input.control];
                  });
                  _iterator4 = _createForOfIteratorHelper$f(identifierInputs);
                  try {
                    for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
                      _step4$value = _slicedToArray__default["default"](_step4.value, 3), input = _step4$value[1], control = _step4$value[2];
                      if (!control.value) input.removeControl();
                    }
                  } catch (err) {
                    _iterator4.e(err);
                  } finally {
                    _iterator4.f();
                  }
                }
              } catch (err) {
                _iterator3.e(err);
              } finally {
                _iterator3.f();
              }
            case 3:
            case "end":
              return _context3.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return AddControls;
}(reteStudioCore.Transformer);

function _createSuper$n(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$n(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$n() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var AddFlowPlaceholder = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](AddFlowPlaceholder, _Transformer);
  var _super = _createSuper$n(AddFlowPlaceholder);
  function AddFlowPlaceholder() {
    _classCallCheck__default["default"](this, AddFlowPlaceholder);
    return _super.call(this, 'Add flow placeholder');
  }
  _createClass__default["default"](AddFlowPlaceholder, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return reteStudioCore.patchPlaceholderPorts(function (node) {
                if (node.label === 'IfStatement') return {
                  outputs: [{
                    key: 'alternate',
                    flow: true
                  }]
                };
                if (node.label === 'TryStatement') return {
                  outputs: [{
                    key: 'finalizer',
                    flow: true
                  }]
                };
                if (node.label === 'LabeledStatement') return {
                  outputs: [{
                    key: 'alternate',
                    flow: true
                  }]
                };
              })(context);
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(_ref) {
        var editor, _i, _arr, node;
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              editor = _ref.editor;
              _i = 0, _arr = _toConsumableArray__default["default"](editor.getNodes());
            case 2:
              if (!(_i < _arr.length)) {
                _context2.next = 10;
                break;
              }
              node = _arr[_i];
              if (!(node.label === 'Placeholder')) {
                _context2.next = 7;
                break;
              }
              _context2.next = 7;
              return reteStudioCore.Utils.removeNodeWithConnections(editor, node.id);
            case 7:
              _i++;
              _context2.next = 2;
              break;
            case 10:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return AddFlowPlaceholder;
}(reteStudioCore.Transformer);

function _createSuper$m(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$m(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$m() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var CleanUpPorts = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](CleanUpPorts, _Transformer);
  var _super = _createSuper$m(CleanUpPorts);
  function CleanUpPorts() {
    _classCallCheck__default["default"](this, CleanUpPorts);
    return _super.call(this, 'Clean up ports');
  }
  _createClass__default["default"](CleanUpPorts, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        var editor;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              editor = context.editor;
              _context.next = 3;
              return reteStudioCore.cleanUpPorts(function (node) {
                if (node.type === 'expression') return {
                  inputs: [reteStudioCore.BIND_KEY],
                  outputs: [reteStudioCore.BIND_KEY]
                };
                if (node.label === 'IfStatement') return {
                  outputs: [reteStudioCore.BIND_KEY]
                };
                if (node.label === 'TryStatement') return {
                  outputs: [reteStudioCore.BIND_KEY]
                };
                if (node.label === 'CatchClause') return {
                  outputs: ['body']
                };
                if (node.label === 'Closure') return {
                  inputs: [reteStudioCore.BIND_KEY],
                  outputs: [reteStudioCore.BIND_KEY]
                };
                if (node.label === 'Constructor') return {
                  inputs: [reteStudioCore.BIND_KEY]
                };
                if (['FunctionExpression', 'ArrowFunctionExpression', 'ClassExpression'].includes(node.label)) return {
                  inputs: [reteStudioCore.BIND_KEY]
                };
                if (node.label === 'Entry') {
                  var outputs = [];
                  var parent = node.parent ? editor.getNode(node.parent) : null;
                  if ((parent === null || parent === void 0 ? void 0 : parent.label) === 'ClassExpression') {
                    outputs.push('body');
                  } else if ((parent === null || parent === void 0 ? void 0 : parent.label) === 'Constructor') {
                    outputs.push('key');
                  }
                  return {
                    inputs: [reteStudioCore.BIND_KEY],
                    outputs: [reteStudioCore.BIND_KEY].concat(outputs)
                  };
                }
              }, function (node, key, port) {
                if (port !== null && port !== void 0 && port.control) {
                  node.addControl(key, port.control);
                }
              })(context);
            case 3:
              _context.next = 5;
              return reteStudioCore.ensurePorts(function (node) {
                if (node.label === 'VariableDeclarator') {
                  return {
                    inputs: ['init']
                  };
                }
              }, function () {
                return null;
              })(context);
            case 5:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        var editor;
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              editor = context.editor;
              _context2.next = 3;
              return reteStudioCore.ensurePorts(function (node) {
                if (node.label === 'Entry') {
                  var extra = [];
                  var parent = node.parent ? editor.getNode(node.parent) : null;
                  if ((parent === null || parent === void 0 ? void 0 : parent.label) === 'ClassExpression') {
                    extra.push('body');
                  } else if ((parent === null || parent === void 0 ? void 0 : parent.label) === 'Constructor') {
                    extra.push(['key', function () {
                      return new reteStudioCore.RefSocket('Reference', 'constructor');
                    }]);
                  }
                  return {
                    inputs: [reteStudioCore.BIND_KEY],
                    outputs: [reteStudioCore.BIND_KEY].concat(extra)
                  };
                }
                return {
                  inputs: [reteStudioCore.BIND_KEY],
                  outputs: [reteStudioCore.BIND_KEY]
                };
              }, function () {
                return null;
              })(context);
            case 3:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return CleanUpPorts;
}(reteStudioCore.Transformer);

function _createSuper$l(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$l(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$l() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var ClearUnknown = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](ClearUnknown, _Transformer);
  var _super = _createSuper$l(ClearUnknown);
  function ClearUnknown() {
    _classCallCheck__default["default"](this, ClearUnknown);
    return _super.call(this, 'Clear unknown');
  }
  _createClass__default["default"](ClearUnknown, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return reteStudioCore.removeRedunantNodes(function (node) {
                return node.type === 'unknown' && Boolean(node.data.reasonCode);
              })(context);
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
            case 1:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return ClearUnknown;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$e(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$e(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$e(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$e(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$e(o, minLen); }
function _arrayLikeToArray$e(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$k(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$k(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$k() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var ExpressionIntoStatement = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](ExpressionIntoStatement, _Transformer);
  var _super = _createSuper$k(ExpressionIntoStatement);
  function ExpressionIntoStatement() {
    _classCallCheck__default["default"](this, ExpressionIntoStatement);
    return _super.call(this, 'Expression into statement');
  }
  _createClass__default["default"](ExpressionIntoStatement, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.forEach(function (n) {
                return n.label === 'ExpressionStatement';
              }, /*#__PURE__*/function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(node, context) {
                  var _getInputNode, _getInputNode2, expression;
                  return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        _getInputNode = reteStudioCore.getInputNode(context, node.id, 'expression', false), _getInputNode2 = _slicedToArray__default["default"](_getInputNode, 1), expression = _getInputNode2[0];
                        if (expression) {
                          _context.next = 3;
                          break;
                        }
                        return _context.abrupt("return");
                      case 3:
                        if (!(expression.type !== 'expression')) {
                          _context.next = 5;
                          break;
                        }
                        return _context.abrupt("return");
                      case 5:
                        if (['AssignmentExpression', 'CallExpression', 'UpdateExpression', 'YieldExpression', 'NewExpression'].includes(expression.label)) {
                          _context.next = 7;
                          break;
                        }
                        return _context.abrupt("return");
                      case 7:
                        _context.next = 9;
                        return reteStudioCore.mergeSiblingNodes(expression, node)(context);
                      case 9:
                        _context.next = 11;
                        return reteStudioCore.Utils.removeInputConnections(context.editor, node.id, ['expression']);
                      case 11:
                        node.removeInput('expression');
                        node.label = expression.label;
                      case 13:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }));
                return function (_x2, _x3) {
                  return _ref.apply(this, arguments);
                };
              }())(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.next = 2;
              return (// unmerge statements
                function () {
                  var _ref2 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
                    var editor, nodes, _iterator, _step, _loop;
                    return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context4) {
                      while (1) switch (_context4.prev = _context4.next) {
                        case 0:
                          editor = context.editor;
                          nodes = editor.getNodes().filter(function (n) {
                            return n.type === 'statement';
                          }).filter(function (n) {
                            return ['AssignmentExpression', 'CallExpression', 'UpdateExpression', 'YieldExpression', 'NewExpression'].includes(n.label);
                          });
                          _iterator = _createForOfIteratorHelper$e(nodes);
                          _context4.prev = 3;
                          _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                            var statement, expression, cons, _iterator2, _step2, c;
                            return _regeneratorRuntime__default["default"].wrap(function _loop$(_context3) {
                              while (1) switch (_context3.prev = _context3.next) {
                                case 0:
                                  statement = _step.value;
                                  expression = statement.clone();
                                  expression.type = 'expression';
                                  _context3.next = 5;
                                  return editor.addNode(expression);
                                case 5:
                                  cons = editor.getConnections().filter(function (c) {
                                    return c.target === statement.id && c.targetInput !== reteStudioCore.BIND_KEY;
                                  });
                                  _iterator2 = _createForOfIteratorHelper$e(cons);
                                  _context3.prev = 7;
                                  _iterator2.s();
                                case 9:
                                  if ((_step2 = _iterator2.n()).done) {
                                    _context3.next = 17;
                                    break;
                                  }
                                  c = _step2.value;
                                  _context3.next = 13;
                                  return editor.removeConnection(c.id);
                                case 13:
                                  _context3.next = 15;
                                  return editor.addConnection(new reteStudioCore.Connection(editor.getNode(c.source), c.sourceOutput, expression, c.targetInput));
                                case 15:
                                  _context3.next = 9;
                                  break;
                                case 17:
                                  _context3.next = 22;
                                  break;
                                case 19:
                                  _context3.prev = 19;
                                  _context3.t0 = _context3["catch"](7);
                                  _iterator2.e(_context3.t0);
                                case 22:
                                  _context3.prev = 22;
                                  _iterator2.f();
                                  return _context3.finish(22);
                                case 25:
                                  Object.keys(statement.inputs).forEach(function (key) {
                                    if (key !== reteStudioCore.BIND_KEY) statement.removeInput(key);
                                  });
                                  statement.label = 'ExpressionStatement';
                                  statement.addInput('expression', new reteStudioCore.Input(reteStudioCore.socket, 'expression', true));
                                  _context3.next = 30;
                                  return editor.addConnection(new reteStudioCore.Connection(expression, reteStudioCore.BIND_KEY, statement, 'expression'));
                                case 30:
                                case "end":
                                  return _context3.stop();
                              }
                            }, _loop, null, [[7, 19, 22, 25]]);
                          });
                          _iterator.s();
                        case 6:
                          if ((_step = _iterator.n()).done) {
                            _context4.next = 10;
                            break;
                          }
                          return _context4.delegateYield(_loop(), "t0", 8);
                        case 8:
                          _context4.next = 6;
                          break;
                        case 10:
                          _context4.next = 15;
                          break;
                        case 12:
                          _context4.prev = 12;
                          _context4.t1 = _context4["catch"](3);
                          _iterator.e(_context4.t1);
                        case 15:
                          _context4.prev = 15;
                          _iterator.f();
                          return _context4.finish(15);
                        case 18:
                        case "end":
                          return _context4.stop();
                      }
                    }, _callee3, null, [[3, 12, 15, 18]]);
                  }));
                  return function (_x5) {
                    return _ref2.apply(this, arguments);
                  };
                }()(context)
              );
            case 2:
            case "end":
              return _context5.stop();
          }
        }, _callee4);
      }));
      function down(_x4) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return ExpressionIntoStatement;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$d(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$d(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$d(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$d(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$d(o, minLen); }
function _arrayLikeToArray$d(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$j(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$j(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$j() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var InnerPorts = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](InnerPorts, _Transformer);
  var _super = _createSuper$j(InnerPorts);
  function InnerPorts() {
    _classCallCheck__default["default"](this, InnerPorts);
    return _super.call(this, 'Inner ports');
  }
  _createClass__default["default"](InnerPorts, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        var editor;
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              editor = context.editor;
              _context2.next = 3;
              return reteStudioCore.forEach(function (node) {
                return node.label === 'ClassBody';
              }, /*#__PURE__*/function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(node) {
                  var _getInputNode, _getInputNode2, entryConnection;
                  return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        _getInputNode = reteStudioCore.getInputNode(context, node.id, reteStudioCore.BIND_KEY), _getInputNode2 = _slicedToArray__default["default"](_getInputNode, 2), entryConnection = _getInputNode2[1];
                        _context.next = 3;
                        return editor.removeConnection(entryConnection.id);
                      case 3:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }));
                return function (_x2) {
                  return _ref.apply(this, arguments);
                };
              }())(context);
            case 3:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
        var editor, classBodies, _iterator, _step, _loop;
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              editor = context.editor;
              classBodies = editor.getNodes().filter(function (node) {
                return node.label === 'ClassBody';
              });
              _iterator = _createForOfIteratorHelper$d(classBodies);
              _context4.prev = 3;
              _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                var classBody, entry;
                return _regeneratorRuntime__default["default"].wrap(function _loop$(_context3) {
                  while (1) switch (_context3.prev = _context3.next) {
                    case 0:
                      classBody = _step.value;
                      entry = editor.getNodes().find(function (node) {
                        return node.parent === classBody.parent && node.label === 'Entry';
                      });
                      if (entry) {
                        _context3.next = 4;
                        break;
                      }
                      throw new Error('InnerPorts: Entry not found');
                    case 4:
                      _context3.next = 6;
                      return editor.addConnection(new reteStudioCore.Connection(entry, 'body', classBody, reteStudioCore.BIND_KEY));
                    case 6:
                    case "end":
                      return _context3.stop();
                  }
                }, _loop);
              });
              _iterator.s();
            case 6:
              if ((_step = _iterator.n()).done) {
                _context4.next = 10;
                break;
              }
              return _context4.delegateYield(_loop(), "t0", 8);
            case 8:
              _context4.next = 6;
              break;
            case 10:
              _context4.next = 15;
              break;
            case 12:
              _context4.prev = 12;
              _context4.t1 = _context4["catch"](3);
              _iterator.e(_context4.t1);
            case 15:
              _context4.prev = 15;
              _iterator.f();
              return _context4.finish(15);
            case 18:
            case "end":
              return _context4.stop();
          }
        }, _callee3, null, [[3, 12, 15, 18]]);
      }));
      function down(_x3) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return InnerPorts;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$c(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$c(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$c(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$c(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$c(o, minLen); }
function _arrayLikeToArray$c(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$i(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$i(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$i() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var LiteralsToControls = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](LiteralsToControls, _Transformer);
  var _super = _createSuper$i(LiteralsToControls);
  function LiteralsToControls() {
    var _this;
    _classCallCheck__default["default"](this, LiteralsToControls);
    _this = _super.call(this, 'literals to controls');
    _defineProperty__default["default"](_assertThisInitialized__default["default"](_this), "types", {
      'StringLiteral': ['text', ''],
      'NumericLiteral': ['number', 0],
      'BooleanLiteral': ['boolean', false],
      'NullLiteral': ['null', null]
      // 'BigIntLiteral': ['bigint', 0n] // TODO
    });
    return _this;
  }
  _createClass__default["default"](LiteralsToControls, [{
    key: "literalToType",
    value: function literalToType(label) {
      return this.types[label][0];
    }
  }, {
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        var _this2 = this;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return reteStudioCore.simplifyLiterals(function (node) {
                var literals = ['StringLiteral', 'NumericLiteral', 'NullLiteral', 'DecimalLiteral', 'BooleanLiteral', 'BigIntLiteral'];
                return [].concat(literals, ['Identifier']).includes(node.label);
              }, function (node) {
                if (node.label === 'Identifier') {
                  return new reteStudioCore.InputControl({
                    action: 'change-identifier',
                    type: 'identifier',
                    initial: String(node.data.name)
                  });
                }
                var type = _this2.literalToType(node.label);
                var control = new reteStudioCore.InputControl({
                  action: 'change-literal',
                  type: type,
                  readonly: false
                });
                control.setValue(node.data.value);
                return control;
              })(context);
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "typeToLiteral",
    value: function typeToLiteral(type) {
      var literal = Object.entries(this.types).find(function (_ref) {
        var _ref2 = _slicedToArray__default["default"](_ref, 2);
          _ref2[0];
          var t = _ref2[1];
        return t[0] === type;
      });
      if (!literal) throw new Error("Unknown type ".concat(type));
      return [literal[0], literal[1][1]];
    }
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee5(context) {
        var _this3 = this;
        return _regeneratorRuntime__default["default"].wrap(function _callee5$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              _context7.next = 2;
              return function () {
                var _ref3 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4(context) {
                  var editor, addIdentifier, _addIdentifier, addLiteral, _addLiteral, nodes, _iterator, _step, _loop;
                  return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context6) {
                    while (1) switch (_context6.prev = _context6.next) {
                      case 0:
                        _addLiteral = function _addLiteral3() {
                          _addLiteral = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(label, value, parent) {
                            var node;
                            return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
                              while (1) switch (_context3.prev = _context3.next) {
                                case 0:
                                  node = new reteStudioCore.BaseNode(label);
                                  node.type = 'expression';
                                  node.data.value = value; // TODO
                                  node.parent = parent;
                                  _context3.next = 6;
                                  return editor.addNode(node);
                                case 6:
                                  return _context3.abrupt("return", node);
                                case 7:
                                case "end":
                                  return _context3.stop();
                              }
                            }, _callee3);
                          }));
                          return _addLiteral.apply(this, arguments);
                        };
                        addLiteral = function _addLiteral2(_x6, _x7, _x8) {
                          return _addLiteral.apply(this, arguments);
                        };
                        _addIdentifier = function _addIdentifier3() {
                          _addIdentifier = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(name, parent) {
                            var node;
                            return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
                              while (1) switch (_context2.prev = _context2.next) {
                                case 0:
                                  node = new reteStudioCore.BaseNode('Identifier');
                                  node.type = 'expression';
                                  node.data.name = name;
                                  node.parent = parent;
                                  _context2.next = 6;
                                  return editor.addNode(node);
                                case 6:
                                  return _context2.abrupt("return", node);
                                case 7:
                                case "end":
                                  return _context2.stop();
                              }
                            }, _callee2);
                          }));
                          return _addIdentifier.apply(this, arguments);
                        };
                        addIdentifier = function _addIdentifier2(_x4, _x5) {
                          return _addIdentifier.apply(this, arguments);
                        };
                        editor = context.editor;
                        nodes = _toConsumableArray__default["default"](editor.getNodes());
                        _iterator = _createForOfIteratorHelper$c(nodes);
                        _context6.prev = 7;
                        _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                          var node, inputs, _loop2, _i, _inputs;
                          return _regeneratorRuntime__default["default"].wrap(function _loop$(_context5) {
                            while (1) switch (_context5.prev = _context5.next) {
                              case 0:
                                node = _step.value;
                                inputs = Object.entries(node.inputs);
                                _loop2 = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop2() {
                                  var _control$options;
                                  var _inputs$_i, key, input, control, inputConnections, type, name, identifier, _control$value, _this3$typeToLiteral, _this3$typeToLiteral2, label, defaultValue, literal;
                                  return _regeneratorRuntime__default["default"].wrap(function _loop2$(_context4) {
                                    while (1) switch (_context4.prev = _context4.next) {
                                      case 0:
                                        _inputs$_i = _slicedToArray__default["default"](_inputs[_i], 2), key = _inputs$_i[0], input = _inputs$_i[1];
                                        control = input === null || input === void 0 ? void 0 : input.control;
                                        inputConnections = editor.getConnections().filter(function (c) {
                                          return c.targetInput === key && c.target === node.id;
                                        });
                                        if (!inputConnections.length) {
                                          _context4.next = 5;
                                          break;
                                        }
                                        return _context4.abrupt("return", 1);
                                      case 5:
                                        type = control === null || control === void 0 ? void 0 : (_control$options = control.options) === null || _control$options === void 0 ? void 0 : _control$options.type;
                                        if (!(type === 'identifier')) {
                                          _context4.next = 16;
                                          break;
                                        }
                                        name = String(control.value);
                                        _context4.next = 10;
                                        return addIdentifier(name, node.parent);
                                      case 10:
                                        identifier = _context4.sent;
                                        _context4.next = 13;
                                        return editor.addConnection(new reteStudioCore.Connection(identifier, reteStudioCore.BIND_KEY, node, key));
                                      case 13:
                                        if (input) input.control = null;
                                        _context4.next = 24;
                                        break;
                                      case 16:
                                        if (!(control && type)) {
                                          _context4.next = 24;
                                          break;
                                        }
                                        _this3$typeToLiteral = _this3.typeToLiteral(type), _this3$typeToLiteral2 = _slicedToArray__default["default"](_this3$typeToLiteral, 2), label = _this3$typeToLiteral2[0], defaultValue = _this3$typeToLiteral2[1]; // const [label, defaultValue] = type === 'boolean'
                                        //   ? ['BooleanLiteral', false]
                                        //   : (type === 'number' ? ['NumericLiteral', 0] : ['StringLiteral', ''])
                                        _context4.next = 20;
                                        return addLiteral(label, (_control$value = control.value) !== null && _control$value !== void 0 ? _control$value : defaultValue, node.parent);
                                      case 20:
                                        literal = _context4.sent;
                                        _context4.next = 23;
                                        return editor.addConnection(new reteStudioCore.Connection(literal, reteStudioCore.BIND_KEY, node, key));
                                      case 23:
                                        if (input) input.control = null;
                                      case 24:
                                      case "end":
                                        return _context4.stop();
                                    }
                                  }, _loop2);
                                });
                                _i = 0, _inputs = inputs;
                              case 4:
                                if (!(_i < _inputs.length)) {
                                  _context5.next = 11;
                                  break;
                                }
                                return _context5.delegateYield(_loop2(), "t0", 6);
                              case 6:
                                if (!_context5.t0) {
                                  _context5.next = 8;
                                  break;
                                }
                                return _context5.abrupt("continue", 8);
                              case 8:
                                _i++;
                                _context5.next = 4;
                                break;
                              case 11:
                              case "end":
                                return _context5.stop();
                            }
                          }, _loop);
                        });
                        _iterator.s();
                      case 10:
                        if ((_step = _iterator.n()).done) {
                          _context6.next = 14;
                          break;
                        }
                        return _context6.delegateYield(_loop(), "t0", 12);
                      case 12:
                        _context6.next = 10;
                        break;
                      case 14:
                        _context6.next = 19;
                        break;
                      case 16:
                        _context6.prev = 16;
                        _context6.t1 = _context6["catch"](7);
                        _iterator.e(_context6.t1);
                      case 19:
                        _context6.prev = 19;
                        _iterator.f();
                        return _context6.finish(19);
                      case 22:
                      case "end":
                        return _context6.stop();
                    }
                  }, _callee4, null, [[7, 16, 19, 22]]);
                }));
                return function (_x3) {
                  return _ref3.apply(this, arguments);
                };
              }()(context);
            case 2:
            case "end":
              return _context7.stop();
          }
        }, _callee5);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return LiteralsToControls;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$b(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$b(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$b(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$b(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$b(o, minLen); }
function _arrayLikeToArray$b(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$h(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$h(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$h() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var MarkClosures = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](MarkClosures, _Transformer);
  var _super = _createSuper$h(MarkClosures);
  function MarkClosures() {
    _classCallCheck__default["default"](this, MarkClosures);
    return _super.call(this, 'mark-closures');
  }
  _createClass__default["default"](MarkClosures, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return reteStudioCore.markClosures({
                isStart: function isStart(node) {
                  return node.label === 'Program';
                },
                isClosure: function isClosure(node) {
                  return ['BlockStatement', 'LabeledStatement', 'ClassExpression', 'ClassMethod', 'FunctionExpression', 'ArrowFunctionExpression', 'TryStatement', 'CatchClause'].includes(node.label);
                }
              })(context);
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return function () {
                var _ref2 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(_ref) {
                  var editor, closures, _iterator, _step, _loop;
                  return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context3) {
                    while (1) switch (_context3.prev = _context3.next) {
                      case 0:
                        editor = _ref.editor;
                        closures = editor.getNodes().filter(function (n) {
                          return n.label === 'Closure';
                        });
                        _iterator = _createForOfIteratorHelper$b(closures);
                        _context3.prev = 3;
                        _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                          var node;
                          return _regeneratorRuntime__default["default"].wrap(function _loop$(_context2) {
                            while (1) switch (_context2.prev = _context2.next) {
                              case 0:
                                node = _step.value;
                                reteStructures.structures(editor).children(function (n) {
                                  return n.id === node.id;
                                }).nodes().forEach(function (n) {
                                  n.parent = undefined;
                                });
                                _context2.next = 4;
                                return editor.removeNode(node.id);
                              case 4:
                              case "end":
                                return _context2.stop();
                            }
                          }, _loop);
                        });
                        _iterator.s();
                      case 6:
                        if ((_step = _iterator.n()).done) {
                          _context3.next = 10;
                          break;
                        }
                        return _context3.delegateYield(_loop(), "t0", 8);
                      case 8:
                        _context3.next = 6;
                        break;
                      case 10:
                        _context3.next = 15;
                        break;
                      case 12:
                        _context3.prev = 12;
                        _context3.t1 = _context3["catch"](3);
                        _iterator.e(_context3.t1);
                      case 15:
                        _context3.prev = 15;
                        _iterator.f();
                        return _context3.finish(15);
                      case 18:
                      case "end":
                        return _context3.stop();
                    }
                  }, _callee2, null, [[3, 12, 15, 18]]);
                }));
                return function (_x3) {
                  return _ref2.apply(this, arguments);
                };
              }()(context);
            case 2:
            case "end":
              return _context4.stop();
          }
        }, _callee3);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return MarkClosures;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$a(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$a(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$a(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$a(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$a(o, minLen); }
function _arrayLikeToArray$a(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$g(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$g(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$g() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var MarkConstructor = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](MarkConstructor, _Transformer);
  var _super = _createSuper$g(MarkConstructor);
  function MarkConstructor() {
    _classCallCheck__default["default"](this, MarkConstructor);
    return _super.call(this, 'Mark constructor');
  }
  _createClass__default["default"](MarkConstructor, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.forEach(function (n) {
                return ['ClassMethod'].includes(n.label);
              }, /*#__PURE__*/function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(node) {
                  return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        node.label = 'Constructor';
                      case 1:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }));
                return function (_x2) {
                  return _ref.apply(this, arguments);
                };
              }())(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
        var editor, nodes, _iterator, _step, node;
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              editor = context.editor;
              nodes = editor.getNodes().filter(function (n) {
                return ['Constructor'].includes(n.label);
              });
              _iterator = _createForOfIteratorHelper$a(nodes);
              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  node = _step.value;
                  node.label = 'ClassMethod';
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            case 4:
            case "end":
              return _context3.stop();
          }
        }, _callee3);
      }));
      function down(_x3) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return MarkConstructor;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$9(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$9(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$9(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$9(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$9(o, minLen); }
function _arrayLikeToArray$9(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$f(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$f(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$f() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var MarkControlSockets = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](MarkControlSockets, _Transformer);
  var _super = _createSuper$f(MarkControlSockets);
  function MarkControlSockets() {
    _classCallCheck__default["default"](this, MarkControlSockets);
    return _super.call(this, 'Mark control sockets');
  }
  _createClass__default["default"](MarkControlSockets, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        var editor, socket, _iterator, _step, node;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              editor = context.editor;
              socket = new reteStudioCore.ControlSocket('control flow');
              _iterator = _createForOfIteratorHelper$9(editor.getNodes());
              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  node = _step.value;
                  if (node.type === 'statement') {
                    if (node.inputs[reteStudioCore.BIND_KEY]) node.inputs[reteStudioCore.BIND_KEY].socket = socket;
                    if (node.outputs[reteStudioCore.BIND_KEY]) node.outputs[reteStudioCore.BIND_KEY].socket = socket;
                  }
                  if (['IfStatement'].includes(node.label)) {
                    node.outputs['consequent'].socket = socket;
                    node.outputs['consequent'].label = 'true';
                    node.outputs['alternate'].socket = socket;
                    node.outputs['alternate'].label = 'false';
                  }
                  if (['TryStatement'].includes(node.label)) {
                    node.outputs['block'].socket = socket;
                    node.outputs['handler'].socket = socket;
                    node.outputs['finalizer'].socket = socket;
                  }
                  if (['Entry'].includes(node.label)) {
                    if (node.outputs['body']) {
                      node.outputs['body'].socket = socket;
                      node.outputs['body'].index = -1;
                    }
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            case 4:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
            case 1:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return MarkControlSockets;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$8(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$8(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$8(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$8(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$8(o, minLen); }
function _arrayLikeToArray$8(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$e(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$e(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$e() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var MarkFrames = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](MarkFrames, _Transformer);
  var _super = _createSuper$e(MarkFrames);
  function MarkFrames() {
    _classCallCheck__default["default"](this, MarkFrames);
    return _super.call(this, 'apply frames');
  }
  _createClass__default["default"](MarkFrames, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        var editor, _iterator, _step, node, hasLeft, hasRight, isFrame;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              editor = context.editor;
              _iterator = _createForOfIteratorHelper$8(editor.getNodes());
              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  node = _step.value;
                  hasLeft = ['ClassExpression', 'Constructor', 'FunctionExpression', 'ArrowFunctionExpression'].includes(node.label);
                  hasRight = ['ClassExpression'].includes(node.label);
                  isFrame = hasLeft || hasRight || ['Closure'].includes(node.label);
                  if (isFrame) node.frame = {
                    left: hasLeft,
                    right: hasRight
                  };
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            case 3:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
            case 1:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return MarkFrames;
}(reteStudioCore.Transformer);

function _createSuper$d(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$d(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$d() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var MirrorDataflowExpressions = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](MirrorDataflowExpressions, _Transformer);
  var _super = _createSuper$d(MirrorDataflowExpressions);
  function MirrorDataflowExpressions() {
    _classCallCheck__default["default"](this, MirrorDataflowExpressions);
    return _super.call(this, 'Mirror dataflow expressions');
  }
  _createClass__default["default"](MirrorDataflowExpressions, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return reteStudioCore.mirrorRight(function (_ref, key) {
                var label = _ref.label;
                return ['IfStatement'].includes(label) && /^test$/.test(key) || ['ExpressionStatement'].includes(label) && /^expression$/.test(key) || ['VariableDeclarator'].includes(label) && /^(init)$/.test(key) || ['ThrowStatement'].includes(label) && /^argument$/.test(key) || ['ImportDeclaration'].includes(label) && /^(source)$/.test(key) || ['ImportSpecifier'].includes(label) && /^(imported)$/.test(key) || ['ExportNamedDeclaration'].includes(label) && /^specifiers\[.*\]$/.test(key) || ['ExportDefaultDeclaration'].includes(label) && /^declaration$/.test(key) || ['ObjectProperty'].includes(label) && /^key$/.test(key) || ['ReturnStatement'].includes(label) && /^argument$/.test(key) || ['AssignmentPattern'].includes(label) && /^right$/.test(key) || ['ClassExpression'].includes(label) && /^superClass$/.test(key) || ['ClassBody'].includes(label) && /^body\[.*\]$/.test(key);
              }, function (node, key, side) {
                return node.label === 'ObjectProperty' && side === 'input' && key === 'key';
              })(context);
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.mirrorLeft(function (_ref2, key) {
                var label = _ref2.label;
                // TODO reusable
                return ['IfStatement'].includes(label) && /^test$/.test(key) || ['ExpressionStatement'].includes(label) && /^expression$/.test(key) || ['VariableDeclarator'].includes(label) && /^(init)$/.test(key) || ['ThrowStatement'].includes(label) && /^argument$/.test(key) || ['ImportDeclaration'].includes(label) && /^(source)$/.test(key) || ['ImportSpecifier'].includes(label) && /^(imported)$/.test(key) || ['ExportNamedDeclaration'].includes(label) && /^specifiers\[.*\]$/.test(key) || ['ExportDefaultDeclaration'].includes(label) && /^declaration$/.test(key) || ['ObjectProperty'].includes(label) && /^key$/.test(key) || ['ReturnStatement'].includes(label) && /^argument$/.test(key) || ['AssignmentPattern'].includes(label) && /^right$/.test(key) || ['ClassExpression'].includes(label) && /^superClass$/.test(key) || ['ClassBody'].includes(label) && /^body\[.*\]$/.test(key);
              }, function (node, key, side) {
                return node.label === 'ObjectProperty' && side === 'input' /* TODO output ?? */ && key === 'key';
              })(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return MirrorDataflowExpressions;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$7(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$7(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$7(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$7(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$7(o, minLen); }
function _arrayLikeToArray$7(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$c(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$c(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$c() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var OmitBlockNodes = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](OmitBlockNodes, _Transformer);
  var _super = _createSuper$c(OmitBlockNodes);
  function OmitBlockNodes() {
    _classCallCheck__default["default"](this, OmitBlockNodes);
    return _super.call(this, 'Omit block nodes');
  }
  _createClass__default["default"](OmitBlockNodes, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return reteStudioCore.removeRedunantNodes(function (node) {
                return ['File', 'Program', 'VariableDeclaration', 'BlockStatement', 'Placeholder', 'EmptyStatement'].includes(node.label);
              })(context);
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "insertNode",
    value: function () {
      var _insertNode = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(_ref, node, right) {
        var editor, inputs, _iterator, _step, input, c;
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              editor = _ref.editor;
              inputs = editor.getConnections().filter(function (c) {
                return c.target === right.id && c.targetInput === reteStudioCore.BIND_KEY;
              }); // if (inputs.length > 1) throw new Error('OmitBlockNodes: Multiple inputs')
              _iterator = _createForOfIteratorHelper$7(inputs);
              _context2.prev = 3;
              _iterator.s();
            case 5:
              if ((_step = _iterator.n()).done) {
                _context2.next = 14;
                break;
              }
              input = _step.value;
              _context2.next = 9;
              return editor.removeConnection(input.id);
            case 9:
              c = new reteStudioCore.Connection(editor.getNode(input.source), input.sourceOutput, node, reteStudioCore.BIND_KEY);
              _context2.next = 12;
              return editor.addConnection(c);
            case 12:
              _context2.next = 5;
              break;
            case 14:
              _context2.next = 19;
              break;
            case 16:
              _context2.prev = 16;
              _context2.t0 = _context2["catch"](3);
              _iterator.e(_context2.t0);
            case 19:
              _context2.prev = 19;
              _iterator.f();
              return _context2.finish(19);
            case 22:
              _context2.next = 24;
              return editor.addConnection(new reteStudioCore.Connection(node, reteStudioCore.BIND_KEY, right, reteStudioCore.BIND_KEY));
            case 24:
            case "end":
              return _context2.stop();
          }
        }, _callee2, null, [[3, 16, 19, 22]]);
      }));
      function insertNode(_x2, _x3, _x4) {
        return _insertNode.apply(this, arguments);
      }
      return insertNode;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
        var _this = this;
        var editor, closures, _iterator2, _step2, _loop, variableDeclarators, _iterator3, _step3, node, variableDeclaration, catchClauses, _iterator4, _step4, catchClause, _getInputNode, _getInputNode2, blockStatement, blockStatementOutput, _getInputNode3, _getInputNode4, tryStatement, tryStatementOutput, _getOutputNode, _getOutputNode2, next, nextInput;
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              // Program, BlockStatement, VariableDeclaration
              editor = context.editor;
              closures = [undefined].concat(_toConsumableArray__default["default"](editor.getNodes().filter(function (n) {
                return n.label === 'Closure';
              })));
              _iterator2 = _createForOfIteratorHelper$7(closures);
              _context4.prev = 3;
              _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                var closure, roots, root, start;
                return _regeneratorRuntime__default["default"].wrap(function _loop$(_context3) {
                  while (1) switch (_context3.prev = _context3.next) {
                    case 0:
                      closure = _step2.value;
                      roots = (closure ? reteStructures.structures(editor).descendants(function (n) {
                        return n.id === closure.id;
                      }) : reteStructures.structures(editor)).filter(function (n) {
                        return n.label !== 'Closure';
                      }).roots().nodes()
                      // TODO if expression in wrong closure
                      .filter(function (n) {
                        return n.type === 'statement';
                      });
                      if (!(roots.length === 0)) {
                        _context3.next = 4;
                        break;
                      }
                      return _context3.abrupt("return", 1);
                    case 4:
                      if (!(roots.length > 1)) {
                        _context3.next = 6;
                        break;
                      }
                      throw new Error('OmitBlockNodes: Multiple roots');
                    case 6:
                      root = roots[0]; // if (root.label === 'LabeledStatement') continue
                      start = closure ? new reteStudioCore.BaseNode('BlockStatement') : new reteStudioCore.BaseNode('Program');
                      if (closure) {
                        start.type = 'statement';
                        start.parent = closure.id;
                      }
                      _context3.next = 11;
                      return editor.addNode(start);
                    case 11:
                      _context3.next = 13;
                      return _this.insertNode(context, start, root);
                    case 13:
                    case "end":
                      return _context3.stop();
                  }
                }, _loop);
              });
              _iterator2.s();
            case 6:
              if ((_step2 = _iterator2.n()).done) {
                _context4.next = 12;
                break;
              }
              return _context4.delegateYield(_loop(), "t0", 8);
            case 8:
              if (!_context4.t0) {
                _context4.next = 10;
                break;
              }
              return _context4.abrupt("continue", 10);
            case 10:
              _context4.next = 6;
              break;
            case 12:
              _context4.next = 17;
              break;
            case 14:
              _context4.prev = 14;
              _context4.t1 = _context4["catch"](3);
              _iterator2.e(_context4.t1);
            case 17:
              _context4.prev = 17;
              _iterator2.f();
              return _context4.finish(17);
            case 20:
              variableDeclarators = reteStructures.structures(editor).filter(function (n) {
                return n.label === 'VariableDeclarator';
              }).nodes();
              _iterator3 = _createForOfIteratorHelper$7(variableDeclarators);
              _context4.prev = 22;
              _iterator3.s();
            case 24:
              if ((_step3 = _iterator3.n()).done) {
                _context4.next = 36;
                break;
              }
              node = _step3.value;
              variableDeclaration = new reteStudioCore.BaseNode('VariableDeclaration');
              variableDeclaration.type = 'statement';
              variableDeclaration.data.kind = node.data.kind;
              variableDeclaration.parent = node.parent;
              _context4.next = 32;
              return editor.addNode(variableDeclaration);
            case 32:
              _context4.next = 34;
              return this.insertNode(context, variableDeclaration, node);
            case 34:
              _context4.next = 24;
              break;
            case 36:
              _context4.next = 41;
              break;
            case 38:
              _context4.prev = 38;
              _context4.t2 = _context4["catch"](22);
              _iterator3.e(_context4.t2);
            case 41:
              _context4.prev = 41;
              _iterator3.f();
              return _context4.finish(41);
            case 44:
              // fix CatchClause's BlockStatement
              catchClauses = editor.getNodes().filter(function (n) {
                return n.label === 'CatchClause';
              });
              _iterator4 = _createForOfIteratorHelper$7(catchClauses);
              _context4.prev = 46;
              _iterator4.s();
            case 48:
              if ((_step4 = _iterator4.n()).done) {
                _context4.next = 69;
                break;
              }
              catchClause = _step4.value;
              _getInputNode = reteStudioCore.getInputNode(context, catchClause.id, reteStudioCore.BIND_KEY), _getInputNode2 = _slicedToArray__default["default"](_getInputNode, 2), blockStatement = _getInputNode2[0], blockStatementOutput = _getInputNode2[1];
              _getInputNode3 = reteStudioCore.getInputNode(context, blockStatement.id, reteStudioCore.BIND_KEY), _getInputNode4 = _slicedToArray__default["default"](_getInputNode3, 2), tryStatement = _getInputNode4[0], tryStatementOutput = _getInputNode4[1];
              _getOutputNode = reteStudioCore.getOutputNode(context, catchClause.id, reteStudioCore.BIND_KEY, false), _getOutputNode2 = _slicedToArray__default["default"](_getOutputNode, 2), next = _getOutputNode2[0], nextInput = _getOutputNode2[1];
              _context4.next = 55;
              return editor.removeConnection(blockStatementOutput.id);
            case 55:
              _context4.next = 57;
              return editor.removeConnection(tryStatementOutput.id);
            case 57:
              if (!nextInput) {
                _context4.next = 60;
                break;
              }
              _context4.next = 60;
              return editor.removeConnection(nextInput.id);
            case 60:
              _context4.next = 62;
              return editor.addConnection(new reteStudioCore.Connection(tryStatement, tryStatementOutput.sourceOutput, catchClause, reteStudioCore.BIND_KEY));
            case 62:
              _context4.next = 64;
              return editor.addConnection(new reteStudioCore.Connection(catchClause, reteStudioCore.BIND_KEY, blockStatement, reteStudioCore.BIND_KEY));
            case 64:
              if (!next) {
                _context4.next = 67;
                break;
              }
              _context4.next = 67;
              return editor.addConnection(new reteStudioCore.Connection(blockStatement, reteStudioCore.BIND_KEY, next, reteStudioCore.BIND_KEY));
            case 67:
              _context4.next = 48;
              break;
            case 69:
              _context4.next = 74;
              break;
            case 71:
              _context4.prev = 71;
              _context4.t3 = _context4["catch"](46);
              _iterator4.e(_context4.t3);
            case 74:
              _context4.prev = 74;
              _iterator4.f();
              return _context4.finish(74);
            case 77:
            case "end":
              return _context4.stop();
          }
        }, _callee3, this, [[3, 14, 17, 20], [22, 38, 41, 44], [46, 71, 74, 77]]);
      }));
      function down(_x5) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return OmitBlockNodes;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$6(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$6(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$6(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$6(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$6(o, minLen); }
function _arrayLikeToArray$6(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$b(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$b(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$b() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var OmitBreak = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](OmitBreak, _Transformer);
  var _super = _createSuper$b(OmitBreak);
  function OmitBreak() {
    _classCallCheck__default["default"](this, OmitBreak);
    return _super.call(this, 'Omit break');
  }
  _createClass__default["default"](OmitBreak, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.forEach(function (n) {
                return n.label === 'BreakStatement';
              }, /*#__PURE__*/function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(node, context) {
                  var editor, createConnection, labeledStatement, _getOutputNode, _getOutputNode2, end, endCon, _getInputNode, _getInputNode2, source, sourceCon, _getOutputNode3, _getOutputNode4, labelNode;
                  return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        editor = context.editor, createConnection = context.createConnection;
                        labeledStatement = reteStudioCore.findLabeledStatement(context, node.id);
                        _getOutputNode = reteStudioCore.getOutputNode(context, labeledStatement.id, 'alternate', false), _getOutputNode2 = _slicedToArray__default["default"](_getOutputNode, 2), end = _getOutputNode2[0], endCon = _getOutputNode2[1];
                        _getInputNode = reteStudioCore.getInputNode(context, node.id, reteStudioCore.BIND_KEY), _getInputNode2 = _slicedToArray__default["default"](_getInputNode, 2), source = _getInputNode2[0], sourceCon = _getInputNode2[1];
                        if (!(end && endCon)) {
                          _context.next = 9;
                          break;
                        }
                        _context.next = 7;
                        return editor.addConnection(createConnection(source, sourceCon.sourceOutput, end, endCon.targetInput));
                      case 7:
                        _context.next = 9;
                        break;
                      case 9:
                        _getOutputNode3 = reteStudioCore.getOutputNode(context, node.id, 'label', false), _getOutputNode4 = _slicedToArray__default["default"](_getOutputNode3, 1), labelNode = _getOutputNode4[0];
                        if (!labelNode) {
                          _context.next = 13;
                          break;
                        }
                        _context.next = 13;
                        return reteStudioCore.Utils.removeNodeWithConnections(editor, labelNode.id);
                      case 13:
                        _context.next = 15;
                        return reteStudioCore.Utils.removeNodeWithConnections(editor, node.id);
                      case 15:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }));
                return function (_x2, _x3) {
                  return _ref.apply(this, arguments);
                };
              }())(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.next = 2;
              return function () {
                var _ref3 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(_ref2) {
                  var editor, nodes, _iterator, _step, _loop;
                  return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context4) {
                    while (1) switch (_context4.prev = _context4.next) {
                      case 0:
                        editor = _ref2.editor;
                        nodes = editor.getNodes().filter(function (n) {
                          return n.label === 'LabeledStatement';
                        });
                        _iterator = _createForOfIteratorHelper$6(nodes);
                        _context4.prev = 3;
                        _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                          var labelNode, _getOutputNode5, _getOutputNode6, end, _getOutputNode7, _getOutputNode8, label, cons, _iterator2, _step2, c, source, _getInputNode3, _getInputNode4, prev, closure, breakNode, identNode;
                          return _regeneratorRuntime__default["default"].wrap(function _loop$(_context3) {
                            while (1) switch (_context3.prev = _context3.next) {
                              case 0:
                                labelNode = _step.value;
                                _getOutputNode5 = reteStudioCore.getOutputNode({
                                  editor: editor
                                }, labelNode.id, 'alternate', false), _getOutputNode6 = _slicedToArray__default["default"](_getOutputNode5, 1), end = _getOutputNode6[0];
                                _getOutputNode7 = reteStudioCore.getOutputNode({
                                  editor: editor
                                }, labelNode.id, 'label'), _getOutputNode8 = _slicedToArray__default["default"](_getOutputNode7, 1), label = _getOutputNode8[0];
                                if (end) {
                                  _context3.next = 5;
                                  break;
                                }
                                return _context3.abrupt("return", 1);
                              case 5:
                                cons = editor.getConnections().filter(function (c) {
                                  return c.target === end.id && c.targetInput === reteStudioCore.BIND_KEY;
                                });
                                _iterator2 = _createForOfIteratorHelper$6(cons);
                                _context3.prev = 7;
                                _iterator2.s();
                              case 9:
                                if ((_step2 = _iterator2.n()).done) {
                                  _context3.next = 45;
                                  break;
                                }
                                c = _step2.value;
                                source = editor.getNode(c.source);
                                if (!['LabeledStatement'].includes(source.label)) {
                                  _context3.next = 14;
                                  break;
                                }
                                return _context3.abrupt("continue", 43);
                              case 14:
                                if (!['ContinueStatement'].includes(source.label)) {
                                  _context3.next = 16;
                                  break;
                                }
                                return _context3.abrupt("continue", 43);
                              case 16:
                                _getInputNode3 = reteStudioCore.getInputNode({
                                  editor: editor
                                }, source.id, reteStudioCore.BIND_KEY, false), _getInputNode4 = _slicedToArray__default["default"](_getInputNode3, 1), prev = _getInputNode4[0];
                                if (!(prev && prev.label === 'LabeledStatement')) {
                                  _context3.next = 19;
                                  break;
                                }
                                return _context3.abrupt("continue", 43);
                              case 19:
                                closure = new reteStudioCore.BaseNode('Closure');
                                breakNode = new reteStudioCore.BaseNode('BreakStatement');
                                identNode = new reteStudioCore.BaseNode('Identifier');
                                identNode.data.name = label.data.name;
                                identNode.type = 'expression';
                                breakNode.addOutput('label', new reteStudioCore.Output(reteStudioCore.socket, 'label', true));
                                breakNode.type = 'statement';
                                closure.parent = source.parent;
                                identNode.parent = closure.id;
                                breakNode.parent = closure.id;
                                _context3.next = 31;
                                return editor.addNode(closure);
                              case 31:
                                _context3.next = 33;
                                return editor.addNode(breakNode);
                              case 33:
                                _context3.next = 35;
                                return editor.addNode(identNode);
                              case 35:
                                _context3.next = 37;
                                return editor.removeConnection(c.id);
                              case 37:
                                _context3.next = 39;
                                return editor.addConnection(new reteStudioCore.Connection(breakNode, 'label', identNode, reteStudioCore.BIND_KEY));
                              case 39:
                                _context3.next = 41;
                                return editor.addConnection(new reteStudioCore.Connection(source, c.sourceOutput, breakNode, reteStudioCore.BIND_KEY));
                              case 41:
                                _context3.next = 43;
                                return editor.addConnection(new reteStudioCore.Connection(breakNode, reteStudioCore.BIND_KEY, end, reteStudioCore.BIND_KEY));
                              case 43:
                                _context3.next = 9;
                                break;
                              case 45:
                                _context3.next = 50;
                                break;
                              case 47:
                                _context3.prev = 47;
                                _context3.t0 = _context3["catch"](7);
                                _iterator2.e(_context3.t0);
                              case 50:
                                _context3.prev = 50;
                                _iterator2.f();
                                return _context3.finish(50);
                              case 53:
                              case "end":
                                return _context3.stop();
                            }
                          }, _loop, null, [[7, 47, 50, 53]]);
                        });
                        _iterator.s();
                      case 6:
                        if ((_step = _iterator.n()).done) {
                          _context4.next = 12;
                          break;
                        }
                        return _context4.delegateYield(_loop(), "t0", 8);
                      case 8:
                        if (!_context4.t0) {
                          _context4.next = 10;
                          break;
                        }
                        return _context4.abrupt("continue", 10);
                      case 10:
                        _context4.next = 6;
                        break;
                      case 12:
                        _context4.next = 17;
                        break;
                      case 14:
                        _context4.prev = 14;
                        _context4.t1 = _context4["catch"](3);
                        _iterator.e(_context4.t1);
                      case 17:
                        _context4.prev = 17;
                        _iterator.f();
                        return _context4.finish(17);
                      case 20:
                      case "end":
                        return _context4.stop();
                    }
                  }, _callee3, null, [[3, 14, 17, 20]]);
                }));
                return function (_x5) {
                  return _ref3.apply(this, arguments);
                };
              }()(context);
            case 2:
            case "end":
              return _context5.stop();
          }
        }, _callee4);
      }));
      function down(_x4) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return OmitBreak;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$5(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$5(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$5(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$5(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$5(o, minLen); }
function _arrayLikeToArray$5(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$a(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$a(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$a() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var OmitContinue = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](OmitContinue, _Transformer);
  var _super = _createSuper$a(OmitContinue);
  function OmitContinue() {
    _classCallCheck__default["default"](this, OmitContinue);
    return _super.call(this, 'Omit continue');
  }
  _createClass__default["default"](OmitContinue, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        var editor, createConnection, continueStatements, _iterator, _step, _loop, _iterator2, _step2, node, _getOutputNode, _getOutputNode2, labelNode;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              editor = context.editor, createConnection = context.createConnection;
              continueStatements = editor.getNodes().filter(function (n) {
                return n.label === 'ContinueStatement';
              });
              _iterator = _createForOfIteratorHelper$5(continueStatements);
              _context2.prev = 3;
              _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                var node, labeledStatement, sources, _iterator3, _step3, source, sourceNode;
                return _regeneratorRuntime__default["default"].wrap(function _loop$(_context) {
                  while (1) switch (_context.prev = _context.next) {
                    case 0:
                      node = _step.value;
                      labeledStatement = reteStudioCore.findLabeledStatement(context, node.id);
                      sources = editor.getConnections().filter(function (c) {
                        return c.target === node.id && c.targetInput === reteStudioCore.BIND_KEY;
                      });
                      _iterator3 = _createForOfIteratorHelper$5(sources);
                      _context.prev = 4;
                      _iterator3.s();
                    case 6:
                      if ((_step3 = _iterator3.n()).done) {
                        _context.next = 13;
                        break;
                      }
                      source = _step3.value;
                      sourceNode = editor.getNode(source.source);
                      _context.next = 11;
                      return editor.addConnection(createConnection(sourceNode, source.sourceOutput, labeledStatement, reteStudioCore.BIND_KEY, {
                        isLoop: true
                      }));
                    case 11:
                      _context.next = 6;
                      break;
                    case 13:
                      _context.next = 18;
                      break;
                    case 15:
                      _context.prev = 15;
                      _context.t0 = _context["catch"](4);
                      _iterator3.e(_context.t0);
                    case 18:
                      _context.prev = 18;
                      _iterator3.f();
                      return _context.finish(18);
                    case 21:
                    case "end":
                      return _context.stop();
                  }
                }, _loop, null, [[4, 15, 18, 21]]);
              });
              _iterator.s();
            case 6:
              if ((_step = _iterator.n()).done) {
                _context2.next = 10;
                break;
              }
              return _context2.delegateYield(_loop(), "t0", 8);
            case 8:
              _context2.next = 6;
              break;
            case 10:
              _context2.next = 15;
              break;
            case 12:
              _context2.prev = 12;
              _context2.t1 = _context2["catch"](3);
              _iterator.e(_context2.t1);
            case 15:
              _context2.prev = 15;
              _iterator.f();
              return _context2.finish(15);
            case 18:
              _iterator2 = _createForOfIteratorHelper$5(continueStatements);
              _context2.prev = 19;
              _iterator2.s();
            case 21:
              if ((_step2 = _iterator2.n()).done) {
                _context2.next = 31;
                break;
              }
              node = _step2.value;
              _getOutputNode = reteStudioCore.getOutputNode(context, node.id, 'label', false), _getOutputNode2 = _slicedToArray__default["default"](_getOutputNode, 1), labelNode = _getOutputNode2[0];
              if (!labelNode) {
                _context2.next = 27;
                break;
              }
              _context2.next = 27;
              return reteStudioCore.Utils.removeNodeWithConnections(editor, labelNode.id);
            case 27:
              _context2.next = 29;
              return reteStudioCore.Utils.removeNodeWithConnections(editor, node.id);
            case 29:
              _context2.next = 21;
              break;
            case 31:
              _context2.next = 36;
              break;
            case 33:
              _context2.prev = 33;
              _context2.t2 = _context2["catch"](19);
              _iterator2.e(_context2.t2);
            case 36:
              _context2.prev = 36;
              _iterator2.f();
              return _context2.finish(36);
            case 39:
            case "end":
              return _context2.stop();
          }
        }, _callee, null, [[3, 12, 15, 18], [19, 33, 36, 39]]);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return function () {
                var _ref2 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(_ref) {
                  var editor, loops, _iterator4, _step4, loop, source, target, _getOutputNode3, _getOutputNode4, alternate, _getOutputNode5, _getOutputNode6, label, closure, continueNode, identNode;
                  return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context3) {
                    while (1) switch (_context3.prev = _context3.next) {
                      case 0:
                        editor = _ref.editor;
                        loops = editor.getConnections().filter(function (c) {
                          return c.isLoop;
                        });
                        _iterator4 = _createForOfIteratorHelper$5(loops);
                        _context3.prev = 3;
                        _iterator4.s();
                      case 5:
                        if ((_step4 = _iterator4.n()).done) {
                          _context3.next = 41;
                          break;
                        }
                        loop = _step4.value;
                        source = editor.getNode(loop.source);
                        target = editor.getNode(loop.target);
                        if (!(target.label !== 'LabeledStatement')) {
                          _context3.next = 11;
                          break;
                        }
                        throw new Error('Unexpected target type');
                      case 11:
                        _getOutputNode3 = reteStudioCore.getOutputNode({
                          editor: editor
                        }, target.id, 'alternate', false), _getOutputNode4 = _slicedToArray__default["default"](_getOutputNode3, 1), alternate = _getOutputNode4[0];
                        _getOutputNode5 = reteStudioCore.getOutputNode({
                          editor: editor
                        }, target.id, 'label'), _getOutputNode6 = _slicedToArray__default["default"](_getOutputNode5, 1), label = _getOutputNode6[0];
                        _context3.next = 15;
                        return editor.removeConnection(loop.id);
                      case 15:
                        if (alternate) {
                          _context3.next = 17;
                          break;
                        }
                        return _context3.abrupt("continue", 39);
                      case 17:
                        closure = new reteStudioCore.BaseNode('Closure');
                        continueNode = new reteStudioCore.BaseNode('ContinueStatement');
                        identNode = new reteStudioCore.BaseNode('Identifier');
                        identNode.data.name = label.data.name;
                        identNode.type = 'expression';
                        continueNode.addOutput('label', new reteStudioCore.Output(reteStudioCore.socket, 'label', true));
                        continueNode.type = 'statement';
                        closure.parent = source.parent;
                        identNode.parent = closure.id;
                        continueNode.parent = closure.id;
                        _context3.next = 29;
                        return editor.addNode(closure);
                      case 29:
                        _context3.next = 31;
                        return editor.addNode(continueNode);
                      case 31:
                        _context3.next = 33;
                        return editor.addNode(identNode);
                      case 33:
                        _context3.next = 35;
                        return editor.addConnection(new reteStudioCore.Connection(continueNode, 'label', identNode, reteStudioCore.BIND_KEY));
                      case 35:
                        _context3.next = 37;
                        return editor.addConnection(new reteStudioCore.Connection(source, loop.sourceOutput, continueNode, reteStudioCore.BIND_KEY));
                      case 37:
                        _context3.next = 39;
                        return editor.addConnection(new reteStudioCore.Connection(continueNode, reteStudioCore.BIND_KEY, alternate, reteStudioCore.BIND_KEY));
                      case 39:
                        _context3.next = 5;
                        break;
                      case 41:
                        _context3.next = 46;
                        break;
                      case 43:
                        _context3.prev = 43;
                        _context3.t0 = _context3["catch"](3);
                        _iterator4.e(_context3.t0);
                      case 46:
                        _context3.prev = 46;
                        _iterator4.f();
                        return _context3.finish(46);
                      case 49:
                      case "end":
                        return _context3.stop();
                    }
                  }, _callee2, null, [[3, 43, 46, 49]]);
                }));
                return function (_x3) {
                  return _ref2.apply(this, arguments);
                };
              }()(context);
            case 2:
            case "end":
              return _context4.stop();
          }
        }, _callee3);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return OmitContinue;
}(reteStudioCore.Transformer);

function _createSuper$9(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$9(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$9() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function _createForOfIteratorHelper$4(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$4(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$4(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$4(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$4(o, minLen); }
function _arrayLikeToArray$4(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }

// TODO move to rete-structures
function bfs(editor, startNode, condition) {
  var queue = [];
  var visited = new Set();
  queue.push(startNode);
  visited.add(startNode);
  while (queue.length > 0) {
    var _node = queue.shift();
    if (!_node) return null;
    var found = condition(_node);
    if (found) return found;
    var connections = editor.getConnections();
    var _iterator = _createForOfIteratorHelper$4(connections),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var connection = _step.value;
        if (connection.source === _node.id) {
          var targetId = connection.target;
          var target = editor.getNode(targetId);
          if (!visited.has(target)) {
            queue.push(target);
            visited.add(target);
          }
        }
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return null;
}
var OmitLabeled = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](OmitLabeled, _Transformer);
  var _super = _createSuper$9(OmitLabeled);
  function OmitLabeled() {
    _classCallCheck__default["default"](this, OmitLabeled);
    return _super.call(this, 'Omit labeled');
  }
  _createClass__default["default"](OmitLabeled, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.forEach(function (n) {
                return n.label === 'LabeledStatement';
              }, /*#__PURE__*/function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(node, context) {
                  var editor, createConnection, inps, _getOutputNode, _getOutputNode2, outputNode, outputCon, _iterator2, _step2, inp, c, _getOutputNode3, _getOutputNode4, labelNode;
                  return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        editor = context.editor, createConnection = context.createConnection;
                        inps = editor.getConnections().filter(function (c) {
                          return c.target === node.id && c.targetInput === reteStudioCore.BIND_KEY;
                        });
                        _getOutputNode = reteStudioCore.getOutputNode(context, node.id, 'body', false), _getOutputNode2 = _slicedToArray__default["default"](_getOutputNode, 2), outputNode = _getOutputNode2[0], outputCon = _getOutputNode2[1];
                        if (!(outputNode && outputCon)) {
                          _context.next = 22;
                          break;
                        }
                        _iterator2 = _createForOfIteratorHelper$4(inps);
                        _context.prev = 5;
                        _iterator2.s();
                      case 7:
                        if ((_step2 = _iterator2.n()).done) {
                          _context.next = 14;
                          break;
                        }
                        inp = _step2.value;
                        c = createConnection(editor.getNode(inp.source), inp.sourceOutput, outputNode, outputCon.targetInput, inp);
                        _context.next = 12;
                        return editor.addConnection(c);
                      case 12:
                        _context.next = 7;
                        break;
                      case 14:
                        _context.next = 19;
                        break;
                      case 16:
                        _context.prev = 16;
                        _context.t0 = _context["catch"](5);
                        _iterator2.e(_context.t0);
                      case 19:
                        _context.prev = 19;
                        _iterator2.f();
                        return _context.finish(19);
                      case 22:
                        _getOutputNode3 = reteStudioCore.getOutputNode(context, node.id, 'label'), _getOutputNode4 = _slicedToArray__default["default"](_getOutputNode3, 1), labelNode = _getOutputNode4[0];
                        _context.next = 25;
                        return reteStudioCore.Utils.removeNodeWithConnections(editor, labelNode.id);
                      case 25:
                        _context.next = 27;
                        return reteStudioCore.Utils.removeNodeWithConnections(editor, node.id);
                      case 27:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee, null, [[5, 16, 19, 22]]);
                }));
                return function (_x2, _x3) {
                  return _ref.apply(this, arguments);
                };
              }())(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4(context) {
        var editor, createLabeledClosure, _createLabeledClosure, loops, _iterator3, _step3, _loop;
        return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _createLabeledClosure = function _createLabeledClosure3() {
                _createLabeledClosure = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(entry) {
                  var entryParent, closure, labeledStatement, ident, end;
                  return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
                    while (1) switch (_context3.prev = _context3.next) {
                      case 0:
                        entryParent = entry.parent ? editor.getNode(entry.parent) : null;
                        closure = new reteStudioCore.BaseNode('Closure');
                        labeledStatement = new reteStudioCore.BaseNode('LabeledStatement');
                        ident = new reteStudioCore.BaseNode('Identifier');
                        ident.data.name = "loop".concat(labeledStatement.id);
                        end = bfs(context.editor, entry, function (n) {
                          if (n.label === 'IfStatement') {
                            var _getOutputNode5 = reteStudioCore.getOutputNode(context, n.id, 'alternate'),
                              _getOutputNode6 = _slicedToArray__default["default"](_getOutputNode5, 2),
                              _end = _getOutputNode6[0],
                              c = _getOutputNode6[1];
                            if (c.isLoop) return false;
                            var diff = reteStudioCore.getClosureDifferenceOld(n, _end, context);
                            return diff.length > 0 ? _end : false; // TODO recheck new getClosureDifference
                          }

                          return false;
                        });
                        if (entryParent) {
                          _context3.next = 8;
                          break;
                        }
                        throw new Error('Entry parent not found');
                      case 8:
                        closure.parent = entryParent.parent;
                        entryParent.parent = closure.id;
                        labeledStatement.type = 'statement';
                        ident.type = 'expression';
                        labeledStatement.parent = closure.id;
                        ident.parent = closure.id;
                        labeledStatement.addOutput('label', new reteStudioCore.Output(reteStudioCore.socket, 'label', true));
                        labeledStatement.addOutput('body', new reteStudioCore.Output(reteStudioCore.socket, 'body', true));
                        labeledStatement.addOutput('alternate', new reteStudioCore.Output(reteStudioCore.socket, 'alternate', true));
                        _context3.next = 19;
                        return editor.addNode(closure);
                      case 19:
                        _context3.next = 21;
                        return editor.addNode(labeledStatement);
                      case 21:
                        _context3.next = 23;
                        return editor.addNode(ident);
                      case 23:
                        _context3.next = 25;
                        return editor.addConnection(new reteStudioCore.Connection(labeledStatement, 'label', ident, reteStudioCore.BIND_KEY));
                      case 25:
                        _context3.next = 27;
                        return editor.addConnection(new reteStudioCore.Connection(labeledStatement, 'body', entry, reteStudioCore.BIND_KEY));
                      case 27:
                        if (!end) {
                          _context3.next = 32;
                          break;
                        }
                        _context3.next = 30;
                        return editor.addConnection(new reteStudioCore.Connection(labeledStatement, 'alternate', end, reteStudioCore.BIND_KEY));
                      case 30:
                        _context3.next = 34;
                        break;
                      case 32:
                        _context3.next = 34;
                        return reteStudioCore.patchPlaceholderPorts(function (node) {
                          if (node.label === 'LabeledStatement') return {
                            outputs: [{
                              key: 'alternate',
                              flow: true
                            }]
                          };
                        })(context);
                      case 34:
                        return _context3.abrupt("return", {
                          labeledStatement: labeledStatement
                        });
                      case 35:
                      case "end":
                        return _context3.stop();
                    }
                  }, _callee3);
                }));
                return _createLabeledClosure.apply(this, arguments);
              };
              createLabeledClosure = function _createLabeledClosure2(_x5) {
                return _createLabeledClosure.apply(this, arguments);
              };
              // add LabeledStatement FIX extra closures
              editor = context.editor;
              _context5.next = 5;
              return reteStudioCore.patchPlaceholderPorts(function (node) {
                if (node.label === 'IfStatement') {
                  return {
                    outputs: [{
                      key: 'alternate',
                      flow: true
                    }]
                  };
                }
              })(context);
            case 5:
              loops = editor.getConnections().filter(function (c) {
                return c.isLoop;
              });
              _iterator3 = _createForOfIteratorHelper$4(loops);
              _context5.prev = 7;
              _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                var loop, entry, inputs, existing, _yield$createLabeledC, labeledStatement, _iterator4, _step4, inp;
                return _regeneratorRuntime__default["default"].wrap(function _loop$(_context4) {
                  while (1) switch (_context4.prev = _context4.next) {
                    case 0:
                      loop = _step3.value;
                      entry = editor.getNode(loop.target);
                      inputs = editor.getConnections().filter(function (c) {
                        return c.target === entry.id && c.targetInput === reteStudioCore.BIND_KEY;
                      });
                      existing = reteStudioCore.findLabeledStatement(context, entry.id, true);
                      if (!(existing && !editor.getConnections().some(function (c) {
                        return c.source === existing.id;
                      }))) {
                        _context4.next = 6;
                        break;
                      }
                      return _context4.abrupt("return", 1);
                    case 6:
                      _context4.next = 8;
                      return createLabeledClosure(entry);
                    case 8:
                      _yield$createLabeledC = _context4.sent;
                      labeledStatement = _yield$createLabeledC.labeledStatement;
                      _iterator4 = _createForOfIteratorHelper$4(inputs);
                      _context4.prev = 11;
                      _iterator4.s();
                    case 13:
                      if ((_step4 = _iterator4.n()).done) {
                        _context4.next = 21;
                        break;
                      }
                      inp = _step4.value;
                      _context4.next = 17;
                      return editor.removeConnection(inp.id);
                    case 17:
                      _context4.next = 19;
                      return editor.addConnection(new reteStudioCore.Connection(editor.getNode(inp.source), inp.sourceOutput, labeledStatement, reteStudioCore.BIND_KEY, inp));
                    case 19:
                      _context4.next = 13;
                      break;
                    case 21:
                      _context4.next = 26;
                      break;
                    case 23:
                      _context4.prev = 23;
                      _context4.t0 = _context4["catch"](11);
                      _iterator4.e(_context4.t0);
                    case 26:
                      _context4.prev = 26;
                      _iterator4.f();
                      return _context4.finish(26);
                    case 29:
                    case "end":
                      return _context4.stop();
                  }
                }, _loop, null, [[11, 23, 26, 29]]);
              });
              _iterator3.s();
            case 10:
              if ((_step3 = _iterator3.n()).done) {
                _context5.next = 16;
                break;
              }
              return _context5.delegateYield(_loop(), "t0", 12);
            case 12:
              if (!_context5.t0) {
                _context5.next = 14;
                break;
              }
              return _context5.abrupt("continue", 14);
            case 14:
              _context5.next = 10;
              break;
            case 16:
              _context5.next = 21;
              break;
            case 18:
              _context5.prev = 18;
              _context5.t1 = _context5["catch"](7);
              _iterator3.e(_context5.t1);
            case 21:
              _context5.prev = 21;
              _iterator3.f();
              return _context5.finish(21);
            case 24:
            case "end":
              return _context5.stop();
          }
        }, _callee4, null, [[7, 18, 21, 24]]);
      }));
      function down(_x4) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return OmitLabeled;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$3(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$3(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$3(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$3(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$3(o, minLen); }
function _arrayLikeToArray$3(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$8(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$8(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$8() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var OmitRestoreClosures = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](OmitRestoreClosures, _Transformer);
  var _super = _createSuper$8(OmitRestoreClosures);
  function OmitRestoreClosures() {
    _classCallCheck__default["default"](this, OmitRestoreClosures);
    return _super.call(this, 'omit-restore closures');
  }
  _createClass__default["default"](OmitRestoreClosures, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return reteStudioCore.forEach(function (node) {
                return node.label === 'Closure';
              }, /*#__PURE__*/function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(node, context) {
                  var editor, children;
                  return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        editor = context.editor;
                        children = reteStructures.structures(editor).children(function (m) {
                          return m.id === node.id;
                        }).nodes();
                        if (!children.some(function (child) {
                          return child.label === 'VariableDeclarator';
                        })) {
                          _context.next = 4;
                          break;
                        }
                        return _context.abrupt("return");
                      case 4:
                        children.forEach(function (m) {
                          m.parent = node.parent;
                        });
                        _context.next = 7;
                        return editor.removeNode(node.id);
                      case 7:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }));
                return function (_x2, _x3) {
                  return _ref.apply(this, arguments);
                };
              }())(context);
            case 2:
              _context4.next = 4;
              return reteStudioCore.forEach(function (node) {
                return ['FunctionExpression', 'ArrowFunctionExpression'].includes(node.label);
              }, /*#__PURE__*/function () {
                var _ref2 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(node, context) {
                  var editor, children, _iterator, _step, _loop;
                  return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context3) {
                    while (1) switch (_context3.prev = _context3.next) {
                      case 0:
                        // TODO ArrowFunctionExpression ?
                        editor = context.editor;
                        children = reteStructures.structures(editor).children(function (m) {
                          return m.id === node.id;
                        }).nodes();
                        _iterator = _createForOfIteratorHelper$3(children);
                        _context3.prev = 3;
                        _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                          var child;
                          return _regeneratorRuntime__default["default"].wrap(function _loop$(_context2) {
                            while (1) switch (_context2.prev = _context2.next) {
                              case 0:
                                child = _step.value;
                                if (!(child.label === 'Closure')) {
                                  _context2.next = 5;
                                  break;
                                }
                                reteStructures.structures(editor).children(function (m) {
                                  return m.id === child.id;
                                }).nodes().forEach(function (m) {
                                  m.parent = node.id;
                                });
                                _context2.next = 5;
                                return editor.removeNode(child.id);
                              case 5:
                              case "end":
                                return _context2.stop();
                            }
                          }, _loop);
                        });
                        _iterator.s();
                      case 6:
                        if ((_step = _iterator.n()).done) {
                          _context3.next = 10;
                          break;
                        }
                        return _context3.delegateYield(_loop(), "t0", 8);
                      case 8:
                        _context3.next = 6;
                        break;
                      case 10:
                        _context3.next = 15;
                        break;
                      case 12:
                        _context3.prev = 12;
                        _context3.t1 = _context3["catch"](3);
                        _iterator.e(_context3.t1);
                      case 15:
                        _context3.prev = 15;
                        _iterator.f();
                        return _context3.finish(15);
                      case 18:
                      case "end":
                        return _context3.stop();
                    }
                  }, _callee2, null, [[3, 12, 15, 18]]);
                }));
                return function (_x4, _x5) {
                  return _ref2.apply(this, arguments);
                };
              }())(context);
            case 4:
            case "end":
              return _context4.stop();
          }
        }, _callee3);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee7(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee7$(_context11) {
          while (1) switch (_context11.prev = _context11.next) {
            case 0:
              _context11.next = 2;
              return function () {
                var _ref3 = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee6(context) {
                  var editor, putIntoClosure, _putIntoClosure, toClosure, _toClosure, ifStatements, pairs, _iterator2, _step2, _loop2, connections, loops, _iterator3, _step3, _loop3, entries, _iterator4, _step4, _loop4;
                  return _regeneratorRuntime__default["default"].wrap(function _callee6$(_context10) {
                    while (1) switch (_context10.prev = _context10.next) {
                      case 0:
                        _toClosure = function _toClosure3() {
                          _toClosure = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee5(children, parent) {
                            var closure;
                            return _regeneratorRuntime__default["default"].wrap(function _callee5$(_context6) {
                              while (1) switch (_context6.prev = _context6.next) {
                                case 0:
                                  closure = new reteStudioCore.BaseNode('Closure');
                                  closure.parent = parent;
                                  closure.removeInput(reteStudioCore.BIND_KEY);
                                  closure.removeOutput(reteStudioCore.BIND_KEY);
                                  _context6.next = 6;
                                  return editor.addNode(closure);
                                case 6:
                                  _context6.next = 8;
                                  return putIntoClosure(closure, children);
                                case 8:
                                case "end":
                                  return _context6.stop();
                              }
                            }, _callee5);
                          }));
                          return _toClosure.apply(this, arguments);
                        };
                        toClosure = function _toClosure2(_x10, _x11) {
                          return _toClosure.apply(this, arguments);
                        };
                        _putIntoClosure = function _putIntoClosure3() {
                          _putIntoClosure = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4(closure, statements) {
                            var childrenWithExpressions, parents, parentsChildren, filledParents;
                            return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context5) {
                              while (1) switch (_context5.prev = _context5.next) {
                                case 0:
                                  childrenWithExpressions = statements.map(function (n) {
                                    return [n].concat(_toConsumableArray__default["default"](reteStructures.structures(editor).predecessors(n.id, function (pred) {
                                      return pred.type === 'expression';
                                    }).nodes()));
                                  }).flat();
                                  parents = Array.from(new Set(childrenWithExpressions.map(function (n) {
                                    return n.parent;
                                  }))).filter(function (id) {
                                    return Boolean(id);
                                  }).map(function (id) {
                                    return editor.getNode(id);
                                  });
                                  parentsChildren = parents.map(function (parent) {
                                    return {
                                      parent: parent,
                                      children: reteStructures.structures(editor).children(function (n) {
                                        return n.id === parent.id;
                                      }).nodes()
                                    };
                                  });
                                  filledParents = Object.fromEntries(parentsChildren.filter(function (_ref4) {
                                    var children = _ref4.children;
                                    return children.every(function (n) {
                                      return [].concat(_toConsumableArray__default["default"](parents), _toConsumableArray__default["default"](childrenWithExpressions)).includes(n);
                                    });
                                  }).map(function (_ref5) {
                                    var parent = _ref5.parent,
                                      children = _ref5.children;
                                    return [parent.id, children];
                                  }));
                                  childrenWithExpressions.forEach(function (node) {
                                    var getParent = function getParent(parent) {
                                      return parent && filledParents[parent] ? getParent(editor.getNode(parent).parent) || parent : null;
                                    };
                                    var parent = getParent(node.parent);
                                    if (parent) {
                                      editor.getNode(parent).parent = closure.id;
                                    } else {
                                      node.parent = closure.id;
                                    }
                                  });
                                case 5:
                                case "end":
                                  return _context5.stop();
                              }
                            }, _callee4);
                          }));
                          return _putIntoClosure.apply(this, arguments);
                        };
                        putIntoClosure = function _putIntoClosure2(_x8, _x9) {
                          return _putIntoClosure.apply(this, arguments);
                        };
                        editor = context.editor; // TODO reusable
                        ifStatements = editor.getNodes().filter(function (n) {
                          return n.label === 'IfStatement' || n.label === 'TryStatement';
                        });
                        pairs = ifStatements.map(function (ifStatement) {
                          var keys = ifStatement.label === 'IfStatement' ? ['consequent', 'alternate'] : ['block', 'handler', 'finalizer'];
                          return [ifStatement, {
                            keys: keys
                          }];
                        }); // const allExists = pairs.map(([ifStatement, { keys }]) => getBranchExit(ifStatement, keys, context)).filter(Boolean)
                        _iterator2 = _createForOfIteratorHelper$3(pairs);
                        _context10.prev = 8;
                        _loop2 = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop2() {
                          var _step2$value, ifStatement, keys, st, exit, subgraphs, _iterator5, _step5, subgraph;
                          return _regeneratorRuntime__default["default"].wrap(function _loop2$(_context7) {
                            while (1) switch (_context7.prev = _context7.next) {
                              case 0:
                                _step2$value = _slicedToArray__default["default"](_step2.value, 2), ifStatement = _step2$value[0], keys = _step2$value[1].keys;
                                st = reteStructures.structures({
                                  nodes: editor.getNodes(),
                                  connections: editor.getConnections().filter(function (c) {
                                    return !c.isLoop;
                                  })
                                });
                                exit = reteStudioCore.getBranchExit(ifStatement, keys, context);
                                subgraphs = keys.map(function (key) {
                                  return st.successors(ifStatement.id, function (n, c) {
                                    if (exit && exit.id === n.id) return false;
                                    // if (allExists.length && allExists.includes(n)) return false
                                    if (reteStudioCore.getClosureDifference(ifStatement, n, context).left.length > 0) return false;
                                    if (c.source === ifStatement.id) return c.sourceOutput === key;
                                    return true;
                                  });
                                });
                                _iterator5 = _createForOfIteratorHelper$3(subgraphs);
                                _context7.prev = 5;
                                _iterator5.s();
                              case 7:
                                if ((_step5 = _iterator5.n()).done) {
                                  _context7.next = 14;
                                  break;
                                }
                                subgraph = _step5.value;
                                if (!(subgraph.nodes().length > 0)) {
                                  _context7.next = 12;
                                  break;
                                }
                                _context7.next = 12;
                                return toClosure(subgraph.nodes(), ifStatement.parent);
                              case 12:
                                _context7.next = 7;
                                break;
                              case 14:
                                _context7.next = 19;
                                break;
                              case 16:
                                _context7.prev = 16;
                                _context7.t0 = _context7["catch"](5);
                                _iterator5.e(_context7.t0);
                              case 19:
                                _context7.prev = 19;
                                _iterator5.f();
                                return _context7.finish(19);
                              case 22:
                              case "end":
                                return _context7.stop();
                            }
                          }, _loop2, null, [[5, 16, 19, 22]]);
                        });
                        _iterator2.s();
                      case 11:
                        if ((_step2 = _iterator2.n()).done) {
                          _context10.next = 15;
                          break;
                        }
                        return _context10.delegateYield(_loop2(), "t0", 13);
                      case 13:
                        _context10.next = 11;
                        break;
                      case 15:
                        _context10.next = 20;
                        break;
                      case 17:
                        _context10.prev = 17;
                        _context10.t1 = _context10["catch"](8);
                        _iterator2.e(_context10.t1);
                      case 20:
                        _context10.prev = 20;
                        _iterator2.f();
                        return _context10.finish(20);
                      case 23:
                        connections = editor.getConnections();
                        loops = connections.filter(function (c) {
                          return c.isLoop;
                        });
                        _iterator3 = _createForOfIteratorHelper$3(loops);
                        _context10.prev = 26;
                        _loop3 = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop3() {
                          var loop, start, st, end, forward, _end, _forward, backward, children;
                          return _regeneratorRuntime__default["default"].wrap(function _loop3$(_context8) {
                            while (1) switch (_context8.prev = _context8.next) {
                              case 0:
                                loop = _step3.value;
                                start = editor.getNode(loop.target);
                                st = reteStructures.structures({
                                  nodes: editor.getNodes(),
                                  connections: connections.filter(function (c) {
                                    return !c.isLoop;
                                  })
                                });
                                if (!(start.label === 'IfStatement' || start.label === 'TryStatement')) {
                                  _context8.next = 10;
                                  break;
                                }
                                end = reteStudioCore.getBranchExit(start, start.label === 'IfStatement' ? ['consequent', 'alternate'] : ['block', 'handler', 'finalizer'], context);
                                forward = st.successors(start.id, function (n) {
                                  if (end && end.id === n.id) return false;
                                  return true;
                                }).union({
                                  nodes: [start],
                                  connections: connections
                                });
                                _context8.next = 8;
                                return toClosure(forward.nodes(), start.parent);
                              case 8:
                                _context8.next = 16;
                                break;
                              case 10:
                                _end = editor.getNode(loop.source);
                                _forward = st.successors(start.id).union({
                                  nodes: [start],
                                  connections: connections
                                });
                                backward = st.predecessors(_end.id).union({
                                  nodes: [_end],
                                  connections: connections
                                });
                                children = _forward.intersection({
                                  getNodes: backward.nodes,
                                  getConnections: backward.connections
                                }).nodes();
                                _context8.next = 16;
                                return toClosure(children, start.parent);
                              case 16:
                              case "end":
                                return _context8.stop();
                            }
                          }, _loop3);
                        });
                        _iterator3.s();
                      case 29:
                        if ((_step3 = _iterator3.n()).done) {
                          _context10.next = 33;
                          break;
                        }
                        return _context10.delegateYield(_loop3(), "t2", 31);
                      case 31:
                        _context10.next = 29;
                        break;
                      case 33:
                        _context10.next = 38;
                        break;
                      case 35:
                        _context10.prev = 35;
                        _context10.t3 = _context10["catch"](26);
                        _iterator3.e(_context10.t3);
                      case 38:
                        _context10.prev = 38;
                        _iterator3.f();
                        return _context10.finish(38);
                      case 41:
                        entries = editor.getNodes().filter(function (n) {
                          return n.label === 'Entry';
                        });
                        _iterator4 = _createForOfIteratorHelper$3(entries);
                        _context10.prev = 43;
                        _loop4 = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop4() {
                          var entry, nodes;
                          return _regeneratorRuntime__default["default"].wrap(function _loop4$(_context9) {
                            while (1) switch (_context9.prev = _context9.next) {
                              case 0:
                                entry = _step4.value;
                                if (entry.outputs['body']) {
                                  _context9.next = 4;
                                  break;
                                }
                                console.warn('entry without body', entry);
                                return _context9.abrupt("return", 1);
                              case 4:
                                nodes = reteStructures.structures(editor).successors(entry.id, function (n, c) {
                                  return (c.source === entry.id ? c.sourceOutput === 'body' : true) && n.type === 'statement';
                                }).nodes();
                                _context9.next = 7;
                                return toClosure(nodes, entry.parent);
                              case 7:
                              case "end":
                                return _context9.stop();
                            }
                          }, _loop4);
                        });
                        _iterator4.s();
                      case 46:
                        if ((_step4 = _iterator4.n()).done) {
                          _context10.next = 52;
                          break;
                        }
                        return _context10.delegateYield(_loop4(), "t4", 48);
                      case 48:
                        if (!_context10.t4) {
                          _context10.next = 50;
                          break;
                        }
                        return _context10.abrupt("continue", 50);
                      case 50:
                        _context10.next = 46;
                        break;
                      case 52:
                        _context10.next = 57;
                        break;
                      case 54:
                        _context10.prev = 54;
                        _context10.t5 = _context10["catch"](43);
                        _iterator4.e(_context10.t5);
                      case 57:
                        _context10.prev = 57;
                        _iterator4.f();
                        return _context10.finish(57);
                      case 60:
                      case "end":
                        return _context10.stop();
                    }
                  }, _callee6, null, [[8, 17, 20, 23], [26, 35, 38, 41], [43, 54, 57, 60]]);
                }));
                return function (_x7) {
                  return _ref3.apply(this, arguments);
                };
              }()(context);
            case 2:
            case "end":
              return _context11.stop();
          }
        }, _callee7);
      }));
      function down(_x6) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return OmitRestoreClosures;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$2(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$2(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$2(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$2(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$2(o, minLen); }
function _arrayLikeToArray$2(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$7(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$7(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$7() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var PruneDeadStatements = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](PruneDeadStatements, _Transformer);
  var _super = _createSuper$7(PruneDeadStatements);
  function PruneDeadStatements() {
    _classCallCheck__default["default"](this, PruneDeadStatements);
    return _super.call(this, 'Prune closures');
  }
  _createClass__default["default"](PruneDeadStatements, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        var editor, roots, top, _iterator, _step, _loop;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              editor = context.editor;
              roots = reteStructures.structures(editor).filter(function (n) {
                return n.type === 'statement' || n.label === 'Entry';
              }).roots().filter(function (n) {
                return n.label !== 'Entry';
              }).nodes();
              if (!(roots.length < 2)) {
                _context2.next = 4;
                break;
              }
              return _context2.abrupt("return");
            case 4:
              top = roots.reduce(function (a, b) {
                var diff = reteStudioCore.getClosureDifference2(a, b, context);
                if (diff.left.length > diff.right.length) {
                  return b;
                }
                return a;
              });
              _iterator = _createForOfIteratorHelper$2(roots.filter(function (n) {
                return n !== top;
              }));
              _context2.prev = 6;
              _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                var root, parent, nodes, _iterator2, _step2, node;
                return _regeneratorRuntime__default["default"].wrap(function _loop$(_context) {
                  while (1) switch (_context.prev = _context.next) {
                    case 0:
                      root = _step.value;
                      parent = root.parent && editor.getNode(root.parent);
                      if (!parent) {
                        _context.next = 21;
                        break;
                      }
                      nodes = reteStructures.structures(editor).successors(root.id, function (n) {
                        return reteStudioCore.belongToSameClosure(root, n, context);
                      }).union({
                        nodes: [root],
                        connections: []
                      }).nodes();
                      _iterator2 = _createForOfIteratorHelper$2(nodes);
                      _context.prev = 5;
                      _iterator2.s();
                    case 7:
                      if ((_step2 = _iterator2.n()).done) {
                        _context.next = 13;
                        break;
                      }
                      node = _step2.value;
                      _context.next = 11;
                      return reteStudioCore.Utils.removeNodeWithConnections(editor, node.id);
                    case 11:
                      _context.next = 7;
                      break;
                    case 13:
                      _context.next = 18;
                      break;
                    case 15:
                      _context.prev = 15;
                      _context.t0 = _context["catch"](5);
                      _iterator2.e(_context.t0);
                    case 18:
                      _context.prev = 18;
                      _iterator2.f();
                      return _context.finish(18);
                    case 21:
                    case "end":
                      return _context.stop();
                  }
                }, _loop, null, [[5, 15, 18, 21]]);
              });
              _iterator.s();
            case 9:
              if ((_step = _iterator.n()).done) {
                _context2.next = 13;
                break;
              }
              return _context2.delegateYield(_loop(), "t0", 11);
            case 11:
              _context2.next = 9;
              break;
            case 13:
              _context2.next = 18;
              break;
            case 15:
              _context2.prev = 15;
              _context2.t1 = _context2["catch"](6);
              _iterator.e(_context2.t1);
            case 18:
              _context2.prev = 18;
              _iterator.f();
              return _context2.finish(18);
            case 21:
            case "end":
              return _context2.stop();
          }
        }, _callee, null, [[6, 15, 18, 21]]);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
            case 1:
            case "end":
              return _context3.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return PruneDeadStatements;
}(reteStudioCore.Transformer);

function _createSuper$6(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$6(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$6() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Rename = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](Rename, _Transformer);
  var _super = _createSuper$6(Rename);
  function Rename() {
    _classCallCheck__default["default"](this, Rename);
    return _super.call(this, 'rename');
  }
  _createClass__default["default"](Rename, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return reteStudioCore.rename(function (node) {
                if (node.label === 'AssignmentExpression') return 'Assign';
                if (node.label === 'VariableDeclarator') return 'Variable';
                if (node.label === 'ImportDeclaration') return 'Import';
                if (node.label === 'ExportNamedDeclaration') return 'Export';
                if (node.label === 'ExportAllDeclaration') return 'Export all';
                if (node.label === 'ExportDefaultDeclaration') return 'Export default';
                if (node.label === 'ThrowStatement') return 'Throw';
                if (node.label === 'IfStatement') return 'If';
                if (node.label === 'DebuggerStatement') return 'Debug';
                if (node.label === 'ConditionalExpression') return 'If';
                if (node.label === 'CallExpression') return 'Call';
                if (node.label === 'ExpressionStatement') return 'Statement';
                if (node.label === 'SwitchStatement') return 'Switch';
                if (node.label === 'WithStatement') return 'With';
                if (node.label === 'ArrayExpression') return 'Array';
                if (node.label === 'ObjectExpression') return 'Object';
                if (node.label === 'NewExpression') return 'New';
                if (node.label === 'ObjectPattern') return 'Object destructing';
                if (node.label === 'ArrayPattern') return 'Array destructing';
                if (node.label === 'AssignmentPattern') return 'Default';
                if (node.label === 'SpreadElement') return 'Spread';
                if (node.label === 'RestElement') return 'Rest';
                if (node.label === 'YieldExpression') return 'Yield';
                if (node.label === 'ReturnStatement') return 'Return';
                if (node.label === 'TryStatement') return 'Try';
                if (node.label === 'CatchClause') return 'Catch';
                if (node.label === 'ThisExpression') return 'this';
                if (node.label === 'MemberExpression') return 'Member';
                if (node.label === 'OptionalMemberExpression') return 'Member (optional)';
                if (node.label === 'FunctionExpression') return 'Function';
                if (node.label === 'ArrowFunctionExpression') return 'Arrow function';
                if (node.label === 'ClassExpression') return 'Class';
                if (node.label === 'ExportSpecifier') return 'Export specifier';
                if (node.label === 'ImportSpecifier') return 'Import specifier';
                if (node.label === 'ClassProperty') return 'Class property';
                if (node.label === 'ObjectProperty') return 'Object property';
                if (node.label === 'AwaitExpression') return 'Await';
                if (node.label === 'RegExpLiteral') return 'Regular expression';
                if (node.label === 'UpdateExpression') return reteStudioCore.humanizeOperator(node.data.operator, 'update');
                if (node.label === 'BinaryExpression') return reteStudioCore.humanizeOperator(node.data.operator, 'binary');
                if (node.label === 'UnaryExpression') return reteStudioCore.humanizeOperator(node.data.operator, 'unary');
                if (node.label === 'LogicalExpression') return reteStudioCore.humanizeOperator(node.data.operator, 'logical');
              }, function (node) {
                return node.updateSize();
              })(context);
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.rename(function (node) {
                if (node.label === 'Assign') {
                  node.data.operator = '=';
                  return 'AssignmentExpression';
                }
                if (node.label === 'Variable') return 'VariableDeclarator';
                if (node.label === 'Import') return 'ImportDeclaration';
                if (node.label === 'Export') return 'ExportNamedDeclaration';
                if (node.label === 'Export all') return 'ExportAllDeclaration';
                if (node.label === 'Export default') return 'ExportDefaultDeclaration';
                if (node.label === 'Throw') return 'ThrowStatement';
                if (node.label === 'Debug') return 'DebuggerStatement';
                if (node.label === 'If') return node.type === 'expression' ? 'ConditionalExpression' : 'IfStatement';
                if (node.label === 'Call') return 'CallExpression';
                if (node.label === 'Statement') return 'ExpressionStatement';
                if (node.label === 'Switch') return 'SwitchStatement';
                if (node.label === 'With') return 'WithStatement';
                if (node.label === 'Array') return 'ArrayExpression';
                if (node.label === 'Object') return 'ObjectExpression';
                if (node.label === 'New') return 'NewExpression';
                if (node.label === 'Object destructing') return 'ObjectPattern';
                if (node.label === 'Array destructing') return 'ArrayPattern';
                if (node.label === 'Default') return 'AssignmentPattern';
                if (node.label === 'Spread') return 'SpreadElement';
                if (node.label === 'Rest') return 'RestElement';
                if (node.label === 'Yield') return 'YieldExpression';
                if (node.label === 'Return') return 'ReturnStatement';
                if (node.label === 'Try') return 'TryStatement';
                if (node.label === 'Catch') return 'CatchClause';
                if (node.label === 'this') return 'ThisExpression';
                if (node.label === 'Member') return 'MemberExpression';
                if (node.label === 'Member (optional)') return 'OptionalMemberExpression';
                if (node.label === 'Function') return 'FunctionExpression';
                if (node.label === 'Arrow function') return 'ArrowFunctionExpression';
                if (node.label === 'Class') return 'ClassExpression';
                if (node.label === 'Export specifier') return 'ExportSpecifier';
                if (node.label === 'Import specifier') return 'ImportSpecifier';
                if (node.label === 'Class property') return 'ClassProperty';
                if (node.label === 'Object property') return 'ObjectProperty';
                if (node.label === 'Await') return 'AwaitExpression';
                if (node.label === 'Regular expression') return 'RegExpLiteral';
                if (reteStudioCore.getUpdateOperator(node.label)) {
                  node.data.operator = reteStudioCore.getUpdateOperator(node.label);
                  return 'UpdateExpression';
                }
                var unaryOperator = reteStudioCore.getUnaryOperator(node.label);
                if (unaryOperator) {
                  node.data.operator = unaryOperator;
                  return 'UnaryExpression';
                }
                var binaryOperator = reteStudioCore.getBinaryOperator(node.label) || t__namespace.BINARY_OPERATORS.find(function (op) {
                  return op === node.label;
                });
                var logicalOperator = reteStudioCore.getLogicalOperator(node.label) || t__namespace.LOGICAL_OPERATORS.find(function (op) {
                  return op === node.label;
                });
                if (binaryOperator) {
                  node.data.operator = binaryOperator;
                  return 'BinaryExpression';
                }
                if (logicalOperator) {
                  node.data.operator = logicalOperator;
                  return 'LogicalExpression';
                }
                // throw new Error(`Unknown node type: ${node.label}`)
              }, function (node) {
                return node.updateSize();
              })(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return Rename;
}(reteStudioCore.Transformer);

function _createSuper$5(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$5(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$5() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var RestoreBindPorts = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](RestoreBindPorts, _Transformer);
  var _super = _createSuper$5(RestoreBindPorts);
  function RestoreBindPorts() {
    _classCallCheck__default["default"](this, RestoreBindPorts);
    return _super.call(this, 'Restore bind ports');
  }
  _createClass__default["default"](RestoreBindPorts, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
            case 1:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.ensurePorts(function () {
                return {
                  inputs: [reteStudioCore.BIND_KEY],
                  outputs: [reteStudioCore.BIND_KEY]
                };
              }, function () {
                return null;
              })(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return RestoreBindPorts;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper$1(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray$1(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray$1(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray$1(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$1(o, minLen); }
function _arrayLikeToArray$1(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$4(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$4(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$4() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var ReverseUnpackSolidClosures = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](ReverseUnpackSolidClosures, _Transformer);
  var _super = _createSuper$4(ReverseUnpackSolidClosures);
  function ReverseUnpackSolidClosures() {
    _classCallCheck__default["default"](this, ReverseUnpackSolidClosures);
    return _super.call(this, 'Reverse unpack solid closures');
  }
  _createClass__default["default"](ReverseUnpackSolidClosures, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
            case 1:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
                  var editor, nodes, _iterator, _step, _loop;
                  return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context3) {
                    while (1) switch (_context3.prev = _context3.next) {
                      case 0:
                        editor = context.editor;
                        nodes = editor.getNodes().filter(function (node) {
                          return ['FunctionExpression', 'ClassMethod', 'ArrowFunctionExpression', 'ClassExpression'].includes(node.label);
                        });
                        _iterator = _createForOfIteratorHelper$1(nodes);
                        _context3.prev = 3;
                        _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                          var node, entry, _getInputNode, _getInputNode2, inp, inputConnection;
                          return _regeneratorRuntime__default["default"].wrap(function _loop$(_context2) {
                            while (1) switch (_context2.prev = _context2.next) {
                              case 0:
                                node = _step.value;
                                entry = editor.getNodes().find(function (n) {
                                  return n.label === 'Entry' && n.parent === node.id;
                                });
                                if (entry) {
                                  _context2.next = 4;
                                  break;
                                }
                                throw new Error('Entry not found');
                              case 4:
                                _getInputNode = reteStudioCore.getInputNode(context, node.id, reteStudioCore.BIND_KEY), _getInputNode2 = _slicedToArray__default["default"](_getInputNode, 2), inp = _getInputNode2[0], inputConnection = _getInputNode2[1];
                                _context2.next = 7;
                                return editor.removeConnection(inputConnection.id);
                              case 7:
                                _context2.next = 9;
                                return editor.addConnection(new reteStudioCore.Connection(inp, inputConnection.sourceOutput, entry, reteStudioCore.BIND_KEY));
                              case 9:
                                entry.label = node.label;
                                entry.type = 'expression';
                                reteStructures.structures(editor).children(function (n) {
                                  return n.id === node.id;
                                }).nodes().forEach(function (n) {
                                  return n.parent = node.parent;
                                });
                                _context2.next = 14;
                                return editor.removeNode(node.id);
                              case 14:
                              case "end":
                                return _context2.stop();
                            }
                          }, _loop);
                        });
                        _iterator.s();
                      case 6:
                        if ((_step = _iterator.n()).done) {
                          _context3.next = 10;
                          break;
                        }
                        return _context3.delegateYield(_loop(), "t0", 8);
                      case 8:
                        _context3.next = 6;
                        break;
                      case 10:
                        _context3.next = 15;
                        break;
                      case 12:
                        _context3.prev = 12;
                        _context3.t1 = _context3["catch"](3);
                        _iterator.e(_context3.t1);
                      case 15:
                        _context3.prev = 15;
                        _iterator.f();
                        return _context3.finish(15);
                      case 18:
                      case "end":
                        return _context3.stop();
                    }
                  }, _callee2, null, [[3, 12, 15, 18]]);
                }));
                return function (_x3) {
                  return _ref.apply(this, arguments);
                };
              }()(context);
            case 2:
            case "end":
              return _context4.stop();
          }
        }, _callee3);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return ReverseUnpackSolidClosures;
}(reteStudioCore.Transformer);

function _createSuper$3(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$3(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$3() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var SaveVariableKind = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](SaveVariableKind, _Transformer);
  var _super = _createSuper$3(SaveVariableKind);
  function SaveVariableKind() {
    _classCallCheck__default["default"](this, SaveVariableKind);
    return _super.call(this, 'Save variable kind');
  }
  _createClass__default["default"](SaveVariableKind, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.forEach(function (node) {
                return ['VariableDeclarator'].includes(node.label);
              }, /*#__PURE__*/function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(node, context) {
                  var _getInputNode, _getInputNode2, declaration;
                  return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        _getInputNode = reteStudioCore.getInputNode(context, node.id, reteStudioCore.BIND_KEY), _getInputNode2 = _slicedToArray__default["default"](_getInputNode, 1), declaration = _getInputNode2[0];
                        node.data.kind = declaration.data.kind;
                      case 2:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }));
                return function (_x2, _x3) {
                  return _ref.apply(this, arguments);
                };
              }())(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
            case 1:
            case "end":
              return _context3.stop();
          }
        }, _callee3);
      }));
      function down(_x4) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return SaveVariableKind;
}(reteStudioCore.Transformer);

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _createSuper$2(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$2(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$2() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var SimplifyIdentifiers = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](SimplifyIdentifiers, _Transformer);
  var _super = _createSuper$2(SimplifyIdentifiers);
  function SimplifyIdentifiers() {
    _classCallCheck__default["default"](this, SimplifyIdentifiers);
    return _super.call(this, 'Simplify identifiers');
  }
  _createClass__default["default"](SimplifyIdentifiers, [{
    key: "addRefSocket",
    value: function addRefSocket(nodeId, outputKey, identifier, context) {
      var node = context.editor.getNode(nodeId);
      var output = node.outputs[outputKey];
      if (output && !(output.socket instanceof reteStudioCore.RefSocket)) {
        var socket = new reteStudioCore.RefSocket('Reference');
        socket.identifier = identifier;
        output.socket = socket;
      }
    }
  }, {
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        var _this = this;
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return reteStudioCore.simplifyIdentifiers(function (node, context) {
                var editor = context.editor;
                if (node.label !== 'Identifier') return false;
                var outcomingCons = editor.getConnections().filter(function (c) {
                  return c.source === node.id;
                });
                return outcomingCons.length === 0;
              }, function (node, context) {
                var editor = context.editor;
                if (node.label !== 'Identifier') return false;
                var incomingCons = editor.getConnections().filter(function (c) {
                  return c.target === node.id;
                });
                if (incomingCons.length > 0) return false;
                var _getOutputNode = reteStudioCore.getOutputNode(context, node.id, reteStudioCore.BIND_KEY),
                  _getOutputNode2 = _slicedToArray__default["default"](_getOutputNode, 2),
                  targetNode = _getOutputNode2[0],
                  targetConnection = _getOutputNode2[1];
                var isNonReferenceIdentifier = targetNode.label === 'ObjectProperty' && !targetNode.data.computed || targetNode.label === 'MemberExpression' && targetConnection.targetInput === 'property' || targetNode.label === 'ImportSpecifier' && targetConnection.targetInput === 'imported' || targetNode.label === 'ExportSpecifier' && targetConnection.targetInput === 'exported';
                return !isNonReferenceIdentifier;
              }, function (identifier, connection) {
                var nodeId = connection.source;
                var key = connection.sourceOutput;
                _this.addRefSocket(nodeId, key, String(identifier.data.name), context);
              })(context);
            case 2:
              _context.next = 4;
              return reteStudioCore.forEach(function (n) {
                return ['VariableDeclarator'].includes(n.label);
              }, function (node) {
                _this.addRefSocket(node.id, 'id', "var".concat(rete.getUID()), context);
              })(context);
            case 4:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.next = 2;
              return function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
                  var editor, identifiers, addIdentifier, _addIdentifier, _iterator, _step, _loop;
                  return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context4) {
                    while (1) switch (_context4.prev = _context4.next) {
                      case 0:
                        _addIdentifier = function _addIdentifier3() {
                          _addIdentifier = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(name, parent) {
                            var node;
                            return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
                              while (1) switch (_context2.prev = _context2.next) {
                                case 0:
                                  node = new reteStudioCore.BaseNode('Identifier');
                                  node.type = 'expression';
                                  node.data.name = name;
                                  node.parent = parent;
                                  _context2.next = 6;
                                  return editor.addNode(node);
                                case 6:
                                  return _context2.abrupt("return", node);
                                case 7:
                                case "end":
                                  return _context2.stop();
                              }
                            }, _callee2);
                          }));
                          return _addIdentifier.apply(this, arguments);
                        };
                        addIdentifier = function _addIdentifier2(_x4, _x5) {
                          return _addIdentifier.apply(this, arguments);
                        };
                        editor = context.editor;
                        identifiers = context.editor.getNodes().map(function (node) {
                          return Object.entries(node.outputs).filter(function (_ref2) {
                            var _ref3 = _slicedToArray__default["default"](_ref2, 2);
                              _ref3[0];
                              var output = _ref3[1];
                            return output && output.socket instanceof reteStudioCore.RefSocket;
                          }).map(function (_ref4) {
                            var _ref5 = _slicedToArray__default["default"](_ref4, 2),
                              key = _ref5[0],
                              output = _ref5[1];
                            return {
                              node: node,
                              key: key,
                              output: output
                            };
                          }).filter(function (_ref6) {
                            var node = _ref6.node,
                              key = _ref6.key;
                            var outgoers = reteStructures.structures(editor).outgoers(node.id, function (_, c) {
                              return c.sourceOutput === key;
                            });
                            return outgoers.filter(function (n) {
                              return ['ArrayPattern', 'ObjectPattern'].includes(n.label);
                            }).nodes().length === 0;
                          });
                        }).flat();
                        _iterator = _createForOfIteratorHelper(identifiers);
                        _context4.prev = 5;
                        _loop = /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _loop() {
                          var ident, key, node, output, identifierConnections, outputIdentifier, _iterator2, _step2, _output$socket, connection, target, identifier, inputIdentifier;
                          return _regeneratorRuntime__default["default"].wrap(function _loop$(_context3) {
                            while (1) switch (_context3.prev = _context3.next) {
                              case 0:
                                ident = _step.value;
                                key = ident.key, node = ident.node, output = ident.output;
                                identifierConnections = editor.getConnections().filter(function (c) {
                                  return c.source === node.id && c.sourceOutput === key;
                                });
                                _context3.next = 5;
                                return addIdentifier((output === null || output === void 0 ? void 0 : output.socket) instanceof reteStudioCore.RefSocket && output.socket.identifier || '', node.parent);
                              case 5:
                                outputIdentifier = _context3.sent;
                                _context3.next = 8;
                                return editor.addConnection(new reteStudioCore.Connection(node, key, outputIdentifier, reteStudioCore.BIND_KEY));
                              case 8:
                                _iterator2 = _createForOfIteratorHelper(identifierConnections);
                                _context3.prev = 9;
                                _iterator2.s();
                              case 11:
                                if ((_step2 = _iterator2.n()).done) {
                                  _context3.next = 26;
                                  break;
                                }
                                connection = _step2.value;
                                target = editor.getNode(connection.target);
                                identifier = output === null || output === void 0 ? void 0 : (_output$socket = output.socket) === null || _output$socket === void 0 ? void 0 : _output$socket.identifier;
                                if (identifier) {
                                  _context3.next = 17;
                                  break;
                                }
                                throw new Error('No identifier');
                              case 17:
                                _context3.next = 19;
                                return addIdentifier(identifier, target.parent);
                              case 19:
                                inputIdentifier = _context3.sent;
                                _context3.next = 22;
                                return editor.addConnection(new reteStudioCore.Connection(inputIdentifier, reteStudioCore.BIND_KEY, target, connection.targetInput));
                              case 22:
                                _context3.next = 24;
                                return editor.removeConnection(connection.id);
                              case 24:
                                _context3.next = 11;
                                break;
                              case 26:
                                _context3.next = 31;
                                break;
                              case 28:
                                _context3.prev = 28;
                                _context3.t0 = _context3["catch"](9);
                                _iterator2.e(_context3.t0);
                              case 31:
                                _context3.prev = 31;
                                _iterator2.f();
                                return _context3.finish(31);
                              case 34:
                                if (output) output.socket = new reteStudioCore.Socket('any');
                              case 35:
                              case "end":
                                return _context3.stop();
                            }
                          }, _loop, null, [[9, 28, 31, 34]]);
                        });
                        _iterator.s();
                      case 8:
                        if ((_step = _iterator.n()).done) {
                          _context4.next = 12;
                          break;
                        }
                        return _context4.delegateYield(_loop(), "t0", 10);
                      case 10:
                        _context4.next = 8;
                        break;
                      case 12:
                        _context4.next = 17;
                        break;
                      case 14:
                        _context4.prev = 14;
                        _context4.t1 = _context4["catch"](5);
                        _iterator.e(_context4.t1);
                      case 17:
                        _context4.prev = 17;
                        _iterator.f();
                        return _context4.finish(17);
                      case 20:
                      case "end":
                        return _context4.stop();
                    }
                  }, _callee3, null, [[5, 14, 17, 20]]);
                }));
                return function (_x3) {
                  return _ref.apply(this, arguments);
                };
              }()(context);
            case 2:
            case "end":
              return _context5.stop();
          }
        }, _callee4);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return SimplifyIdentifiers;
}(reteStudioCore.Transformer);

function _createSuper$1(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct$1(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct$1() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var SolidBlocksEntry = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](SolidBlocksEntry, _Transformer);
  var _super = _createSuper$1(SolidBlocksEntry);
  function SolidBlocksEntry() {
    _classCallCheck__default["default"](this, SolidBlocksEntry);
    return _super.call(this, 'Solid blocks entry');
  }
  _createClass__default["default"](SolidBlocksEntry, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.forEach(function (n) {
                return ['FunctionExpression', 'ArrowFunctionExpression', 'ClassExpression', 'ClassMethod'].includes(n.label);
              }, /*#__PURE__*/function () {
                var _ref = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(node, context) {
                  var editor, createConnection, _getInputNode, _getInputNode2, input, inputCon, closure;
                  return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        editor = context.editor, createConnection = context.createConnection;
                        _getInputNode = reteStudioCore.getInputNode(context, node.id, reteStudioCore.BIND_KEY), _getInputNode2 = _slicedToArray__default["default"](_getInputNode, 2), input = _getInputNode2[0], inputCon = _getInputNode2[1];
                        _context.next = 4;
                        return editor.removeConnection(inputCon.id);
                      case 4:
                        if (node.parent) {
                          _context.next = 6;
                          break;
                        }
                        throw new Error('No parent for function expression');
                      case 6:
                        closure = editor.getNode(node.parent);
                        closure.label = node.label;
                        node.label = 'Entry';
                        node.type = 'unknown';
                        _context.next = 12;
                        return editor.addConnection(createConnection(input, inputCon.sourceOutput, closure, reteStudioCore.BIND_KEY));
                      case 12:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }));
                return function (_x2, _x3) {
                  return _ref.apply(this, arguments);
                };
              }())(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
            case 1:
            case "end":
              return _context3.stop();
          }
        }, _callee3);
      }));
      function down(_x4) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return SolidBlocksEntry;
}(reteStudioCore.Transformer);

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf__default["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf__default["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn__default["default"](this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var TreeFlow = /*#__PURE__*/function (_Transformer) {
  _inherits__default["default"](TreeFlow, _Transformer);
  var _super = _createSuper(TreeFlow);
  function TreeFlow() {
    _classCallCheck__default["default"](this, TreeFlow);
    return _super.call(this, 'tree flow');
  }
  _createClass__default["default"](TreeFlow, [{
    key: "up",
    value: function () {
      var _up = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return reteStudioCore.treeToFlow({
                isStart: function isStart(node) {
                  return ['Program', 'ClassMethod', 'FunctionExpression', 'ArrowFunctionExpression'].includes(node.label);
                },
                isSequence: function isSequence(node) {
                  if (['Program', 'BlockStatement'].includes(node.label)) return /^body\[.*\]$/;
                  if (['VariableDeclaration'].includes(node.label)) return /^declarations\[.*\]$/;
                  if (['CatchClause'].includes(node.label)) return /^body$/;
                  return false;
                },
                getBlockParameterName: function getBlockParameterName(node) {
                  if (node.label === 'Program') return {
                    array: true,
                    key: 'body'
                  };
                  if (node.label === 'VariableDeclaration') return {
                    array: true,
                    key: 'declarations'
                  };
                  if (node.label === 'CatchClause') return {
                    array: false,
                    key: 'body'
                  };
                  if (node.label === 'ObjectPattern') return {
                    array: true,
                    key: 'properties'
                  };
                  return {
                    array: true,
                    key: 'body'
                  };
                },
                isBranch: function isBranch(node) {
                  if (['IfStatement'].includes(node.label)) return /(alternate|consequent)/;
                  if (['TryStatement'].includes(node.label)) return /(block|handler|finalizer)/;
                  if (['LabeledStatement'].includes(node.label)) return /(body|alternate)/;
                  return false;
                }
              })(context);
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function up(_x) {
        return _up.apply(this, arguments);
      }
      return up;
    }()
  }, {
    key: "down",
    value: function () {
      var _down = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2(context) {
        return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return reteStudioCore.flowToTree({
                isRoot: function isRoot(node, context) {
                  if (node.label === 'BlockStatement') {
                    var prev = context.editor.getConnections().filter(function (c) {
                      return c.target === node.id && c.targetInput === reteStudioCore.BIND_KEY;
                    }).map(function (c) {
                      return context.editor.getNode(c.source);
                    });
                    if (prev.length === 0) throw new Error('BlockStatement must have an incomer');
                    if (prev.length > 1) return false;
                    return ['ClassMethod', 'FunctionExpression', 'Constructor', 'ArrowFunctionExpression'].includes(prev[0].label);
                  }
                  return ['Program'].includes(node.label);
                },
                isBranch: function isBranch(node) {
                  return ['IfStatement', 'TryStatement', 'LabeledStatement'].includes(node.label);
                },
                getBranchNames: function getBranchNames(node) {
                  if (node.label === 'IfStatement') return ['consequent', 'alternate'];
                  if (node.label === 'LabeledStatement') return ['body', 'alternate'];
                  if (node.label === 'TryStatement') return ['block', 'handler', 'finalizer'];
                  throw new Error("Unknown branch node ".concat(node.label));
                },
                isBlock: function isBlock(node) {
                  return ['BlockStatement', 'Program', 'VariableDeclaration', 'CatchClause'].includes(node.label);
                },
                getBlockParameterName: function getBlockParameterName(node) {
                  if (node.label === 'Program') return {
                    array: true,
                    key: 'body'
                  };
                  if (node.label === 'VariableDeclaration') return {
                    array: true,
                    key: 'declarations'
                  };
                  if (node.label === 'CatchClause') return {
                    array: false,
                    key: 'body'
                  };
                  if (node.label === 'ObjectPattern') return {
                    array: true,
                    key: 'properties'
                  };
                  return {
                    array: true,
                    key: 'body'
                  };
                },
                isValidSubflow: function isValidSubflow(entry, flow) {
                  if (entry.label === 'VariableDeclaration') return flow.label === 'VariableDeclarator';
                  return true;
                }
              })(context);
            case 2:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function down(_x2) {
        return _down.apply(this, arguments);
      }
      return down;
    }()
  }]);
  return TreeFlow;
}(reteStudioCore.Transformer);

function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty__default["default"](e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var base = {
  createInput: function createInput(label) {
    return new rete.ClassicPreset.Input(reteStudioCore.socket, label, true);
  },
  createOutput: function createOutput(label) {
    return new reteStudioCore.Output(reteStudioCore.socket, label, true);
  },
  createConnection: function createConnection(source, sourceOutput, target, targetInput, options) {
    return new reteStudioCore.Connection(source, sourceOutput, target, targetInput, options);
  },
  createNode: function createNode(type) {
    return new reteStudioCore.BaseNode(type);
  }
};
var astTools = {
  parse: function parse(code) {
    return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee() {
      var parserOptions;
      return _regeneratorRuntime__default["default"].wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            parserOptions = {
              sourceType: 'module',
              strictMode: false,
              errorRecovery: true
            };
            return _context.abrupt("return", parser.parse(code, parserOptions));
          case 2:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  generate: function generate(ast) {
    return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee2() {
      return _regeneratorRuntime__default["default"].wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            return _context2.abrupt("return", _generate__default["default"](ast).code);
          case 1:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  purify: function purify(ast) {
    return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee3() {
      return _regeneratorRuntime__default["default"].wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            return _context3.abrupt("return", applyAstTransformations(ast));
          case 1:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }))();
  },
  unpurify: function unpurify(ast) {
    return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee4() {
      return _regeneratorRuntime__default["default"].wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            return _context4.abrupt("return", applyAstReverseTransformations(ast));
          case 1:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }))();
  },
  executable: function executable(ast) {
    return _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee5() {
      return _regeneratorRuntime__default["default"].wrap(function _callee5$(_context5) {
        while (1) switch (_context5.prev = _context5.next) {
          case 0:
            return _context5.abrupt("return", makePurifiedExecutable(t__namespace.cloneNode(ast)));
          case 1:
          case "end":
            return _context5.stop();
        }
      }, _callee5);
    }))();
  }
};
function initCodePlugin() {
  var processedTypes = new Set();
  var unsupportedTypes = ['ClassPrivateProperty', 'ClassPrivateMethod', 'PrivateName', 'WithStatement', 'Directive', 'FunctionDeclaration', 'ClassDeclaration', 'CommentLine'];
  var code = new reteStudioCore.CodePlugin({
    transformers: [new MarkClosures(), new ClearUnknown(), new AddFlowPlaceholder(), new SaveVariableKind(), new TreeFlow(), new SolidBlocksEntry(), new OmitBlockNodes(), new OmitContinue(), new PruneDeadStatements(), new OmitBreak(), new PruneDeadStatements(), new OmitLabeled(), new ReverseUnpackSolidClosures(), new MarkConstructor(), new RestoreBindPorts(), new MirrorDataflowExpressions(), new SimplifyIdentifiers(), new LiteralsToControls(), new OmitRestoreClosures(), new ExpressionIntoStatement(), new InnerPorts(), new CleanUpPorts(), new MarkFrames(), new MarkControlSockets(), new AddControls(), new Rename()],
    up: _objectSpread(_objectSpread({}, base), {}, {
      isSupported: function isSupported(node) {
        return !unsupportedTypes.includes(node.type);
      },
      isStatement: function isStatement(data) {
        return t__namespace.isStatement(data) || t__namespace.isVariableDeclarator(data) || t__namespace.isSwitchCase(data) || t__namespace.isCatchClause(data);
      },
      isExpression: function isExpression(data) {
        return t__namespace.isProgram(data) || t__namespace.isExpression(data) || t__namespace.isLiteral(data) || t__namespace.isSpreadElement(data) || t__namespace.isClassBody(data) || t__namespace.isClassMethod(data) || t__namespace.isClassProperty(data) || t__namespace.isTemplateElement(data) || t__namespace.isSwitchCase(data) || t__namespace.isObjectProperty(data) || t__namespace.isObjectMethod(data) || t__namespace.isModuleSpecifier(data) || t__namespace.isRestElement(data) || t__namespace.isPattern(data);
      },
      nodeCreated: function nodeCreated(node) {
        node.type && processedTypes.add(node.type);
      }
    }),
    down: _objectSpread(_objectSpread({}, base), {}, {
      createASTNode: function createASTNode(node, args) {
        if (!(node.label in t__namespace)) throw new Error("Unknown factory ".concat(node.label));
        var factory = t__namespace[node.label];
        if (typeof factory !== 'function') throw new Error("Factory ".concat(node.label, " is not a function"));
        return factory.apply(void 0, _toConsumableArray__default["default"](args));
      },
      nodeParameters: function nodeParameters(label) {
        return t__namespace.BUILDER_KEYS[label];
      },
      defaults: function defaults(node, key) {
        if (['FunctionExpression', 'ArrowFunctionExpression', 'ClassMethod'].includes(node.label)) {
          if (key === 'params') return [];
          if (key === 'body') return t__namespace.blockStatement([]);
        }
        if (['IfStatement'].includes(node.label) && key === 'alternate') return null;
        if (['IfStatement'].includes(node.label) && key === 'consequent') return t__namespace.blockStatement([]);
        if (['ImportDeclaration'].includes(node.label) && key === 'specifiers') return [];
        if (['CallExpression', 'NewExpression'].includes(node.label) && key === 'arguments') return [];
        if (['ClassBody', 'BlockStatement'].includes(node.label) && key === 'body') return [];
        if (['TemplateLiteral'].includes(node.label) && key === 'expressions') return [];
        if (['ObjectPattern'].includes(node.label) && key === 'properties') return [];
      }
    })
  });
  function toGraph(_x) {
    return _toGraph.apply(this, arguments);
  }
  function _toGraph() {
    _toGraph = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee6(ast) {
      return _regeneratorRuntime__default["default"].wrap(function _callee6$(_context6) {
        while (1) switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return code.toGraph(ast);
          case 2:
          case "end":
            return _context6.stop();
        }
      }, _callee6);
    }));
    return _toGraph.apply(this, arguments);
  }
  function toAST() {
    return _toAST.apply(this, arguments);
  }
  function _toAST() {
    _toAST = _asyncToGenerator__default["default"]( /*#__PURE__*/_regeneratorRuntime__default["default"].mark(function _callee7() {
      var ast;
      return _regeneratorRuntime__default["default"].wrap(function _callee7$(_context7) {
        while (1) switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return code.toAST();
          case 2:
            ast = _context7.sent;
            return _context7.abrupt("return", astTools.unpurify(ast));
          case 4:
          case "end":
            return _context7.stop();
        }
      }, _callee7);
    }));
    return _toAST.apply(this, arguments);
  }
  return {
    code: code,
    astTools: astTools,
    unsupportedTypes: unsupportedTypes,
    processedTypes: processedTypes,
    toGraph: toGraph,
    toAST: toAST
  };
}

var name = 'JavaScript';
var playgroundExample = "let count = 5;\n\nwhile (count > 0) {\n  log(count);\n  count--;\n}\n\nlog(\"Countdown complete!\");\n";
var snippets = [{
  label: 'Variable',
  code: "const name = '';"
}, {
  label: 'Assign',
  subitems: [{
    label: 'assign',
    code: "name = '';"
  }, {
    label: 'increment',
    code: "i++"
  }, {
    label: 'decrement',
    code: "i--"
  }]
}, {
  label: 'Math',
  subitems: [{
    label: '+',
    code: "1 + 1"
  }, {
    label: '-',
    code: "1 - 1"
  }, {
    label: '*',
    code: "1 * 1"
  }, {
    label: '/',
    code: "1 / 1"
  }, {
    label: '%',
    code: "1 % 1"
  }]
}, {
  label: 'Logical',
  subitems: [{
    label: 'equal',
    code: "1 == 1"
  }, {
    label: 'not equal',
    code: "1 != 1"
  }, {
    label: 'strict equal',
    code: "1 === 1"
  }, {
    label: 'strict not equal',
    code: "1 !== 1"
  }, {
    label: '>',
    code: "1 > 1"
  }, {
    label: '>=',
    code: "1 >= 1"
  }, {
    label: '<',
    code: "1 < 1"
  }, {
    label: '<=',
    code: "1 <= 1"
  }, {
    label: 'and',
    code: "true && true"
  }, {
    label: 'or',
    code: "true || true"
  }, {
    label: 'not',
    code: "!true"
  }]
}, {
  label: 'Operators',
  subitems: [{
    label: 'typeof',
    code: "typeof 1"
  }, {
    label: 'instanceof',
    code: "1 instanceof Number"
  }, {
    label: 'in',
    code: "0 in [0]"
  }, {
    label: 'delete',
    code: "delete obj.prop"
  }]
}, {
  label: 'Function',
  subitems: [{
    label: 'function',
    code: "function func() {}"
  }, {
    label: 'return',
    code: "return 1"
  }]
}, {
  label: 'If',
  code: "if (true) {}"
}, {
  label: 'Array',
  code: "[1]"
}, {
  label: 'Object',
  code: "({ a: 1 })"
}, {
  label: 'Class',
  code: "class Class {\n      constructor() {}\n    }"
}, {
  label: 'Modules',
  subitems: [{
    label: 'Import',
    code: "import { n } from ''"
  }, {
    label: 'Export',
    code: "export { n }"
  }]
}, {
  label: 'Try-catch',
  code: "try {} catch (e) {}"
}, {
  label: 'Log',
  code: "console.log()"
}];

exports.astTools = astTools;
exports.initCodePlugin = initCodePlugin;
exports.name = name;
exports.playgroundExample = playgroundExample;
exports.snippets = snippets;
//# sourceMappingURL=rete-studio-java-script-lang.common.js.map
