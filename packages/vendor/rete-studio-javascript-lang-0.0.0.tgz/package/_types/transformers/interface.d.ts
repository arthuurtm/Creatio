export { Transformer } from 'rete-studio-core';
//# sourceMappingURL=interface.d.ts.map