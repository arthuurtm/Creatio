import { ASTNodeBase, Context, InputType, Schemes, ToASTContext } from 'rete-studio-core';
import { Transformer } from './interface';
export declare class LiteralsToControls<ASTNode extends ASTNodeBase, S extends Schemes> extends Transformer<Context<ASTNode, S>, ToASTContext<ASTNode, S>> {
    types: Record<string, [InputType, unknown]>;
    constructor();
    literalToType(label: string): InputType;
    up(context: Context<ASTNode, S>): Promise<void>;
    typeToLiteral(type: InputType): [string, unknown];
    down(context: ToASTContext<ASTNode, S>): Promise<void>;
}
//# sourceMappingURL=literals-to-controls.d.ts.map