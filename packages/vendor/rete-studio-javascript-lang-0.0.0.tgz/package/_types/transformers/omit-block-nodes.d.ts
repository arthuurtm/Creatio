import { ASTNodeBase, Context, Schemes, ToASTContext } from 'rete-studio-core';
import { Transformer } from './interface';
export declare class OmitBlockNodes<ASTNode extends ASTNodeBase, S extends Schemes> extends Transformer<Context<ASTNode, S>, ToASTContext<ASTNode, S>> {
    constructor();
    up(context: Context<ASTNode, S>): Promise<void>;
    private insertNode;
    down(context: ToASTContext<ASTNode, S>): Promise<void>;
}
//# sourceMappingURL=omit-block-nodes.d.ts.map