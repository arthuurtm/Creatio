import { ASTNodeBase, Context, Schemes, ToASTContext } from 'rete-studio-core';
import { Transformer } from './interface';
export declare class SimplifyIdentifiers<ASTNode extends ASTNodeBase, S extends Schemes> extends Transformer<Context<ASTNode, S>, ToASTContext<ASTNode, S>> {
    constructor();
    private addRefSocket;
    up(context: Context<ASTNode, S>): Promise<void>;
    down(context: ToASTContext<ASTNode, S>): Promise<void>;
}
//# sourceMappingURL=simplify-identifiers.d.ts.map