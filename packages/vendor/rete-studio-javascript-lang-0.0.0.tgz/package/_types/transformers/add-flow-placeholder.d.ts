import { ASTNodeBase, Context, Schemes, ToASTContext } from 'rete-studio-core';
import { Transformer } from './interface';
export declare class AddFlowPlaceholder<ASTNode extends ASTNodeBase, S extends Schemes> extends Transformer<Context<ASTNode, S>, ToASTContext<ASTNode, S>> {
    constructor();
    up(context: Context<ASTNode, S>): Promise<void>;
    down({ editor }: ToASTContext<ASTNode, S>): Promise<void>;
}
//# sourceMappingURL=add-flow-placeholder.d.ts.map