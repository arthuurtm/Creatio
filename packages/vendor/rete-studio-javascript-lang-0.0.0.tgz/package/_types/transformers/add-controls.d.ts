import { ASTNodeBase, Context, InsertControl, Schemes, ToASTContext } from 'rete-studio-core';
import { Transformer } from './interface';
export declare class AddControls<ASTNode extends ASTNodeBase, S extends Schemes> extends Transformer<Context<ASTNode, S>, ToASTContext<ASTNode, S>> {
    constructor();
    createInsertButton(key: string, side: 'input' | 'output', needControl?: boolean): InsertControl;
    private createOutputIdentifierControl;
    private createTextControl;
    up(context: Context<ASTNode, S>): Promise<void>;
    down(context: ToASTContext<ASTNode, S>): Promise<void>;
}
//# sourceMappingURL=add-controls.d.ts.map