import { Scope as TraverseScope } from '@babel/traverse';
import * as BabelType from '@babel/types';
export declare function declarationToVariable(declaration: BabelType.Declaration, transformBody: (body: BabelType.Node, parentScope: TraverseScope) => void, parentScope: TraverseScope): BabelType.VariableDeclaration;
export declare function declarationToExpression(declaration: BabelType.Declaration, transformBody: (body: BabelType.Node, parentScope: TraverseScope) => void, parentScope: TraverseScope): BabelType.ClassExpression | BabelType.FunctionExpression;
//# sourceMappingURL=declarations.d.ts.map