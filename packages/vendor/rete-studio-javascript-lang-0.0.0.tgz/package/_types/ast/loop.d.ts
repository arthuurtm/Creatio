import { NodePath } from '@babel/traverse';
import * as BabelType from '@babel/types';
export declare function createLoop(path: NodePath<BabelType.Statement>): {
    id: BabelType.Identifier;
    statement: BabelType.LabeledStatement;
    patchContinue(body: BabelType.Statement, pregoto?: BabelType.Statement | null): void;
};
export declare function loopToGoto(path: NodePath<BabelType.WhileStatement | BabelType.ForStatement>, pregoto?: BabelType.Statement | null): {
    statement: BabelType.LabeledStatement;
    id: BabelType.Identifier;
    body: BabelType.BlockStatement;
};
//# sourceMappingURL=loop.d.ts.map