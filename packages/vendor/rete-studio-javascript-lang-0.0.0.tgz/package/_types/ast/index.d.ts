import { Scope as TraverseScope } from '@babel/traverse';
import * as BabelType from '@babel/types';
export declare function makePurifiedExecutable<T extends BabelType.Node>(node: T, scope?: TraverseScope): T;
export declare function applyAstTransformations<T extends BabelType.Node>(node: T, scope?: TraverseScope): T;
export declare function applyAstReverseTransformations<T extends BabelType.Node>(node: T, scope?: TraverseScope): T;
//# sourceMappingURL=index.d.ts.map