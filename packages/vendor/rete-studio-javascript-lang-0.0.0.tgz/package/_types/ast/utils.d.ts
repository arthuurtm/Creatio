import * as BabelType from '@babel/types';
export declare function getIdentifiers(v: BabelType.LVal): BabelType.Identifier[];
//# sourceMappingURL=utils.d.ts.map