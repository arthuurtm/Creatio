import * as BabelType from '@babel/types';
export declare function hoise(scopable: BabelType.Scopable, declaration: BabelType.Declaration): void;
export declare function getScopableBody(scopable: BabelType.Scopable): BabelType.Statement[];
export declare function prepend(parent: BabelType.Node, node: BabelType.Statement, nextSibling: BabelType.Statement): void;
export declare function append(parent: BabelType.Node, node: BabelType.Statement, nextSibling: BabelType.Statement): void;
//# sourceMappingURL=scope.d.ts.map