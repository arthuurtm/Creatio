import * as BabelType from '@babel/types';
import { CodePlugin, Schemes } from 'rete-studio-core';
export declare const astTools: {
    parse(code: string): Promise<import("@babel/parser").ParseResult<BabelType.File>>;
    generate(ast: BabelType.File): Promise<string>;
    purify(ast: BabelType.File): Promise<BabelType.File>;
    unpurify(ast: BabelType.File): Promise<BabelType.File>;
    executable(ast: BabelType.File): Promise<BabelType.File>;
};
export declare function initCodePlugin(): {
    code: CodePlugin<Schemes, BabelType.Node>;
    astTools: {
        parse(code: string): Promise<import("@babel/parser").ParseResult<BabelType.File>>;
        generate(ast: BabelType.File): Promise<string>;
        purify(ast: BabelType.File): Promise<BabelType.File>;
        unpurify(ast: BabelType.File): Promise<BabelType.File>;
        executable(ast: BabelType.File): Promise<BabelType.File>;
    };
    unsupportedTypes: string[];
    processedTypes: Set<string>;
    toGraph: (ast: BabelType.File) => Promise<void>;
    toAST: () => Promise<BabelType.File>;
};
//# sourceMappingURL=code-plugin.d.ts.map