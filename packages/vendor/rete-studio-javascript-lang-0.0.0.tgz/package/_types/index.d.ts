import { LanguageSnippet } from 'rete-studio-core';
export { astTools, initCodePlugin } from './code-plugin';
export declare const name = "JavaScript";
export declare const playgroundExample = "let count = 5;\n\nwhile (count > 0) {\n  log(count);\n  count--;\n}\n\nlog(\"Countdown complete!\");\n";
export declare const snippets: LanguageSnippet[];
//# sourceMappingURL=index.d.ts.map